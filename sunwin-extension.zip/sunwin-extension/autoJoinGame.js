(() => {
  function createDebugConsole() {
    try {
      const iframe = document.createElement("iframe");
      iframe.style.display = "none";
      (document.body || document.documentElement).appendChild(iframe);
      return iframe.contentWindow.console.log.bind(
        iframe.contentWindow.console
      );
    } catch (e) {
      console.error("[Phom Monitor] Lỗi tạo debug console:", e);
      return console.log.bind(console);
    }
  }

  const debug = createDebugConsole();

  function createTouchEvent(x, y) {
    const event = new cc.Event.EventTouch([{ x, y }], 0);
    // override getLocation để trả đúng tọa độ
    event.getLocation = () => ({ x, y });
    return event;
  }

  // Hàm tìm node theo tên đệ quy
  function findNodeDeep(name, node) {
    if (!node) return null;
    if (node.name === name) return node;
    for (let child of node.children) {
      const found = findNodeDeep(name, child);
      if (found) return found;
    }
    return null;
  }

  function findNodeByName(name) {
    return findNodeDeep(name, cc.director.getScene());
  }

  // Hàm duyệt toàn bộ scene và thực thi callback nếu node name chứa "popup"
  function findAllPopupsAndClickClose(node = cc.director.getScene()) {
    if (!node) return;

    if (node.name.toLowerCase().includes("popup")) {
      const btnClose = findNodeDeep("btn_close", node);
      if (btnClose) {
        debug("Tìm thấy nút btn_close và click:", btnClose);
        // Có thể cần vị trí tương đối (ví dụ 0,0 hoặc trung tâm)
        const touchX = 0;
        const touchY = 0;

        const startEvent = createTouchEvent(touchX, touchY);
        btnClose.emit(cc.Node.EventType.TOUCH_START, startEvent);

        const endEvent = createTouchEvent(touchX, touchY);
        btnClose.emit(cc.Node.EventType.TOUCH_END, endEvent);
      }
    }

    node.children.forEach((child) => findAllPopupsAndClickClose(child));
  }

  // Chạy
  findAllPopupsAndClickClose();

  function joinGame() {
    const phom = findNodeByName("ico_phom");
    if (!phom) {
      debug("Không tìm thấy node phom");
      return;
    }
    const startEvent = createTouchEvent(0, 0);
    phom.emit(cc.Node.EventType.TOUCH_START, startEvent);
    const endEvent = createTouchEvent(0, 0);
    phom.emit(cc.Node.EventType.TOUCH_END, endEvent);
  }

  joinGame();
})();
