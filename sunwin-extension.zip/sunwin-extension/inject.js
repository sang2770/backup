console.log("[Phom Monitor] Inline script START at:", new Date().toISOString());
(function () {
  // Hàm tạo console ẩn
  function createDebugConsole() {
    try {
      const iframe = document.createElement("iframe");
      iframe.style.display = "none";
      (document.body || document.documentElement).appendChild(iframe);
      return iframe.contentWindow.console.log.bind(
        iframe.contentWindow.console
      );
    } catch (e) {
      console.error("[Phom Monitor] Lỗi tạo debug console:", e);
      return console.log.bind(console);
    }
  }

  const debug = createDebugConsole();
  window.phomMonitor = window.phomMonitor || {};
  window.phomMonitor.activeWebSocket = null;
  window.phomMonitor.currentUser = null; // Track current user info

  // Ghi đè WebSocket
  debug(
    "%c[Phom Monitor] Đang ghi đè WebSocket...",
    "color: orange; font-weight: bold;",
    new Date().toISOString()
  );
  const OriginalWebSocket = window.WebSocket;
  window.WebSocket = new Proxy(OriginalWebSocket, {
    construct(target, args) {
      const url = args[0];
      const ws = new target(...args);
      debug("[Phom Monitor] Tạo WebSocket:", url);
      if (!url.includes("ws-lby.azhkthg1.net") && !url.includes("ws-card04.azhkthg1.net")) {
        return ws;
      }
      debug("[Phom Monitor] Đã tạo WebSocket:", url, new Date().toISOString());

      debug(
        "%c[Phom Monitor] Kết nối WebSocket mới:",
        "color: green; font-weight: bold;",
        url
      );
      window.phomMonitor.activeWebSocket = ws;

      // Common decode function for both incoming and outgoing messages
      const decodeMessageData = (data, direction = "incoming") => {
        // Early validation checks
        if (data === null || data === undefined) {
          debug(`${direction.toUpperCase()} data is null/undefined`);
          return null;
        }

        try {
          // If data is already a string (outgoing), try JSON first
          if (typeof data === 'string') {
            if (data.trim() === '') {
              debug(`${direction.toUpperCase()} empty string`);
              return null;
            }
            try {
              const jsonData = JSON.parse(data);
              // debug(`${direction.toUpperCase()} JSON:`, jsonData);
              return jsonData;
            } catch (jsonError) {
              // debug(`${direction.toUpperCase()} STRING:`, data);
              return data;
            }
          }

          // If data is binary (incoming), validate and try MessagePack first
          let bytes;
          if (data instanceof ArrayBuffer) {
            if (data.byteLength === 0) {
              debug(`${direction.toUpperCase()} empty ArrayBuffer`);
              return null;
            }
            bytes = new Uint8Array(data);
          } else if (data instanceof Uint8Array) {
            if (data.length === 0) {
              debug(`${direction.toUpperCase()} empty Uint8Array`);
              return null;
            }
            bytes = data;
          } else if (data instanceof Blob) {
            debug(`${direction.toUpperCase()} Blob data, not supported yet`);
            return null;
          } else {
            // Try to convert other types to Uint8Array
            try {
              bytes = new Uint8Array(data);
              if (bytes.length === 0) {
                debug(`${direction.toUpperCase()} empty converted array`);
                return null;
              }
            } catch (conversionError) {
              debug(`${direction.toUpperCase()} failed to convert to Uint8Array:`, conversionError.message);
              return null;
            }
          }

          // Try MessagePack decode
          if (typeof MessagePack !== 'undefined' && MessagePack.decode) {
            try {
              const decoded = MessagePack.decode(bytes);
              // debug(`${direction.toUpperCase()} MSGPACK:`, decoded);
              return decoded;
            } catch (msgpackError) {
              // debug(`MSGPACK DECODE ERROR:`, msgpackError.message);
            }
          }

          // Fallback to JSON decode
          try {
            const text = new TextDecoder().decode(bytes);
            if (text.trim()) {
              const jsonData = JSON.parse(text);
              // debug(`${direction.toUpperCase()} JSON FALLBACK:`, jsonData);
              return jsonData;
            } else {
              debug(`${direction.toUpperCase()} empty text after decode`);
              return null;
            }
          } catch (jsonError) {
            debug(`Raw binary data (${direction}):`, bytes);
          }

          return null;
        } catch (error) {
          debug(`DECODE ERROR (${direction}):`, error.message);
          return null;
        }
      };

      ws.addEventListener("open", () => {
        window.postMessage({ type: "PHOM_MONITOR_WS_READY" }, "*");
      });

      function handleMessageData(event) {
        // debug("%c[Phom Monitor] Message nhận:", "color: yellow;", event.data);
        try {
          const parsed = JSON.parse(event.data);
          // toi an bai [5,{"cs":39,"sAC":[13,17,21,31,35,39,20,37,40,49],"cmc":47,"sMs":[13,17,21,31,35,39],"ic":false,"fP":{"uid":"797cec50-7981-40d3-a54d-b05b1f9503b2","lm":-100,"puid":"175dfb50-1bed-4891-be20-819c65eb1f0a","dn":"rrrrweee23","mX":100,"m":5000},"cmd":853}]
          // doi thu an bai [5,{"cs":47,"ic":false,"fP":{"uid":"d390fa55-700d-4269-ac16-8d2fee8c5a06","lm":-100,"puid":"59b71a74-4e60-4a09-bb29-c0d8aab82406","dn":"vaniii","mX":100,"m":4890},"cmd":853}]
          if (
            Array.isArray(parsed) &&
            parsed.length === 2 &&
            parsed[0] === 5 &&
            parsed[1]?.cmd === 853
          ) {
            const currentUser = window.phomMonitor.currentUser;
            const fromPlayer = parsed[1].fP;
            const isOpponent = currentUser && fromPlayer.dn !== currentUser.name;
            const isLow = fromPlayer.lm < 0;
            if (isOpponent && isLow) {
              debug("%c[Phom Monitor] Đối thủ ăn bài:", "color: red;", fromPlayer.dn);
              window.postMessage({
                type: "PHOM_MONITOR_OPPONENT_EAT_CARD",
                data: {
                  playerName: fromPlayer.dn,
                  playerUid: fromPlayer.uid,
                  cs: parsed[1].cs
                }
              });
            } else if (!isOpponent && isLow && parsed[1].sAC) {
              debug("%c[Phom Monitor] Tôi ăn bài:", "color: green;", fromPlayer.dn);
              window.postMessage({
                type: "PHOM_MONITOR_MY_CARDS",
                data: { cards: parsed[1].sAC }
              });
            }
          }

          // user moi vao ban
          // [5,{"uid":"019224b7-69d8-47bb-b0d4-34e8996a0e19","dn":"ch0t","cmd":5}]
          if (
            Array.isArray(parsed) &&
            parsed.length === 2 &&
            parsed[0] === 5 &&
            parsed[1]?.cmd === 5
          ) {
            debug("%c[Phom Monitor] User mới vào bàn:", "color: green;", parsed[1].dn);
            window.postMessage({
              type: "PHOM_MONITOR_USER_JOIN",
              data: {
                userName: parsed[1]?.dn,
                userUid: parsed[1]?.uid
              }
            });
          }
          // Thông tin user và gold - cập nhật current user info
          if (
            Array.isArray(parsed) &&
            parsed.length === 2 &&
            parsed[0] === 5 &&
            parsed[1]?.cmd === 100
          ) {
            const gold = parsed[1]?.["As"]?.["gold"] ?? 0;
            const userKey = parsed[1]?.["dn"];
            const userUid = parsed[1]?.["uid"];

            // Store current user info
            window.phomMonitor.currentUser = {
              name: userKey,
              uid: userUid,
              gold: gold
            };

            debug("%c[Phom Monitor] Current user info:", "color: blue;", window.phomMonitor.currentUser);

            window.postMessage({
              type: "PHOM_MONITOR_GOLD_UPDATE",
              data: {
                gold: gold ?? 0,
                userKey: userKey ?? "",
                userUid: userUid ?? ""
              },
            });
          }


          // [5,{"cs":6,"uid":"9c81b405-b520-461a-ba42-ddb65e26864c","sAC":[4,6,7,42,43,1,15,16,27,33],"sMs":[4,6,7],"dn":"trreewww1","cmd":852}] // Nhận bài sau khi bốc (cmd 852)
          // Phân tích bài của người chơi (khi nhận bài đầu game - cmd 850)
          if (
            Array.isArray(parsed) &&
            parsed.length === 2 &&
            parsed[0] === 5 &&
            (parsed[1]?.cmd === 850 || parsed[1]?.cmd === 852) &&
            parsed[1]?.cs
          ) {
            debug("%c[Phom Monitor] Nhận bài đầu game (cmd 850):", "color: green;", parsed[1].cs);
            window.postMessage({
              type: "PHOM_MONITOR_INIT",
              data: {
                cnt: parsed[1].cs ? parsed[1].cs.length : 0
              }
            });
            window.postMessage({
              type: "PHOM_MONITOR_MY_CARDS",
              data: { cards: parsed[1]?.cmd === 850 ? parsed[1].cs : parsed[1].sAC }
            });
          }

          // Phân tích lượt đánh bài (cmd 851)
          if (
            Array.isArray(parsed) &&
            parsed.length === 2 &&
            parsed[0] === 5 &&
            parsed[1]?.cmd === 851 &&
            parsed[1]?.fP
          ) {
            const fromPlayer = parsed[1].fP;
            const turnPlayer = parsed[1].tP;
            const currentUser = window.phomMonitor.currentUser;

            // debug("%c[Phom Monitor] Ai đó đánh bài (cmd 851):", "color: orange;", {
            //   fromPlayer: fromPlayer.dn,
            //   card: fromPlayer.dCs,
            //   nextPlayer: turnPlayer?.dn,
            //   isMyCard: currentUser && fromPlayer.dn === currentUser.name
            // });

            if (currentUser && fromPlayer.dn === currentUser.name) {
              debug("%c[Phom Monitor] Tôi đánh bài:", "color: green;", fromPlayer.dCs);
              window.postMessage({
                type: "PHOM_MONITOR_MY_PLAYED_CARDS",
                data: { dCs: Array.isArray(fromPlayer.dCs) ? fromPlayer.dCs : [fromPlayer.dCs] }
              });
            } else {
              debug("%c[Phom Monitor] Đối thủ đánh bài:", "color: red;", fromPlayer.dCs);
              window.postMessage({
                type: "PHOM_MONITOR_OPPONENT_PLAYED_CARDS",
                data: {
                  playerName: fromPlayer.dn,
                  playerUid: fromPlayer.uid,
                  dCs: Array.isArray(fromPlayer.dCs) ? fromPlayer.dCs : [fromPlayer.dCs]
                }
              });
            }

            // Kiểm tra lượt tiếp theo có phải của mình không
            if (turnPlayer && currentUser && turnPlayer.dn === currentUser.name) {
              debug("%c[Phom Monitor] Đến lượt tôi:", "color: green;", turnPlayer.dn);
              window.postMessage({
                type: "PHOM_MONITOR_MY_TURN",
                data: {
                  turn: true,
                  gameState: parsed[1],
                  turnPlayer: turnPlayer
                }
              });
            }
          }



          // Phân tích message hạ phỏm (cmd 854)
          if (
            Array.isArray(parsed) &&
            parsed.length === 2 &&
            parsed[0] === 5 &&
            parsed[1]?.cmd === 854 &&
            parsed[1]?.mes
          ) {
            const currentUser = window.phomMonitor.currentUser;
            const isMyPhom = currentUser && parsed[1].dn === currentUser.name;

            debug(`%c[Phom Monitor] ${isMyPhom ? 'Tôi' : 'Đối thủ'} hạ phỏm (cmd 854):`,
              isMyPhom ? "color: green;" : "color: purple;", {
              player: parsed[1].dn,
              combinations: parsed[1].mes,
              isMyPhom: isMyPhom
            });

            window.postMessage({
              type: isMyPhom ? "PHOM_MONITOR_MY_PHOM" : "PHOM_MONITOR_OPPONENT_PHOM",
              data: {
                playerName: parsed[1].dn,
                playerUid: parsed[1].uid,
                combinations: parsed[1].mes,
                isMyPhom: isMyPhom
              }
            });
          }

          // Thông tin người chơi bàn
          if (
            Array.isArray(parsed) &&
            parsed.length === 2 &&
            parsed[0] === 5 &&
            parsed[1]?.cmd === 202
          ) {
            debug(
              "%c[Phom Monitor] Message cmd=202:",
              "color: orange;",
              parsed
            );
            window.postMessage(
              { type: "PHOM_MONITOR_ROOMDATA", roomData: parsed[1] },
              "*"
            );
          }

          // Thông tin phòng
          if (
            Array.isArray(parsed) &&
            parsed.length === 2 &&
            parsed[0] === 5 &&
            (parsed[1]?.cmd === 313 || parsed[1]?.cmd === 308)
          ) {
            debug(
              "%c[Phom Monitor] Message cmd=313:",
              "color: orange;",
              parsed
            );
            const roomId = parsed[1]?.ri?.rid;
            if (roomId) {
              window.postMessage(
                { type: "PHOM_MONITOR_ROOMID", roomId: roomId },
                "*"
              );
            }
          }

          if (Array.isArray(parsed) && parsed.length === 2 && parsed[0] === 5) {
            if (parsed[1]?.cmd === 205 && Array.isArray(parsed[1]?.ps)) {
              window.postMessage({
                type: "PHOM_MONITOR_GAME_END"
              });
            }
          }

          if (Array.isArray(parsed) && parsed.length > 2 && parsed[0] === 4) {
            debug("%c[Phom Monitor] Message cmd=4:", "color: orange;", parsed);
            // user leave room
            window.postMessage({ type: "PHOM_MONITOR_USER_LEAVE" }, "*");
          }

          // Thông báo thao tác quá nhanh
          if (
            Array.isArray(parsed) &&
            (parsed.some(
              (item) =>
                typeof item === "string" &&
                item.includes(
                  "Bạn thực hiện thao tác quá nhanh. Vui lòng đợi..."
                )
            ) ||
              (parsed.length >= 2 &&
                parsed[1]?.mgs?.includes(
                  "Bạn thực hiện thao tác quá nhanh. Vui lòng đợi..."
                )))
          ) {
            alert("Bạn thực hiện thao tác quá nhanh. Vui lòng đợi...");
            window.postMessage({ type: "PHOM_MONITOR_MAX_ACTION" }, "*");
          }

          if (
            Array.isArray(parsed) &&
            parsed.length === 5 &&
            parsed[4] === "Phòng đầy"
          ) {
            window.postMessage({ type: "PHOM_MONITOR_USER_LEAVE" }, "*");
          }
        } catch (e) {
          debug("%c[Phom Monitor] Lỗi phân tích message:", "color: red;", e);
        }
      }
      ws.addEventListener("message", (event) => {
        const decodedData = decodeMessageData(event.data, "incoming");

        if (decodedData) {
          if (typeof decodedData === 'object' && Array.isArray(decodedData)) {
            const fakeEvent = { data: JSON.stringify(decodedData) };
            handleMessageData(fakeEvent);
          }
        }
      });

      const originalSend = ws.send;
      ws.send = function (data) {
        // debug("%c[Phom Monitor] Message gửi:", "color: purple;", data);
        // Decode outgoing message using common function
        const decodedData = decodeMessageData(data, "outgoing");
        debug("%c[Phom Monitor] Message gửi:", "color: purple;", decodedData);
        // Process decoded outgoing data
        if (decodedData && Array.isArray(decodedData)) {
          if (
            decodedData.length == 4 &&
            decodedData[0] === 6 &&
            decodedData[3]?.gid &&
            decodedData[3]?.cmd === 300
          ) {
            debug("%c[Phom Monitor] Vào game");
            window.postMessage(
              { type: "PHOM_MONITOR_GAME_ID", gameId: decodedData[3].gid },
              "*"
            );
          }
        }
        let dataToSend = data;
        if (typeof data === 'object' && data !== null && !(data instanceof Uint8Array)) {
          try {
            if (typeof MessagePack !== 'undefined' && MessagePack.encode) {
              dataToSend = MessagePack.encode(data);
            } else {
              dataToSend = JSON.stringify(data);
            }
          } catch (error) {
            debug("%c[Phom Monitor] Encoding error, sending original data:", "color: red;", error);
            dataToSend = data;
          }
        }
        return originalSend.call(this, dataToSend);
      };

      return ws;
    },
  });

  debug(
    "%c[Phom Monitor] Đã ghi đè WebSocket.",
    "color: orange; font-weight: bold;",
    new Date().toISOString()
  );
  const sendWebSocketMessage = function (message, options = {}) {
    const {
      retryCount = 0,
      maxRetries = 10,
      retryInterval = 1000,
      actionName = "action",
      onSuccess,
    } = options;

    const ws = window.phomMonitor.activeWebSocket;
    if (!ws || ws.readyState !== WebSocket.OPEN) {
      debug(
        `%c[Phom Monitor] WebSocket not ready, retry ${retryCount + 1
        }/${maxRetries}`,
        "color: red;"
      );

      if (retryCount < maxRetries) {
        setTimeout(() => {
          sendWebSocketMessage(message, {
            ...options,
            retryCount: retryCount + 1,
          });
        }, retryInterval);
      } else {
        debug(
          `%c[Phom Monitor] Failed to send after ${maxRetries} retries.`,
          "color: red; font-weight: bold;"
        );
      }
      return;
    }

    // Handle array of messages - encode if needed
    debug(
      `%c[Phom Monitor] Sending ${actionName} message:`,
      "color: green;",
      message
    );

    // Encode message before sending
    let dataToSend;
    if (typeof message === 'object' && message !== null) {
      try {
        // Try MessagePack encoding first if available
        if (typeof MessagePack !== 'undefined' && MessagePack.encode) {
          dataToSend = MessagePack.encode(message);
          debug(`%c[Phom Monitor] Encoded ${actionName} with MessagePack`, "color: blue;");
        } else {
          // Fallback to JSON
          dataToSend = JSON.stringify(message);
          debug(`%c[Phom Monitor] Encoded ${actionName} with JSON`, "color: blue;");
        }
      } catch (error) {
        debug(`%c[Phom Monitor] Encoding error for ${actionName}:`, "color: red;", error);
        dataToSend = JSON.stringify(message); // Safe fallback
      }
    } else {
      dataToSend = message;
    }

    ws.send(dataToSend);

    if (onSuccess) {
      onSuccess();
    }
  };

  window.sendJoinMessage = function (selectedTable, retryCount = 0) {
    const message = [
      6,
      "Simms",
      "channelPlugin",
      { cmd: 313, gid: 8, aid: 1, b: selectedTable.toString() },
    ];

    sendWebSocketMessage(message, {
      retryCount,
      actionName: "join table",
      onSuccess: () =>
        debug(
          "%c[Phom Monitor] Join message sent to table:",
          "color: green;",
          selectedTable
        ),
    });
  };

  window.sendLeaveMessage = function (roomId) {
    const messageOut = [4, "Simms", roomId];
    sendWebSocketMessage(messageOut, {
      maxRetries: 1,
      actionName: "leave room",
      onSuccess: () =>
        debug(
          "%c[Phom Monitor] Leave message sent for room:",
          "color: green;",
          roomId
        ),
    });
    const message2 = [6, "Simms", "channelPlugin", { cmd: 310 }];
    sendWebSocketMessage(message2, {
      maxRetries: 1,
      actionName: "leave room",
    });
  };

  window.createTableMessage = function (selectedTable) {
    const message = [
      6,
      "Simms",
      "channelPlugin",
      {
        cmd: 308,
        gid: 8,
        aid: 1,
        b: parseInt(selectedTable),
        Mu: 4,
        pwd: "",
        iJ: true,
      },
    ];

    sendWebSocketMessage(message, {
      maxRetries: 1,
      actionName: "create table",
      onSuccess: () =>
        debug(
          "%c[Phom Monitor] Create table message sent:",
          "color: green;",
          selectedTable
        ),
    });
  };

  window.joinRoomByIdMessage = function (roomId) {
    const message = [3, "Simms", roomId, "1234"];

    sendWebSocketMessage(message, {
      maxRetries: 1,
      actionName: "join room by id",
      onSuccess: () =>
        debug(
          "%c[Phom Monitor] Join room by ID message sent:",
          "color: green;",
          roomId
        ),
    });
  };

  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    if (event.data.type === "PHOM_MONITOR_JOIN") {
      debug("%c[Phom Monitor] Message từ popup:", "color: orange;", event.data);
      const table = event.data.selectedTable || "100";
      if (window.sendJoinMessage) {
        window.sendJoinMessage(table);
      }
    } else if (event.data.type === "PHOM_MONITOR_LEAVE") {
      debug("%c[Phom Monitor] Message từ popup:", "color: orange;", event.data);
      const roomId = event.data.roomId || "";
      if (window.sendLeaveMessage) {
        window.sendLeaveMessage(roomId);
      }
    } else if (event.data.type === "PHOM_MONITOR_CREATE_TABLE") {
      debug("%c[Phom Monitor] Message từ popup:", "color: orange;", event.data);
      const table = event.data.selectedTable || "100";
      if (window.createTableMessage) {
        window.createTableMessage(table);
      }
    } else if (event.data.type === "PHOM_MONITOR_JOIN_ROOMID") {
      debug("%c[Phom Monitor] Message từ popup:", "color: orange;", event.data);
      const roomId = event.data.roomId || "";
      if (window.joinRoomByIdMessage && roomId) {
        window.joinRoomByIdMessage(roomId);
      }
    } else if (event.data.type === "PHOM_BOT_MOVE") {
      debug("%c[Phom Monitor] Bot move:", "color: cyan;", event.data);
      const move = event.data.data;

      // Thực hiện nước đi của bot với commands mới
      if (move.action === 'play_phom') {
        const message = [6, "Simms", "channelPlugin", {
          cmd: 854,
          gid: 8,
          mes: move.combinations
        }];
        sendWebSocketMessage(message, {
          actionName: "bot play phom",
          onSuccess: () => debug("%c[Phom Monitor] Bot played phom:", "color: green;", move.combinations)
        });
      } else if (move.action === 'discard') {
        const message = [6, "Simms", "channelPlugin", {
          cmd: 851,
          gid: 8,
          dCs: move.cards[0]
        }];
        sendWebSocketMessage(message, {
          actionName: "bot discard",
          onSuccess: () => debug("%c[Phom Monitor] Bot discarded:", "color: green;", move.cards[0])
        });
      } else if (move.action === 'draw') {
        const message = [6, "Simms", "channelPlugin", {
          cmd: 853,
          gid: 8
        }];
        sendWebSocketMessage(message, {
          actionName: "bot draw",
          onSuccess: () => debug("%c[Phom Monitor] Bot drew card", "color: green;")
        });
      }
    }
  });
})();
