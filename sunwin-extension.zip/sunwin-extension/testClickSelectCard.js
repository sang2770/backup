function createDebugConsole() {
    try {
        const iframe = document.createElement("iframe");
        iframe.style.display = "none";
        (document.body || document.documentElement).appendChild(iframe);
        return iframe.contentWindow.console.log.bind(
            iframe.contentWindow.console
        );
    } catch (e) {
        console.error("[Phom Monitor] Lỗi tạo debug console:", e);
        return console.log.bind(console);
    }
}

const debug = createDebugConsole();

let myPlayedCards = new Set();


function parseCardSprite(spriteName) {
    if (!spriteName || spriteName === "Card_bc") {
        return { value: null, suit: null, hidden: true };
    }

    // Pattern: Card_[number][suit]
    const match = spriteName.match(/^Card_(\d+)([TCRB])$/);
    if (!match) {
        return { value: null, suit: null, error: `Invalid sprite: ${spriteName}` };
    }

    const value = parseInt(match[1]);
    const suitChar = match[2];

    // Mapping suit characters - Cập nhật theo chuẩn Việt Nam
    const suitMap = {
        'B': { name: 'Bích', symbol: '♠', emoji: '♠️', color: 'black' },  // Spades
        'T': { name: 'Chuồn (Tép)', symbol: '♣', emoji: '♣️', color: 'black' }, // Clubs
        'R': { name: 'Rô', symbol: '♦', emoji: '♦️', color: 'red' },      // Diamonds  
        'C': { name: 'Cơ', symbol: '♥', emoji: '❤️', color: 'red' },      // Hearts
    };

    // Convert number to display value
    let displayValue;
    if (value === 1) displayValue = 'A';
    else if (value === 11) displayValue = 'J';
    else if (value === 12) displayValue = 'Q';
    else if (value === 13) displayValue = 'K';
    else displayValue = value.toString();

    const suit = suitMap[suitChar] || { name: 'Unknown', symbol: '?', emoji: '❓', color: 'unknown' };

    return {
        value: value,
        displayValue: displayValue,
        suit: suit,
        suitChar: suitChar,
        cardName: `${displayValue}${suit.symbol}`,
        cardCode: `${value}${suitChar}`,
        hidden: false
    };
}

function findNodeByName(name) {
    return findNodeDeep(name, cc.director.getScene());
}

function findNodeDeep(name, node) {
    if (!node) return null;
    if (node.name === name) return node;
    for (let child of node.children) {
        const found = findNodeDeep(name, child);
        if (found) return found;
    }
    return null;
}

function getPlayerCards() {
    const cardNode = findNodeByName("card_node");
    if (!cardNode) {
        debug("Không tìm thấy card_node");
        return [];
    }

    const cards = [];
    const visibleCards = [];
    const hiddenCards = [];

    cardNode.children.forEach((cardChild, index) => {
        if (cardChild.name === "card" && cardChild.active) {
            const sprite = cardChild.getComponent(cc.Sprite);
            const spriteName = sprite?.spriteFrame?.name || "unknown";

            const cardInfo = parseCardSprite(spriteName);

            // Kiểm tra component thứ 3 để xác định bài thật
            const hasCardObject = cardChild._components &&
                cardChild._components[2] &&
                cardChild._components[2].card !== undefined;

            const cardData = {
                index: index + 1,
                sprite: spriteName,
                node: cardChild,
                position: {
                    x: Math.round(cardChild.position.x * 10) / 10,
                    y: Math.round(cardChild.position.y * 10) / 10
                },
                internalId: cardChild._components?.[1]?._internalId || 'unknown',
                hasCardObject: hasCardObject,
                ...cardInfo
            };

            cards.push(cardData);

            if (cardInfo.hidden) {
                hiddenCards.push(cardData);
            } else if (hasCardObject) {
                visibleCards.push(cardData);
            }
        }
    });

    // Log summary
    debug(`\n=== TỔNG KẾT QUÂN BÀI ===`);
    debug(`Tổng số quân bài: ${cards.length}`);
    debug(`Quân bài hiện: ${visibleCards.length}`);
    debug(`Quân bài ẩn: ${hiddenCards.length}`);

    if (visibleCards.length > 0) {
        debug(`\n📋 QUÂN BÀI TRONG TAY:`);
        visibleCards.forEach(card => {
            debug(`  ${card.index}. ${card.cardName} (${card.suit.name}) - ID: ${card.sprite} - Pos: (${card.position.x}, ${card.position.y})`);
        });
    }

    return {
        all: cards,
        visible: visibleCards,
        hidden: hiddenCards,
        summary: {
            total: cards.length,
            visible: visibleCards.length,
            hidden: hiddenCards.length
        }
    };
}

function clickCardLikeHand(cardNode) {
    const comp = cardNode._components.find(c =>
        typeof c.selected === "function" || typeof c.getSelected === "function"
    );

    if (!comp) {
        debug("❌ Không tìm thấy component xử lý chọn bài");
        return;
    }

    try {
        // Nếu card đã chọn rồi → bỏ chọn
        if (typeof comp.getSelected === "function" && comp.getSelected()) {
            comp.selected(false);
        } else {
            comp.selected(true); // chọn bài giống hệt click tay
        }

        debug("✅ Chọn bài giống tay thật:", cardNode.name);
    } catch (e) {
        debug("⚠ Lỗi khi chọn bài:", e);
    }
}


function clickCardByIndex(cardNumber) {
    const targets = getPlayerCards().visible;
    if (targets.length === 0) {
        debug("❌ Không có quân bài nào để click");
        return false;
    }

    if (cardNumber < 1 || cardNumber > targets.length) {
        debug(`❌ Số thứ tự quân bài không hợp lệ. Phải từ 1-${targets.length}`);
        return false;
    }

    clickCardByCoordinates(cardNumber);
    return true;
}

function clickCardBySprite(spriteName) {
    const targets = getPlayerCards().visible;
    if (targets.length === 0) {
        debug("❌ Không có quân bài nào để click");
        return false;
    }

    const targetCard = targets.find(card => card.sprite === spriteName);
    if (!targetCard) {
        debug(`❌ Không tìm thấy quân bài với sprite: ${spriteName}`);
        return false;
    }

    debug(`🎯 Click quân bài: ${targetCard.cardName} tại (${targetCard.position.x}, ${targetCard.position.y})`)
    return clickByCoordinates(targetCard.position.x, targetCard.position.y);
}




// Method to debug node structure and find click handlers
function debugNodeStructure(node, cardInfo = null) {
    debug(`\n🔍 DEBUG NODE STRUCTURE: ${node.name}`);
    debug(`📍 Position: (${node.position.x}, ${node.position.y})`);
    debug(`✅ Active: ${node.active}`);
    debug(`👁️ Visible: ${node.opacity > 0}`);

    if (cardInfo) {
        debug(`🃏 Card Info: ${cardInfo.cardName} (${cardInfo.suit.name})`);
    }

    // Check components
    if (node._components) {
        debug(`🧩 Components (${node._components.length}):`);
        node._components.forEach((comp, index) => {
            if (comp) {
                debug(`  [${index}] ${comp.constructor.name || 'Unknown'}`);

                // Check for click-related properties and methods
                const clickMethods = ['onClick', 'onTouch', 'selectCard', 'onCardClick', 'cardSelected', 'select', 'choose'];
                const foundMethods = clickMethods.filter(method => typeof comp[method] === 'function');
                if (foundMethods.length > 0) {
                    debug(`    🎯 Click methods: ${foundMethods.join(', ')}`);
                }

                // Check for card property
                if (comp.card !== undefined) {
                    debug(`    🃏 Has card property: ${JSON.stringify(comp.card)}`);
                }

                // Check Button component
                if (comp.constructor.name === 'cc.Button' || comp.interactable !== undefined) {
                    debug(`    🔘 Button component - enabled: ${comp.enabled}, interactable: ${comp.interactable}`);
                }
            }
        });
    }

    // Check event listeners
    if (node._eventProcessor && node._eventProcessor._listeners) {
        const listeners = node._eventProcessor._listeners;
        debug(`🎧 Event Listeners:`);
        Object.keys(listeners).forEach(eventType => {
            if (listeners[eventType] && listeners[eventType].length > 0) {
                debug(`  ${eventType}: ${listeners[eventType].length} listeners`);
            }
        });
    }

    // Check parent node
    if (node.parent) {
        debug(`👨‍👩‍👧‍👦 Parent: ${node.parent.name}`);
    }

    return node;
}

function getClickableCards() {
    const playerCards = getPlayerCards();
    if (!playerCards.visible || playerCards.visible.length === 0) {
        debug("❌ Không có quân bài nào để click");
        return [];
    }

    debug(`\n🎮 DANH SÁCH QUÂN BÀI CÓ THỂ CLICK:`);

    const cardNode = findNodeByName("card_node");
    if (cardNode) {
        playerCards.visible.forEach((card, index) => {
            debug(`\n  ${card.index}. ${card.cardName} (${card.suit.name}) - Vị trí: (${card.position.x}, ${card.position.y})`);

            // Find the actual node for this card
            const cardChild = cardNode.children[card.index - 1];
            if (cardChild) {
                debugNodeStructure(cardChild, card);
            }
        });
    }

    return playerCards.visible;
}

// Click by coordinates function
function clickByCoordinates(x, y, elementType = 'canvas') {
    debug(`🎯 Click bằng tọa độ: (${x}, ${y}) trên ${elementType}`);

    try {
        // Method 1: Canvas click simulation
        const canvas = document.querySelector('canvas');
        if (canvas) {
            const rect = canvas.getBoundingClientRect();

            // Convert game coordinates to screen coordinates
            const screenX = rect.left + rect.width / 2 + x;
            const screenY = rect.top + rect.height / 2 - y; // Y axis is inverted in canvas

            debug(`📍 Screen coordinates: (${screenX}, ${screenY})`);

            // Create mouse events
            const mouseDown = new MouseEvent('mousedown', {
                bubbles: true,
                cancelable: true,
                clientX: screenX,
                clientY: screenY,
                button: 0
            });

            const mouseUp = new MouseEvent('mouseup', {
                bubbles: true,
                cancelable: true,
                clientX: screenX,
                clientY: screenY,
                button: 0
            });

            const click = new MouseEvent('click', {
                bubbles: true,
                cancelable: true,
                clientX: screenX,
                clientY: screenY,
                button: 0
            });

            // Dispatch events
            canvas.dispatchEvent(mouseDown);
            setTimeout(() => {
                canvas.dispatchEvent(mouseUp);
                canvas.dispatchEvent(click);
            }, 50);

            debug(`✅ Đã click canvas tại tọa độ (${x}, ${y})`);
            return true;
        }
    } catch (error) {
        debug(`❌ Canvas click failed: ${error}`);
    }

    // Method 2: Touch events simulation
    try {
        const canvas = document.querySelector('canvas');
        if (canvas) {
            const rect = canvas.getBoundingClientRect();
            const screenX = rect.left + rect.width / 2 + x;
            const screenY = rect.top + rect.height / 2 - y;

            const touch = new Touch({
                identifier: 1,
                target: canvas,
                clientX: screenX,
                clientY: screenY,
                pageX: screenX,
                pageY: screenY,
                screenX: screenX,
                screenY: screenY
            });

            const touchStart = new TouchEvent('touchstart', {
                bubbles: true,
                cancelable: true,
                touches: [touch],
                targetTouches: [touch],
                changedTouches: [touch]
            });

            const touchEnd = new TouchEvent('touchend', {
                bubbles: true,
                cancelable: true,
                touches: [],
                targetTouches: [],
                changedTouches: [touch]
            });

            canvas.dispatchEvent(touchStart);
            setTimeout(() => {
                canvas.dispatchEvent(touchEnd);
            }, 50);

            debug(`✅ Đã touch canvas tại tọa độ (${x}, ${y})`);
            return true;
        }
    } catch (error) {
        debug(`❌ Touch events failed: ${error}`);
    }

    return false;
}

// Click card by coordinates
function clickCardByCoordinates(cardNumber) {
    debug(`\n📍 Click quân bài số ${cardNumber} bằng tọa độ`);

    const playerCards = getPlayerCards();
    if (!playerCards.visible || playerCards.visible.length === 0) {
        debug("❌ Không có quân bài nào hiện tại");
        return false;
    }

    if (cardNumber < 1 || cardNumber > playerCards.visible.length) {
        debug(`❌ Số thứ tự quân bài không hợp lệ. Phải từ 1-${playerCards.visible.length}`);
        return false;
    }

    const card = playerCards.visible[cardNumber - 1];
    debug(`🎯 Click quân bài: ${card.cardName} tại (${card.position.x}, ${card.position.y})`);

    return clickByCoordinates(card.position.x, card.position.y);
}


function logNodeTree(node, indent = 0) {
    const prefix = ' '.repeat(indent * 2); // mỗi cấp cách ra 2 dấu cách
    debug(`${prefix}- ${node.name}`);

    node.children.forEach(child => {
        logNodeTree(child, indent + 1);
    });
}

logNodeTree(cc.director.getScene());