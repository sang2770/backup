const cardNode = window.phomBot.findNodeByName("card_node")
    .children[targetCard.index - 1];

const selectNode = cardNode.getChildByName("card_select1");

selectNode.emit("click");