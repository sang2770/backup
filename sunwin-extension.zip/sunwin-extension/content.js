(function () {
  // Constants
  const LOG_PREFIX = "[Phom Monitor]";

  // Global variables
  window.isJoiningLoop = false;
  window.isCreatingLoop = false;
  window.gold = 0;
  window.userKey = null;
  window.isPlaying = false;
  window.leaveRequested = false;

  window.joinTableTimeout = null;
  window.joinTableTimeoutCnt = 0;
  window.createTableTimeoutCnt = 0;
  window.checkTimeout = null;
  window.leaveTimeout = null;
  window.gameId = null;

  window.isCreatingBotLoop = false;
  window.botTurn = 0;

  // Helper functions
  const log = (message, data) => {
    console.log(LOG_PREFIX, message, data || "");
  };

  const saveToStorage = (data, callback) => {
    chrome.storage.local.set(data, callback);
  };

  const saveSettings = ({
    joinDelay,
    checkDelay,
    selectedTable,
    systemKeys,
    botMode
  }) => {
    saveToStorage({ joinDelay, checkDelay, selectedTable, systemKeys, botMode }, () => {
      log("Settings saved!", {
        joinDelay,
        checkDelay,
        selectedTable,
        systemKeys,
        botMode,
      });
      chrome.runtime.sendMessage({
        action: "settingsSaved",
        data: { joinDelay, checkDelay, selectedTable, systemKeys, botMode },
      });

      window.postMessage(
        {
          type: "PHOM_BOT_TOGGLE",
          data: { enabled: botMode },
        },
        "*"
      );
    });
  };

  // Inject inline script
  function injectScript(name) {
    const script = document.createElement("script");
    script.src = chrome.runtime.getURL(name);
    script.onload = () => script.remove();
    (document.head || document.documentElement).appendChild(script);
    log("Injected inline script at:", name, new Date().toISOString());
  }

  // Inject msgpack library first, then the main inject script
  function injectScriptsSequentially() {
    const msgpackScript = document.createElement("script");
    msgpackScript.src = chrome.runtime.getURL("msgpack.min.js");
    msgpackScript.onload = () => {
      msgpackScript.remove();
      log("Injected msgpack library");
      // Inject main script after msgpack is loaded
      injectScript("inject.js");
      injectScript("phom-bot.js");
      injectScript("phom-analyzer.js");
    };
    (document.head || document.documentElement).appendChild(msgpackScript);
  }

  // Start injection
  injectScriptsSequentially();

  // Create debug console
  const debug = createDebugConsole();

  function createDebugConsole() {
    try {
      const iframe = document.createElement("iframe");
      iframe.style.display = "none";
      (document.body || document.documentElement).appendChild(iframe);
      return iframe.contentWindow.console.log.bind(
        iframe.contentWindow.console
      );
    } catch (e) {
      console.error(`${LOG_PREFIX} Lỗi tạo debug console:`, e);
      return () => { };
    }
  }

  // Handle room data
  function handleRoomData(roomData) {
    debug(
      `${LOG_PREFIX} Nhận được roomData: `, roomData
    )
    if (window.isPlaying) {
      debug(
        "%c[Phom Monitor] Người chơi đang chơi. Không thực hiện các tác vụ.",
        "color: red;"
      );
      return;
    }
    if (!window.isJoiningLoop && !window.isCreatingBotLoop) {
      debug(
        "%c[Phom Monitor] Quá trình vào bàn chưa bắt đầu hoặc đã dừng.",
        "color: orange;"
      );
      return;
    }
    if (window.leaveRequested) {
      debug(
        "%c[Phom Monitor] Đang chờ rời bàn. Không xử lý roomData.",
        "color: orange;"
      );
      return;
    }
    if (window.checkTimeout) {
      debug(
        "%c[Phom Monitor] Đã có lịch check. Không tạo thêm checkTimeout.",
        "color: orange;"
      );
      return;
    }
    chrome.storage.local.get(
      ["systemKeys", "checkDelay", "selectedTable"],
      ({ systemKeys = [], checkDelay = 3000, selectedTable = "100" }) => {
        if (
          ![
            "100",
            "500",
            "1000",
            "2000",
            "5000",
            "10000",
            "20000",
            "50000",
            "100000",
            "200000",
            "500000",
            "1000000",
            "2000000",
            "5000000",
            "10000000",
          ].includes(selectedTable)
        ) {
          debug("%c[Phom Monitor] Bàn không hợp lệ.", "color: red;");
          return;
        }
        const actualCheckDelay = Math.max(4000, checkDelay);
        debug(
          `${LOG_PREFIX} Kiểm tra sau ${actualCheckDelay}ms.`,
          new Date().toISOString()
        );

        window.checkTimeout = setTimeout(() => {
          if (window.isPlaying) {
            debug(
              "%c[Phom Monitor] Người chơi đang chơi. Không thực hiện các tác vụ.",
              "color: red;"
            );
            return;
          }
          if (shouldStayInRoom(roomData, systemKeys)) {
            debug("%c[Phom Monitor] Check: Ở lại bàn.", "color: orange;");
            window.websocket.sendUserStatus(
              window.userKey + "ở lại bàn. Dừng quá trình."
            );
          } else {
            debug("%c[Phom Monitor] Check: Rời bàn.", "color: orange;");
            leaveTable();
          }
        }, actualCheckDelay);
      }
    );
  }

  function joinGame(callBack) {
    window.callBackAfterJoinGame = callBack;
    injectScript("autoJoinGame.js");
  }

  function shouldStayInRoom(roomData, systemKeys) {
    if (window.isCreatingBotLoop) {
      if (roomData.ps && roomData.ps.length >= 3) {
        return false;
      }
      return true;
    }
    debug(
      `${LOG_PREFIX} systemKeys=${systemKeys}`,
      new Date().toISOString()
    );
    const userKey = window.userKey;
    const players = roomData.ps || [];
    const hostPlayer = players.find((p) => p.C === true);
    const hostKey = hostPlayer?.dn || null;
    const playingKeys = players.filter((p) => p.pi).map((p) => p.dn);
    if (!playingKeys.length) return false;
    const hasStrangeKey = playingKeys.some((key) => !systemKeys.includes(key));
    const hasSystemKeyPlaying = playingKeys.some((key) =>
      systemKeys.includes(key)
    );
    const isCurrentTabInGame = players.map((p) => p.dn).includes(userKey);
    debug(
      `${LOG_PREFIX} hostKey=${hostKey}, isHostSystemKey=${systemKeys.includes(
        hostKey
      )}, hasStrangeKey=${hasStrangeKey}, hasSystemKey=${hasSystemKeyPlaying}, playerKeys=${players.map(
        (p) => p.dn
      )}, playingKeys=${playingKeys}`
    );
    if (!isCurrentTabInGame) {
      return false;
    }

    return (
      (hostKey && systemKeys.includes(hostKey) && hasStrangeKey) ||
      (hostKey && !systemKeys.includes(hostKey) && hasSystemKeyPlaying)
    );
  }

  function createTableWithSelectedTable(selectedTable) {
    const tryCreateTable = () => {
      debug(
        `${LOG_PREFIX} Tạo bàn với số tiền: ${selectedTable}`,
        new Date().toISOString()
      );
      const currentBet = config.createTable.range.default;
      const targetBet = parseInt(selectedTable);
      const listAvailableBet = [
        100, 500, 1000, 2000, 5000, 10000, 20000, 50000, 100000, 200000, 500000,
        1000000, 2000000, 5000000, 10000000,
      ];
      const currentIndex = listAvailableBet.indexOf(currentBet);
      if (!listAvailableBet.includes(targetBet) || currentIndex === -1) {
        debug("%c[Phom Monitor] Bàn không hợp lệ.", "color: red;");
        return;
      }
      window.postMessage(
        { type: "PHOM_MONITOR_CREATE_TABLE", selectedTable: targetBet },
        "*"
      );
    };

    tryCreateTable();

    let checkInterval = setInterval(() => {
      if (window.roomId) {
        debug(
          `${LOG_PREFIX} Tạo bàn thành công với số tiền: ${selectedTable}, roomId: ${window.roomId}`,
          new Date().toISOString()
        );
        clearInterval(checkInterval);
        checkInterval = null;
        return;
      } else {
        debug(
          `${LOG_PREFIX} Chưa có roomId, kiểm tra lại...`,
          new Date().toISOString()
        );
        window.createTableTimeoutCnt += 1;
        if (window.createTableTimeoutCnt > 3) {
          debug(
            "%c[Phom Monitor] Đã thử quá 3 lần, reload trang.",
            "color: red;"
          );
          clearInterval(checkInterval);
          checkInterval = null;
          window.location.reload();
          return;
        }
        tryCreateTable();
      }
    }, 2000);
  }

  function createTableBot(selectedTable) {
    window.isCreatingBotLoop = true;
    createTableWithSelectedTable(selectedTable);
    debug(
      `${LOG_PREFIX} Tạo bàn bot lần thứ: ${window.botTurn}`,
      new Date().toISOString()
    );
  }

  function createTable(selectedTable) {
    window.isCreatingLoop = true;
    createTableWithSelectedTable(selectedTable);
  }

  function leaveTable() {
    if (window.isPlaying) {
      debug(
        "%c[Phom Monitor] Người chơi đang chơi. Không thực hiện các tác vụ.",
        "color: red;"
      );
      window.isJoiningLoop = false;
      window.isCreatingLoop = false;
      window.isCreatingBotLoop = false;
      return;
    }

    if (window.roomId && !window.leaveRequested) {
      window.leaveRequested = true;
      debug("%c[Phom Monitor] LeaveTable - Rời bàn: " + window.roomId, "color: red;");
      injectScript("autoLeaveTable.js");

      // Safety timeout: Reset leave status after 5s if no confirmation received
      if (window.leaveTimeout) clearTimeout(window.leaveTimeout);
      window.leaveTimeout = setTimeout(() => {
        if (window.leaveRequested) {
          debug("%c[Phom Monitor] LeaveTable - Quá 5s chưa nhận xác nhận rời bàn. Tự động reset trạng thái.", "color: red;");
          window.roomId = null;
          window.leaveRequested = false;
          window.isPlaying = false;
        }
      }, 5000);
      return;
    } else {
      debug("%c[Phom Monitor] Không có roomId hoặc đã yêu cầu rời bàn (leaveRequested=" + window.leaveRequested + ").", "color: orange;");
      return;
    }
  }

  window.joinTable = function () {
    if (window.isPlaying) {
      debug(
        "%c[Phom Monitor] Người chơi đang chơi. Không thực hiện các tác vụ.",
        "color: red;"
      );
      window.isJoiningLoop = false;
      window.isCreatingLoop = false;
      window.isCreatingBotLoop = false;
      return;
    }
    chrome.storage.local.get(
      ["joinDelay", "selectedTable"],
      ({ joinDelay = 3000, selectedTable = "100" }) => {
        debug(
          `${LOG_PREFIX} Đã nhận được thông tin vào bàn: ${selectedTable}, số tiền: ${window.gold}`,
          new Date().toISOString()
        );
        if (window.gold < parseInt(selectedTable) * 10) {
          debug("%c[Phom Monitor] Không đủ số dư để vào bàn.", "color: red;");
          alert(
            "Không đủ số dư để vào bàn. Vui lòng nạp thêm tiền vào tài khoản."
          );
          window.isJoiningLoop = false;
          window.joinTableTimeout = null;
          window.isCreatingLoop = false;
          window.isCreatingBotLoop = false;
          return;
        }
        function tryJoin() {
          if (!window.isJoiningLoop) {
            debug(
              "%c[Phom Monitor] Đã dừng quá trình vào bàn.",
              "color: orange;"
            );
            return;
          }
          if (window.roomId) {
            debug(
              "%c[Phom Monitor] Đã có roomId. Chờ thoát bàn",
              "color: orange;"
            );
            return;
          }

          if (window.joinTableTimeout) {
            debug(
              "%c[Phom Monitor] Quá trình vào bàn trước chưa hoàn tất",
              "color: orange;"
            );
            return;
          } else {
            window.postMessage(
              { type: "PHOM_MONITOR_JOIN", selectedTable },
              "*"
            );
          }

          window.joinTableTimeout = setTimeout(() => {
            if (!window.roomId) {
              debug(
                "%c[Phom Monitor] Không tìm thấy roomId sau 3s. Thử lại sau " +
                joinDelay +
                "ms.",
                "color: orange;"
              );
              if (window.joinTableTimeoutCnt > 3) {
                debug(
                  "%c[Phom Monitor] Đã thử quá 3 lần, reload trang.",
                  "color: red;"
                );
                window.location.reload();
                return;
              }
              window.joinTableTimeoutCnt++;
              window.joinTableTimeout = null;
              setTimeout(tryJoin, joinDelay);
            }
          }, 3000);
        }
        if (!window.joinTableTimeout) {
          window.joinTableTimeoutCnt = 0;
        }
        setTimeout(tryJoin, Math.max(4000, joinDelay));
      }
    );
  };

  window.stopJoinTable = function () {
    debug("%c[Phom Monitor] Dừng", "color: orange;");
    if (window.isCreatingLoop) {
      debug("%c[Phom Monitor] Đã dừng quá trình tạo bàn.", "color: orange;");
    }
    if (window.isJoiningLoop) {
      debug("%c[Phom Monitor] Đã dừng quá trình vào bàn.", "color: orange;");
    }
    if (window.isCreatingBotLoop) {
      debug("%c[Phom Monitor] Đã dừng quá trình tạo bàn bot.", "color: orange;");
    }
    window.isCreatingLoop = false;
    window.isJoiningLoop = false;
    window.isCreatingBotLoop = false;
  };

  window.createTable = function () {
    chrome.storage.local.get(["selectedTable"], ({ selectedTable = "100" }) => {
      createTable(selectedTable);
    });
  };

  window.createTableBot = function () {
    chrome.storage.local.get(["selectedTable"], ({ selectedTable = "100" }) => {
      createTableBot(selectedTable);
    });
  };

  window.leaveTable = leaveTable;

  window.joinRoomById = function (roomId) {
    if (window.isPlaying) {
      debug(
        "%c[Phom Monitor] Người chơi đang chơi. Không thực hiện các tác vụ.",
        "color: red;"
      );
      return;
    }

    if (!roomId) {
      debug("%c[Phom Monitor] Không có roomId.", "color: red;");
      return;
    }

    debug(`${LOG_PREFIX} Vào bàn theo ID: ${roomId}`, new Date().toISOString());
    window.postMessage({ type: "PHOM_MONITOR_JOIN_ROOMID", roomId }, "*");
  };

  // Load configuration and initialize WebSocket
  let config;
  fetch(chrome.runtime.getURL("config.json"))
    .then((response) => response.json())
    .then((data) => {
      config = data;
      // Initialize WebSocket with message handler
      window.websocket.connect((message) => {
        if (message.action === "saveSettings") {
          saveSettings(message);
        } else if (
          ["joinTable", "leaveTable", "createTable", "stopJoinTable", "createTableBot"].includes(
            message.action
          )
        ) {
          const actions = {
            joinTable: window.joinTable,
            stopJoinTable: window.stopJoinTable,
            createTable: window.createTable,
            leaveTable: window.leaveTable,
            createTableBot: window.createTableBot,
          };

          if (!window.gameId) {
            debug(
              "%c[Phom Monitor] Không có gameId. Vui lòng đăng nhập.",
              "color: red;"
            );
            joinGame(message.action);
            return true;
          }

          if (message.action === "leaveTable") {
            if (window.isCreatingLoop) {
              debug(
                "%c[Phom Monitor] Đã dừng quá trình tạo bàn.",
                "color: orange;"
              );
            }
            window.isCreatingLoop = false;

            if (window.isCreatingBotLoop) {
              debug(
                "%c[Phom Monitor] Đã dừng quá trình tạo bàn bot.",
                "color: orange;"
              );
              window.isCreatingBotLoop = false;
            }
          }

          if (message.action === "joinTable" && window.isJoiningLoop) {
            debug(
              "%c[Phom Monitor] Quá trình vào bàn đang chạy.",
              "color: orange;"
            );
            return;
          }

          if (message.action === "createTable" && window.isCreatingLoop) {
            debug(
              "%c[Phom Monitor] Quá trình vào bàn đang chạy.",
              "color: orange;"
            );
            return;
          }

          if (message.action === "createTableBot" && window.isCreatingBotLoop) {
            debug(
              "%c[Phom Monitor] Quá trình tạo bàn bot đang chạy.",
              "color: orange;"
            );
            return;
          }

          if (message.action === "joinTable") {
            window.isJoiningLoop = true;
          }
          if (window.isPlaying) {
            debug(
              "%c[Phom Monitor] Người chơi đang chơi. Không thực hiện các tác vụ.",
              "color: red;"
            );
            return;
          }
          if (actions[message.action]) {
            actions[message.action]();
          }
        }
      });
    });

  // Handle window messages
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    if (event.data.type === "PHOM_MONITOR_INIT") {
      window.botTurn += 1;
      window.isPlaying = true;
    } else if (event.data.type === "PHOM_MONITOR_ROOMDATA") {
      handleRoomData(event.data.roomData);
    } else if (event.data.type === "PHOM_MONITOR_GAME_END") {
      debug(
        "%c[Phom Monitor] Trò chơi kết thúc.",
        "color: orange;"
      )
      window.isPlaying = false;
      // if (window.isCreatingBotLoop || window.isCreatingLoop) {
      //   window.leaveTable();
      // }
    } else if (event.data.type === "PHOM_MONITOR_ROOMID") {
      if (window.roomId === event.data.roomId) {
        debug(
          "%c[Phom Monitor] Đã nhận được trùng roomId. Không thực hiện các tác vụ.",
          "color: orange;"
        );
        return;
      }
      if (window.roomId && event.data.roomId !== window.roomId) {
        debug(
          "%c[Phom Monitor] xung đột roomId. Rời bàn: " + window.roomId,
          "color: red;"
        );
        window.postMessage(
          { type: "PHOM_MONITOR_LEAVE", roomId: window.roomId },
          "*"
        );
      }
      if (window.joinTableTimeout) {
        clearTimeout(window.joinTableTimeout);
        window.joinTableTimeout = null;
        window.joinTableTimeoutCnt = 0;
      }
      const roomId = event.data.roomId;
      debug(`${LOG_PREFIX} Đã nhận roomId mới: ${roomId}`);
      window.roomId = roomId;
    } else if (event.data.type === "PHOM_MONITOR_MAX_ACTION") {
      debug(`${LOG_PREFIX} Thao tác quá nhanh. Dừng quá trình vào bàn.`);
      window.roomId = null;
      window.isJoiningLoop = false;
      window.isCreatingLoop = false;
      window.isCreatingBotLoop = false;
      window.isPlaying = false;
      window.leaveRequested = false;
    } else if (event.data.type === "PHOM_MONITOR_GOLD_UPDATE") {
      window.gold = isNaN(Number(event.data.data.gold))
        ? 0
        : Number(event.data.data.gold);
      window.userKey = event.data.data.userKey;
      debug(
        `${LOG_PREFIX} Đã nhận số dư mới: ${window.gold}`,
        new Date().toISOString()
      );
      debug(
        `${LOG_PREFIX} Đã nhận userKey mới: ${window.userKey}`,
        new Date().toISOString()
      );
      if (window.userKey) {
        window.websocket.sendUserKey(window.userKey);
      }
    } else if (event.data.type === "PHOM_MONITOR_WS_READY") {
      debug(`${LOG_PREFIX} WebSocket đã sẵn sàng từ inject.js`);
    } else if (event.data.type === "PHOM_MONITOR_USER_LEAVE") {
      debug(
        "%c[Phom Monitor] Người chơi rời bàn." + window.roomId,
        "color: orange;"
      );
      window.isPlaying = false;
      window.roomId = null;
      window.leaveRequested = false;
      if (window.checkTimeout) {
        clearTimeout(window.checkTimeout);
        window.checkTimeout = null;
      }
      if (window.leaveTimeout) {
        clearTimeout(window.leaveTimeout);
        window.leaveTimeout = null;
      }
      chrome.storage.local.get(["joinDelay"], ({ joinDelay = 3000 }) => {
        const actualJoinDelay = Math.max(4000, joinDelay);
        if (window.isCreatingLoop) {
          setTimeout(() => {
            debug(
              "%c[Phom Monitor] Thực hiện lại quá trình tạo bàn sau " + actualJoinDelay + "ms.",
              "color: orange;"
            );
            if (!window.isCreatingLoop) return;
            window.createTable();
          }, actualJoinDelay);
        }
        else if (window.isCreatingBotLoop) {
          setTimeout(() => {
            debug(
              "%c[Phom Monitor] Thực hiện lại quá trình tạo bàn bot sau " + actualJoinDelay + "ms.",
              "color: orange;"
            );
            if (!window.isCreatingBotLoop) return;
            window.createTableBot();
          }, actualJoinDelay);
        }
        else if (window.isJoiningLoop) {
          setTimeout(() => {
            if (!window.isJoiningLoop) {
              debug(
                "%c[Phom Monitor] Đã dừng quá trình vào bàn.",
                "color: orange;"
              );
              return;
            }
            debug(
              "%c[Phom Monitor] Thực hiện lại quá trình vào bàn sau " + actualJoinDelay + "ms.",
              "color: orange;"
            );
            window.joinTable();
          }, actualJoinDelay);
        }
      });
    } else if (event.data.type === "PHOM_MONITOR_GAME_ID") {
      debug(
        `${LOG_PREFIX} Đã nhận gameId mới: ${event.data.gameId}`,
        new Date().toISOString()
      );
      window.gameId = event.data.gameId;
      if (window.callBackAfterJoinGame) {
        if (window.callBackAfterJoinGame === "joinTable") {
          window.isJoiningLoop = true;
        }
        setTimeout(() => {
          window[callBackAfterJoinGame]();
          window.callBackAfterJoinGame = null;
        }, 1500);
      }
    } else if (event.data.type === "PHOM_MONITOR_MUST_LEAVE") {
      debug(
        "%c[Phom Monitor] Bị yêu cầu rời bàn bởi hệ thống.",
        "color: red;"
      );
      leaveTable();
    }
  });

  // Handle messages from popup
  chrome.runtime.onMessage.addListener((msg, _, sendResponse) => {
    // debug("action: " + msg.action, "color: orange;");
    switch (msg.action) {
      case "saveSettings":
        saveSettings(msg.data);
        sendResponse({ success: true });
        break;
      case "sendUserKey":
        if (msg.userKey) {
          const success = window.websocket.sendUserKey(msg.userKey);
          sendResponse({ success });
        } else {
          sendResponse({ success: false, error: "No userKey provided" });
        }
        break;
      case "executeContentScript":
        debug("functionName: " + msg.functionName, "color: orange;");

        if (msg.functionName) {
          const actions = {
            joinTable: window.joinTable,
            stopJoinTable: window.stopJoinTable,
            createTable: window.createTable,
            leaveTable: window.leaveTable,
            createTableBot: window.createTableBot,
          };

          if (window.isPlaying) {
            debug(
              "%c[Phom Monitor] Người chơi đang chơi. Không thực hiện các tác vụ.",
              "color: red;"
            );
            sendResponse({ status: "Player is playing" });
            return true;
          }
          if (!window.userKey) {
            sendResponse({ status: "No userKey provided" });
            return true;
          }

          if (actions[msg.functionName]) {
            if (!window.gameId) {
              debug(
                "%c[Phom Monitor] Không có gameId. Vui lòng đăng nhập.",
                "color: red;"
              );
              sendResponse({ status: "No gameId provided!. Auto Join game" });
              joinGame(msg.functionName);
              return true;
            }
            if (msg.functionName === "leaveTable") {
              if (window.isCreatingLoop) {
                debug(
                  "%c[Phom Monitor] Đã dừng quá trình tạo bàn.",
                  "color: orange;"
                );
              }
              window.isCreatingLoop = false;

              if (window.isCreatingBotLoop) {
                debug(
                  "%c[Phom Monitor] Đã dừng quá trình tạo bàn bot.",
                  "color: orange;"
                );
                window.isCreatingBotLoop = false;
              }
            }

            if (msg.functionName === "joinTable" && window.isJoiningLoop) {
              debug(
                "%c[Phom Monitor] Quá trình vào bàn đang chạy.",
                "color: orange;"
              );
              return;
            }

            if (msg.functionName === "createTable" && window.isCreatingLoop) {
              debug(
                "%c[Phom Monitor] Quá trình vào bàn đang chạy.",
                "color: orange;"
              );
              return;
            }

            if (msg.functionName === "createTableBot" && window.isCreatingBotLoop) {
              debug(
                "%c[Phom Monitor] Quá trình tạo bàn bot đang chạy.",
                "color: orange;"
              );
              return;
            }
            if (msg.functionName === "joinTable") {
              window.isJoiningLoop = true;
            }
            if (actions[msg.functionName]) {
              actions[msg.functionName]();
            }
            sendResponse({ status: `${msg.functionName} executed` });
          } else {
            sendResponse({ status: `${msg.functionName} not found` });
          }
        } else {
          sendResponse({ success: false, error: "Missing functionName" });
        }
        break;
      case "checkWebSocketStatus":
        sendResponse({ connected: window.websocket.checkStatus() });
        break;
      default:
        sendResponse({ success: false, error: "Unknown action" });
    }
    return true;
  });
})();
