/**
 * PHOM AUTO BOT - Smart Discard Strategy System
 *
 * ARCHITECTURE:
 * 1. phom-analyzer.js: Phân tích messages từ inject.js và gửi analyzed data cho bot
 * 2. phom-bot.js: Nhận analyzed data từ analyzer và thực hiện actions
 *
 * MESSAGE FLOW:
 * inject.js → analyzer (phân tích) → bot (quyết định + action)
 *
 * Bot chỉ focus vào:
 * - Tính toán optimal discard dựa trên 5 factors
 * - Click buttons khi chúng available
 * - Human-like behavior simulation
 */
(function () {
  // Card constants and utilities
  const SUITS = ["♠", "♣", "♦", "♥"];
  const VALUES = [
    "A",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "10",
    "J",
    "Q",
    "K",
  ];

  function createDebugConsole() {
    try {
      const iframe = document.createElement("iframe");
      iframe.style.display = "none";
      (document.body || document.documentElement).appendChild(iframe);
      return iframe.contentWindow.console.log.bind(
        iframe.contentWindow.console
      );
    } catch (e) {
      console.error("[Phom Monitor] Lỗi tạo debug console:", e);
      return console.log.bind(console);
    }
  }

  const debug = createDebugConsole();

  class PhomBot {
    constructor() {
      this.myCards = new Set();
      this.myPlayedCards = new Set();
      this.opponentPlayedCards = new Set();
      this.gameHistory = [];
      this.isEnabled = true;
      this.difficulty = "hard"; // Always hard - maximum performance
      this.playDelay = { min: 2000, max: 5000 }; // Random delay to seem human
      this.currentGameId = null;
      this.myTurn = false;
      this.intervalId = null;
      this.startCheckIntervalId = null; // Track onStartGameCheck interval to prevent leaks
      this.fallbackIntervalId = null; // Fallback for missed MY_TURN events
      this.lastAction = null;
      this.tryStartCnt = 0;
      this.cardSelected = null;
      this.numberOfPlayers = 1; // Default is me
      this.lastDiscardedCard = null; // Track my last discard
      this.timesMyCardEaten = 0; // Track anti "Đền Làng"
      this.isProcessingTurn = false; // Lock for concurrency protection

      // Advanced analytics
      this.cardProbabilities = this.initCardProbabilities();
      this.opponentPatterns = new Map();
      this.winningCombinations = [];
      this.handAnalysis = null;
      this.currentStrategy = "balanced"; // balanced, aggressive, defensive
      this.temporaryStrategy = null;

      // Opponent analysis from analyzer
      this.opponentAnalysis = new Map(); // Thông tin phân tích đối thủ từ analyzer
      // Session tracking for table-stay logic
      this.gamesPlayedAtTable = 0;
      this.maxGamesAtTable = 0; // 0 means no limit (Rule 1)

      this.init();
    }

    // Helper method to get Cocos2D scene safely
    getScene() {
      if (typeof cc === "undefined" || !cc.director) {
        return null;
      }
      return cc.director.getScene();
    }

    // Helper method to check if Cocos2D is available
    isCocosAvailable() {
      return typeof cc !== "undefined" && cc.director;
    }

    // Get all visible cards perfectly: My hand, My played, Opponents played, Eaten cards
    getAllVisibleCards() {
      const visible = new Set([
        ...(this.myCards || []),
        ...(this.myPlayedCards || []),
        ...(this.opponentPlayedCards || [])
      ]);

      // Thêm các bài đối thủ đã ăn vào danh sách bài chết
      if (this.opponentAnalysis) {
        for (const data of this.opponentAnalysis.values()) {
          if (data.eatenCards) {
            data.eatenCards.forEach(c => visible.add(c));
          }
        }
      }

      return visible;
    }

    // Utility function to replace setTimeout with async/await
    sleep(ms) {
      return new Promise((resolve) => setTimeout(resolve, ms));
    }

    init() {
      this.setupEventListeners();
      this.loadSettings();
      if (this.isEnabled) {
        this.startFallbackInterval();
      }
      debug("[Phom Bot] Initialized with advanced card analysis");
    }

    setupEventListeners() {
      window.addEventListener("message", (event) => {
        if (event.source !== window) return;
        const { type, data, eventType } = event.data;
        // Chỉ lắng nghe messages từ analyzer và bot controls
        switch (type) {
          case "PHOM_BOT_TOGGLE":
            const isEnabled = data ? data.enabled : event.data.enabled;
            if (isEnabled !== undefined) {
              this.toggleBot(isEnabled);
            }
            break;
          case "PHOM_BOT_SETTINGS":
            if (data) {
              this.updateSettings(data);
            }
            break;
          case "PHOM_ANALYZER_EVENT":
            // Messages từ analyzer (thông tin đã được phân tích)
            this.handleAnalyzerEvent(eventType, data);
            break;
          case "PHOM_MONITOR_MY_PHOM":
            // Handle my phom combinations - remove cards from hand
            this.handleMyPhomCombinations(data);
            break;
          case "PHOM_MONITOR_OPPONENT_PHOM":
            // Handle opponent phom combinations - update opponent analysis
            this.handleOpponentPhomCombinations(data);
            break;
        }
      });
    }

    handleAnalyzerEvent(eventType, data) {
      if (!data && eventType !== "GAME_CHECK_START") {
        console.warn(`[Phom Bot] Received ${eventType} without data`);
        return;
      }
      switch (eventType) {
        case "GAME_START":
          debug("[Phom Bot] Received game start from analyzer");
          this.onGameStart(data);
          break;

        case "MY_CARDS_RECEIVED":
          this.analyzeInitialHand(data.cards, data.analysis);
          this.updateMyCards(data.cards);
          debug(
            "[Phom Bot] My Cards",
            [...(this.myCards ?? [])].map((c) => this.getCardName(c))
          );
          break;

        case "MY_TURN":
          debug("[Phom Bot] My Turn with situation analysis:", data.situation);
          this.myTurn = true;
          this.makeOptimalMoveWithAnalysis().catch((error) => {
            console.error(
              "[Phom Bot] Error in makeOptimalMoveWithAnalysis:",
              error
            );
          });
          break;
        case "GAME_CHECK_START": {
          const totalReady = this.countPlayerVisible();
          debug(`[Phom Bot] Game check started - Total ready: ${totalReady}`);

          if (totalReady >= 4) {
            debug("[Phom Bot] Rule 3: 3 opponents ready, leaving table immediately");
            window.postMessage({ type: "PHOM_MONITOR_MUST_LEAVE" }, "*");
            break;
          }

          if (totalReady === 3) {
            debug("[Phom Bot] Rule 2: 2 opponents ready, setting limit 2-3 games");
            if (this.maxGamesAtTable === 0 || this.maxGamesAtTable === Infinity) {
              this.maxGamesAtTable = Math.floor(Math.random() * 2) + 2; // 2 or 3
              debug(`[Phom Bot] Session limit set to: ${this.maxGamesAtTable} games`);
            }
          }

          if (totalReady <= 1) {
            debug("[Phom Bot] Rule 1: No opponents ready yet, waiting...");
            // Do nothing, wait for next check
            break;
          }

          // Rule 1: Play if totalReady == 2 (Bot + 1 opponent)
          // Also allows Rule 2 (totalReady == 3) to start if limit not reached
          if (totalReady === 2 || totalReady === 3) {
            this.tryStartCnt = 0;
            this.onStartGameCheck();
            break;
          }
          break;
        }
        case "OPPONENT_CARDS_PLAYED":
          debug("[Phom Bot] Opponent pattern analysis:", data.pattern);
          this.onOpponentCardsPlayed(data.cards);
          this.updateOpponentStrategy(data);
          break;

        case "OPPONENT_EAT_CARD":
          debug(
            `[Phom Bot] Opponent ${data.player} ate card, analysis:`,
            data.analysis
          );
          this.updateOpponentEatenCardAnalysis(data);
          break;

        case "MY_CARDS_PLAYED":
          debug("[Phom Bot] My cards played:", data.cards);
          this.onMyCardsPlayed(data.cards);
          break;

        case "GAME_END":
          debug("[Phom Bot] Game ended:");
          this.onGameEnd(data);
          break;

        case "USER_LEAVE":
          debug("[Phom Bot] User left game (Room closed)");
          this.resetGame();
          // Reset session tracking for next table
          this.gamesPlayedAtTable = 0;
          this.maxGamesAtTable = 0;
          break;
      }
    }

    analyzeInitialHand(cards, analysis) {
      this.myCards = new Set(cards);
      this.handAnalysis = analysis;

      // Điều chỉnh strategy dựa trên hand strength
      if (analysis.strength > 70) {
        this.currentStrategy = "aggressive";
        this.playDelay.min = Math.max(1000, this.playDelay.min - 500);
      } else if (analysis.strength < 30) {
        this.currentStrategy = "defensive";
        this.playDelay.min = Math.min(4000, this.playDelay.min + 1000);
      } else {
        this.currentStrategy = "balanced";
      }

      debug(
        `[Phom Bot] Hand strength: ${analysis.strength}, Strategy: ${this.currentStrategy}`
      );
    }

    /**
     * Cập nhật thông tin phân tích khi đối thủ ăn bài
     * Sử dụng để cải thiện tính toán an toàn khi đánh bài
     */
    updateOpponentEatenCardAnalysis(data) {
      // Lưu trữ thông tin phân tích từ analyzer
      if (!this.opponentAnalysis) {
        this.opponentAnalysis = new Map();
      }

      const { player, eatenCard, analysis, dangerousCards } = data;

      // Cập nhật thông tin cho player này - Sử dụng Map.get() để không xóa dữ liệu cũ (như phomCombinations)
      if (!this.opponentAnalysis.has(player)) {
        this.opponentAnalysis.set(player, {
          phomCombinations: [],
          revealedCards: new Set(),
          estimatedHandSize: 10
        });
      }

      const opponentData = this.opponentAnalysis.get(player);
      opponentData.eatenCards = analysis.eatenCards;
      opponentData.predictedSequences = analysis.predictedSequences;
      opponentData.predictedSets = analysis.predictedSets;
      opponentData.lastUpdate = Date.now();

      // Anti-Đền Làng Check
      if (eatenCard !== undefined && eatenCard === this.lastDiscardedCard) {
        this.timesMyCardEaten++;
        debug(`[Phom Bot] ⚠️ NGƯỜI KẾ TIẾP ĐÃ ĂN BÀI TỪ TÔI! Cảnh báo chống đền làng. Lần ăn: ${this.timesMyCardEaten}`);
      }

      // Lưu danh sách các lá nguy hiểm (từ analyzer)
      this.dangerousCardsFromAnalyzer = new Set(dangerousCards);

      debug(
        `[Phom Bot] Updated analysis for ${player}. Dangerous cards: ${dangerousCards.length}`
      );

      // Log chi tiết để debug
      if (analysis.predictedSequences.length > 0) {
        debug(
          `[Phom Bot] Predicted sequences for ${player}:`,
          analysis.predictedSequences
        );
      }
      if (analysis.predictedSets.length > 0) {
        debug(
          `[Phom Bot] Predicted sets for ${player}:`,
          analysis.predictedSets
        );
      }
    }

    onStartGameCheck() {
      // Clear any previous interval to prevent multiple intervals accumulating
      if (this.startCheckIntervalId) {
        clearInterval(this.startCheckIntervalId);
        this.startCheckIntervalId = null;
        debug("[Phom Bot] Cleared previous startGameCheck interval");
      }

      // Fix: delay must be at least 2000ms (not 0 when tryStartCnt=0)
      const intervalDelay = Math.max(2000, 2000 * this.tryStartCnt);

      this.startCheckIntervalId = setInterval(() => {
        if (this.tryStartCnt > 3) {
          clearInterval(this.startCheckIntervalId);
          this.startCheckIntervalId = null;
          return;
        }
        this.tryStartCnt++;
        const availableButtons = this.getAvailableButtons();
        if (availableButtons.includes("btn_sansang")) {
          debug("[Phom Bot] Game check - clicking 'Sẵn sàng' button");
          this.clickGameButton("btn_sansang");
        }
        if (availableButtons.includes("btn_batdau")) {
          clearInterval(this.startCheckIntervalId);
          this.startCheckIntervalId = null;
          debug("[Phom Bot] Game check - clicking 'Bắt đầu' button");
          this.clickGameButton("btn_batdau");

          setTimeout(() => {
            const okButton = this.getOKButton();
            debug("[Phom Bot] Checking for OK button after start");
            if (okButton && this.isButtonVisible(okButton)) {
              debug("[Phom Bot] Clicking OK button to confirm start");
              this.triggerCocosClick(okButton);
            }
          }, 2000);
        }
      }, intervalDelay);
    }

    /**
     * Fallback interval to detect actionable buttons when MY_TURN is missed
     */
    startFallbackInterval() {
      if (this.fallbackIntervalId) {
        clearInterval(this.fallbackIntervalId);
      }

      this.fallbackIntervalId = setInterval(() => {
        if (!this.isEnabled || this.isProcessingTurn) return;

        const availableButtons = this.getAvailableButtons();
        const actionButtons = [
          "btn_anBai2",
          "btn_rutBai2",
          "btn_guiBai",
          "btn_haPhom",
          "btn_danhBai",
          "btn_baoU"
        ];

        const hasAction = availableButtons.some(btn => actionButtons.includes(btn));

        if (hasAction && !this.myTurn) {
          debug("[Phom Bot] Fallback: Action buttons detected but myTurn is false. Triggering logic.");
          this.myTurn = true;
          this.makeOptimalMoveWithAnalysis().catch(err => {
            debug("[Phom Bot] Fallback error:", err);
          });
        }
      }, 2000);

      debug("[Phom Bot] Fallback interval started (2000ms)");
    }

    async makeOptimalMoveWithAnalysis() {
      if (!this.myTurn || !this.isEnabled || this.isProcessingTurn) {
        if (this.isProcessingTurn) debug("[Phom Bot] Turn sequence already in progress, skipping concurrent call");
        return;
      }

      this.isProcessingTurn = true;
      const delay = this.calculateMoveDelay();

      await this.sleep(delay);
      try {
        await this.performTurnSequence();
      } finally {
        // Luôn đảm bảo reset lock kể cả khi có lỗi
        this.isProcessingTurn = false;
      }
    }

    async performTurnSequence() {
      if (!this.myTurn || !this.isEnabled) return;
      debug(
        "[Phom Bot] Starting turn sequence - checking all available buttons"
      );

      // Check tất cả buttons theo priority
      const availableButtons = this.getAvailableButtons();
      debug("[Phom Bot] Available buttons:", availableButtons);

      // Priority order: Ù > Gửi bài > Hạ phỏm > Ăn bài/Rút bài > Xếp bài > Đánh bài
      const actionTaken = await this.executeHighestPriorityAction(
        availableButtons
      );

      if (!actionTaken) {
        debug("[Phom Bot] No actions available, waiting");
      }
    }

    async executeHighestPriorityAction(availableButtons) {
      if (!this.myTurn || !this.isEnabled) return;

      // Priority 1: Báo Ù (instant win) - KẾT THÚC GAME
      if (availableButtons.includes("btn_baoU")) {
        debug("[Phom Bot] Ù available - declaring win!");
        this.clickGameButton("btn_baoU");
        return true;
      }

      // Priority 2: Gửi bài (end game with advantage) - KẾT THÚC GAME
      if (availableButtons.includes("btn_guiBai")) {
        debug("[Phom Bot] Ending game - sending cards");
        this.clickGameButton("btn_guiBai");
      }

      // Priority 3: Hạ phỏm (play combinations) - KHÔNG kết thúc turn
      if (availableButtons.includes("btn_haPhom")) {
        debug("[Phom Bot] Playing phỏm combinations");
        this.clickGameButton("btn_haPhom");
      }

      if (availableButtons.includes("btn_anBai2")) {
        this.clickGameButton("btn_anBai2");
        await this.sleep(2000);
        await this.performTurnSequence();
        return true;
      } else if (availableButtons.includes("btn_rutBai2")) {
        this.clickGameButton("btn_rutBai2");
        await this.sleep(2000);
        await this.performTurnSequence();
        return true;
      }

      if (availableButtons.includes("btn_xepBai")) {
        debug("[Phom Bot] No other actions - sorting hand");
        this.clickGameButton("btn_xepBai");
      }

      await this.sleep(3000);

      // CẬP NHẬT LẠI TRẠNG THÁI BUTTON SAU KHI ĐÃ ĐỢI (Đề phòng game animation hạ phỏm/xếp bài)
      const currentButtons = this.getAvailableButtons();
      debug("[Phom Bot] Buttons refreshed after delay:", currentButtons);

      let is_guiBai = false;
      if (currentButtons.includes("btn_guiBai")) {
        debug("[Phom Bot] Gửi bài available - click directly, game auto-selects cards.");
        this.clickGameButton("btn_guiBai");
        this.cardSelected = null;
        is_guiBai = true;
      }

      if (is_guiBai) {
        await this.sleep(2000);
        if (this.getAvailableButtons().includes("btn_danhBai")) {
          this.performOptimalDiscardSequence();
        }
      } else {
        if (currentButtons.includes("btn_danhBai")) {
          this.performOptimalDiscardSequence();
        }
      }

      return true;
    }

    performOptimalDiscardSequence() {
      if (!this.myTurn || !this.isEnabled) return;
      // Tính toán lá bài tối ưu để đánh với thuật toán tỷ lệ bị ăn thấp nhất
      let bestDiscardMove = null;

      // Phân tích tất cả lá bài trong tay với chiến lược tránh bị ăn
      let myCardsArray = Array.from(this.myCards);

      // ⭐ TUYỆT ĐỐI KHÔNG PHÁ PHỎM ĐỂ ĐÁNH
      // Filter out all cards that belong to a complete phỏm
      const nonPhomCards = myCardsArray.filter(card => !this.isPartOfExistingPhom(card, this.parseCard(card)));

      if (nonPhomCards.length > 0) {
        debug(`[Phom Bot] Found ${nonPhomCards.length} non-phỏm cards. Total cards: ${myCardsArray.length}`);
        myCardsArray = nonPhomCards;
      } else {
        // Fallback: If ALL cards are in phỏm, only then we consider all of them
        debug("[Phom Bot] ⚠️ TẤT CẢ bài đều nằm trong phỏm. Bắt buộc phải phá phỏm.");
      }

      if (myCardsArray.length === 0) {
        debug("[Phom Bot] No cards to discard");
        return;
      }

      // Nước đầu tiên ưu tiên lấy con ngoài cùng bên phải (sau khi xếp bài)
      let rightmostCard = null;
      if (this.myPlayedCards.size === 0) {
        const visualCards = this.getPlayerCards().visible;
        if (visualCards && visualCards.length > 0) {
          let maxX = -999999;
          for (const c of visualCards) {
            // Lấy lá bài hợp lệ (không phải phỏm dính) nằm ngoài cùng bên phải
            if (myCardsArray.includes(c.cardNumber) && c.position.x > maxX) {
              maxX = c.position.x;
              rightmostCard = c.cardNumber;
            }
          }
          if (rightmostCard !== null) {
            debug(`[Phom Bot] Nước đầu tiên: Chọn lá bài rác ngoài cùng bên phải: ${this.getCardName(rightmostCard)} (X: ${maxX})`);
          }
        }
      }

      // Tính toán điểm an toàn cho từng lá bài (càng cao càng ít bị ăn)
      const safetyScores = myCardsArray.map((card) => {
        const safetyScore = this.calculateCardSafetyScore(card);
        let finalScore = safetyScore.totalScore;
        let reasoning = this.generateDiscardReasoning(card, safetyScore);

        if (card === rightmostCard) {
          finalScore += 5000; // Bonus khổng lồ để luôn đánh lá này ở nước đầu
          reasoning = "➡️ BÀI RÁC NGOÀI CÙNG BÊN PHẢI (NƯỚC 1) - " + reasoning;
        }

        return {
          type: "discard",
          cards: [card],
          score: finalScore,
          safetyBreakdown: safetyScore,
          reasoning: reasoning,
        };
      });

      // Sắp xếp theo điểm an toàn (cao nhất = ít bị ăn nhất)
      safetyScores.sort((a, b) => b.score - a.score);
      debug(
        "[Phom Bot] Safety scores for discards:",
        safetyScores.map((s) => ({
          card: this.getCardName(s.cards[0]),
          score: s.score,
          reasoning: s.reasoning,
        }))
      );
      bestDiscardMove = this.applyDifficultyToSafeDiscard(safetyScores)[0];

      debug(
        `[Phom Bot] Selected safest discard: ${this.getCardName(
          bestDiscardMove.cards[0]
        )} (score: ${bestDiscardMove.score})`,
        bestDiscardMove.safetyBreakdown || {}
      );

      this.performOptimalDiscard(bestDiscardMove);
    }

    /**
     * Tính điểm an toàn của lá bài - điểm càng cao càng ưu tiên đánh
     * ⭐ ƯU TIÊN TUYỆT ĐỐI: LUÔN LUÔN đánh lá đối thủ CHẮC CHẮN không thể ăn được
     * Nguyên tắc: Đối thủ đã đánh Q♣ → Q♦/Q♠ trong tay chắc chắn an toàn → UU TIÊN CAO NHẤT
     */
    calculateCardSafetyScore(card) {
      const cardInfo = this.parseCard(card);
      if (!cardInfo) return { totalScore: 0 };

      let safetyScore = 0;
      const breakdown = {
        guaranteedSafeBonus: 0, // 🔥 PRIORITY 0: Chắc chắn đối thủ không ăn được - CAO NHẤT
        opponentCannotUseBonus: 0, // PRIORITY 1: Lá đối thủ khó ăn được
        trashCardBonus: 0, // Lá rác (không tạo được phỏm)
        phomPreservationPenalty: 0, // Phạt nếu phá phỏm
        edgeBonus: 0, // Lá biên an toàn
        deadCardBonus: 0, // Bài chết
        opponentPatternPenalty: 0, // Pattern đối thủ
        isolationBonus: 0, // Lá cô lập
        handStrengthFactor: 0, // Điều chỉnh theo pha game
        comboBreakingPenalty: 0, // Phạt nếu phá combo tiềm năng
        lateGameHighCardBonus: 0, // Bonus đánh lá cao cuối game
        chotPenalty: 0, // Phạt nếu đánh vòng chốt nhưng rủi ro
        denLangPenalty: 0 // Phạt nếu đánh rủi ro bốc bài thứ 3
      };

      // 🔥 PRIORITY 0: CHẮC CHẮN đối thủ không thể ăn được - UU TIÊN TUYỆT ĐỐI
      const guaranteedSafe = this.calculateGuaranteedSafeBonus(card, cardInfo);
      breakdown.guaranteedSafeBonus = guaranteedSafe;
      safetyScore += breakdown.guaranteedSafeBonus;

      // Nếu lá này CHẮC CHẮN an toàn, return ngay với điểm cực cao
      if (guaranteedSafe >= 1000) {
        return {
          totalScore: Math.round(safetyScore),
          ...breakdown,
        };
      }

      // PRIORITY 1: Kiểm tra lá đối thủ khó ăn được
      const opponentCannotUseBonus = this.calculateOpponentCannotUseBonus(
        card,
        cardInfo
      );
      breakdown.opponentCannotUseBonus = opponentCannotUseBonus;
      safetyScore += breakdown.opponentCannotUseBonus;

      // PRIORITY 2: Phân tích lá rác vs lá có giá trị
      const trashAnalysis = this.analyzeTrashCard(card, cardInfo);
      breakdown.trashCardBonus = trashAnalysis.score;
      safetyScore += breakdown.trashCardBonus;

      // PRIORITY 3: Bảo vệ phỏm đã có - TUYỆT ĐỐI không phá
      const phomPenalty = this.calculatePhomBreakingPenalty(card, cardInfo);
      breakdown.phomPreservationPenalty = phomPenalty;
      safetyScore -= breakdown.phomPreservationPenalty;

      // PRIORITY 4: Tránh phá combo tiềm năng (gần thành phỏm)
      const comboPenalty = this.calculateComboBreakingPenalty(card, cardInfo);
      breakdown.comboBreakingPenalty = comboPenalty;
      safetyScore -= breakdown.comboBreakingPenalty;

      // Factor 4: Vị trí biên an toàn (A, 2, J, Q, K khó tạo dãy)
      breakdown.edgeBonus = this.calculateEdgeCardBonus(cardInfo);
      safetyScore += breakdown.edgeBonus;

      // Factor 5: Bài chết (dead cards) - các lá liên quan đã được đánh
      breakdown.deadCardBonus = this.calculateDeadCardBonus(card, cardInfo);
      safetyScore += breakdown.deadCardBonus;

      // Factor 6: Phân tích pattern đối thủ - tránh đánh lá đối thủ cần
      breakdown.opponentPatternPenalty = this.calculateOpponentPatternRisk(
        card,
        cardInfo
      );
      safetyScore -= breakdown.opponentPatternPenalty;

      // Factor 7: Lá cô lập trong tay
      breakdown.isolationBonus = this.calculateIsolationBonus(card, cardInfo);
      safetyScore += breakdown.isolationBonus;

      // Factor 8: Điều chỉnh theo pha game và hand strength
      breakdown.handStrengthFactor =
        this.calculateHandStrengthAdjustment(cardInfo);
      safetyScore += breakdown.handStrengthFactor;

      // Factor 9: CUỐI GAME - Ưu tiên đánh lá cao để chạy bài (giảm điểm bị ăn)
      const lateGameBonus = this.calculateLateGameHighCardBonus(card, cardInfo);
      breakdown.lateGameHighCardBonus = lateGameBonus;
      safetyScore += breakdown.lateGameHighCardBonus;

      // 🔥 EXTREME OVERRIDES: TÌNH HUỐNG DAC BIET
      const isLastToLower = this.isLastToLowerCards();

      // NẾU MÌNH LÀ NGƯỜI HẠ CUỐI CÙNG (không ai còn khả năng ăn bài) -> Ưu tiên chạy bài to nhất
      if (isLastToLower) {
        // Bỏ qua mọi penalty an toàn, MỤC TIÊU DUY NHẤT LÀ VỨT BÀI CÓ GIÁ TRỊ TO NHẤT ĐỂ GIẢM ĐIỂM
        // K=12, Q=11, J=10,... nhân 10000 để đè lên mọi logic safety khác
        const faceValueScore = cardInfo.value * 10000;
        safetyScore += faceValueScore;

        return {
          totalScore: Math.round(safetyScore),
          ...breakdown,
          reasoning: `🎯 NGƯỜI HẠ BÀI CUỐI - CHẠY BÀI TO NHẤT (${cardInfo.valueName})`
        };
      }

      const isChot = this.myPlayedCards && this.myPlayedCards.size >= 3;
      const isChongDen = this.timesMyCardEaten >= 2;

      if (isChongDen) {
        if (guaranteedSafe < 400 && opponentCannotUseBonus < 120) {
          breakdown.denLangPenalty = -50000;
          safetyScore += breakdown.denLangPenalty;
        }
      } else if (isChot) {
        if (guaranteedSafe < 400 && opponentCannotUseBonus < 80) {
          breakdown.chotPenalty = -10000;
          safetyScore += breakdown.chotPenalty;
        }
        // Hủy bỏ việc ưu tiên đánh lá rác/cao nếu là vòng chốt mà bài đó nguy hiểm
        if (guaranteedSafe < 400 && opponentCannotUseBonus <= 0) {
          safetyScore -= breakdown.trashCardBonus;
          safetyScore -= breakdown.lateGameHighCardBonus;
        }
      }

      return {
        totalScore: Math.round(safetyScore),
        ...breakdown,
      };
    }

    /**
     * 🔥 PRIORITY 0: Tính bonus cho lá CHẮC CHẮN đối thủ không thể ăn được
     * Ví dụ: Đối thủ đã đánh Q♣, mà tay có J♣+J♦+Q♦+Q♠ → Q♦,Q♠ chắc chắn an toàn
     * Logic: Nếu các lá cần thiết để ăn lá này đã được đánh → CHẮC CHẮN an toàn
     */
    calculateGuaranteedSafeBonus(card, cardInfo) {
      const allPlayedCards = this.getAllVisibleCards();

      // Phân tích các loại phỏm mà lá này có thể tham gia
      const possibleCombinations = this.findPossibleCombinationsForCard(
        card,
        cardInfo
      );

      let guaranteedSafeCombinations = 0;
      let totalCombinations = possibleCombinations.length;

      possibleCombinations.forEach((combination) => {
        // Kiểm tra xem tất cả lá cần thiết cho combination này đã bị chặn chưa
        if (
          this.isCombinationBlockedByPlayedCards(combination, allPlayedCards)
        ) {
          guaranteedSafeCombinations++;
        }
      });

      // Nếu TẤT CẢ combinations có thể đều bị chặn → CHẮC CHẮN an toàn
      if (
        totalCombinations > 0 &&
        guaranteedSafeCombinations === totalCombinations
      ) {
        // 🔥 BONUS CỰC CAO - LUÔN LUÔN đánh lá này trước
        return 1500; // Cao hơn tất cả penalties khác
      }

      // Nếu hầu hết combinations bị chặn → rất an toàn
      if (totalCombinations > 0) {
        const safeRatio = guaranteedSafeCombinations / totalCombinations;

        if (safeRatio >= 0.8) {
          return 800; // Rất an toàn
        } else if (safeRatio >= 0.6) {
          return 600; // Khá an toàn
        } else if (safeRatio >= 0.4) {
          return 400; // Tương đối an toàn
        }
      }

      return 0; // Không đủ điều kiện "chắc chắn" an toàn
    }

    /**
     * Tìm tất cả các combinations mà lá bài này có thể tham gia
     * Bao gồm: sequence và set combinations
     */
    findPossibleCombinationsForCard(card, cardInfo) {
      const combinations = [];
      const { suit, value } = cardInfo;

      // 1. SET COMBINATIONS - Các lá cùng giá trị có thể tạo set 3
      // Cần 2 lá khác cùng giá trị
      const setPotentialCards = [];
      for (let otherSuit = 0; otherSuit < 4; otherSuit++) {
        if (otherSuit !== suit) {
          const setCard = value * 4 + otherSuit;
          setPotentialCards.push(setCard);
        }
      }

      // Tạo tất cả combinations set có thể (chọn 2 trong 3 lá còn lại)
      for (let i = 0; i < setPotentialCards.length - 1; i++) {
        for (let j = i + 1; j < setPotentialCards.length; j++) {
          combinations.push({
            type: "set",
            cards: [card, setPotentialCards[i], setPotentialCards[j]],
            requiredCards: [setPotentialCards[i], setPotentialCards[j]], // Lá cần có để ăn
          });
        }
      }

      // 2. SEQUENCE COMBINATIONS - Các dãy 3 lá liên tiếp có thể
      // Tìm tất cả dãy 3 có thể mà lá này tham gia
      for (
        let startValue = Math.max(0, value - 2);
        startValue <= Math.min(10, value);
        startValue++
      ) {
        const sequenceCards = [];
        let isValidSequence = true;
        let containsTargetCard = false;

        // Tạo dãy 3 lá từ startValue
        for (let i = 0; i < 3; i++) {
          const seqValue = startValue + i;
          const seqCard = seqValue * 4 + suit;

          if (seqCard === card) {
            containsTargetCard = true;
          }
          sequenceCards.push(seqCard);
        }

        // Chỉ thêm nếu dãy chứa lá target và hợp lệ
        if (containsTargetCard && isValidSequence) {
          const requiredCards = sequenceCards.filter((c) => c !== card);
          combinations.push({
            type: "sequence",
            cards: sequenceCards,
            requiredCards: requiredCards, // 2 lá còn lại cần có để ăn
          });
        }
      }

      return combinations;
    }

    /**
     * Kiểm tra xem một combination có bị chặn bởi các lá đã đánh không
     * Nếu ít nhất 1 lá required đã được đánh → combination bị chặn
     */
    isCombinationBlockedByPlayedCards(combination, allPlayedCards) {
      // Để ăn được lá target thông qua combination này,
      // đối thủ cần có TẤT CẢ các lá required
      // Nếu ít nhất 1 lá required đã được đánh → không thể ăn

      for (let requiredCard of combination.requiredCards) {
        if (allPlayedCards.has(requiredCard)) {
          return true; // Bị chặn - không thể ăn được
        }
      }

      return false; // Chưa bị chặn - vẫn có thể ăn được
    }

    /**
     * PRIORITY 1: Tính bonus cho lá mà đối thủ KHÔNG THỂ ăn được
     * ƯU TIÊN CAO NHẤT - đánh những lá này trước để tránh cho đối thủ lợi thế
     * SỬ DỤNG THÔNG TIN TỪ ANALYZER về sảnh đối thủ đã ăn
     */
    calculateOpponentCannotUseBonus(card, cardInfo) {
      let bonus = 0;

      // PRIORITY HIGHEST: Sử dụng thông tin từ analyzer về các lá nguy hiểm
      if (
        this.dangerousCardsFromAnalyzer &&
        this.dangerousCardsFromAnalyzer.has(card)
      ) {
        // Lá này được analyzer đánh dấu là nguy hiểm (đối thủ có thể cần)
        return -800; // PENALTY KHÓA MỎ CỰC CAO - TRÁNH ĐÁNH
      }

      const allPlayedCards = this.getAllVisibleCards();

      // Kiểm tra các lá bài mà đối thủ có thể dùng để ăn lá này
      const dangerousCards = this.findCardsThatCanUseThisCard(card, cardInfo);

      // Đếm số lá nguy hiểm đã được đánh (không còn trong bộ bài)
      let safeFromCards = 0;
      let totalDangerousCards = dangerousCards.length;

      dangerousCards.forEach((dangerousCard) => {
        if (allPlayedCards.has(dangerousCard)) {
          safeFromCards++;
        }
      });

      // Tính tỷ lệ an toàn - càng nhiều lá nguy hiểm đã chết, càng an toàn
      if (totalDangerousCards > 0) {
        const safetyRatio = safeFromCards / totalDangerousCards;

        // Bonus cao nếu hầu hết/tất cả lá nguy hiểm đã chết
        if (safetyRatio >= 0.8) {
          bonus = 150; // Rất an toàn - đối thủ khó ăn được
        } else if (safetyRatio >= 0.6) {
          bonus = 120; // Khá an toàn
        } else if (safetyRatio >= 0.4) {
          bonus = 80; // Tương đối an toàn
        } else if (safetyRatio >= 0.2) {
          bonus = 40; // Ít an toàn
        } else {
          bonus = 0; // Nguy hiểm - đối thủ có thể ăn được
        }

        // Bonus thêm cho lá biên (A, K) vì ít bị ăn hơn
        if (cardInfo.value === 0 || cardInfo.value === 12) {
          bonus += 30; // A hoặc K
        } else if (cardInfo.value === 1 || cardInfo.value === 11) {
          bonus += 20; // 2 hoặc Q
        }

        // Penalty nếu có nhiều lá nguy hiểm còn lại (đối thủ dễ ăn)
        const remainingDangerous = totalDangerousCards - safeFromCards;
        if (remainingDangerous >= 4) {
          bonus -= 60; // Nhiều lá có thể ăn
        } else if (remainingDangerous >= 2) {
          bonus -= 30; // Vài lá có thể ăn
        }
      } else {
        // Không có lá nào có thể ăn được - rất an toàn
        bonus = 100;
      }

      return Math.max(0, bonus); // Không để âm
    }

    /**
     * Tìm các lá bài mà đối thủ có thể dùng để ăn lá này
     * Bao gồm: lá để tạo sequence và lá để tạo set
     */
    findCardsThatCanUseThisCard(card, cardInfo) {
      const dangerousCards = [];

      // 1. Các lá có thể tạo sequence với lá này
      const { suit, value } = cardInfo;

      // Lá liền kề để tạo dãy 3 (trước và sau)
      for (let offset = -2; offset <= 2; offset++) {
        if (offset === 0) continue; // Skip chính lá này

        const neighborValue = value + offset;
        if (neighborValue >= 0 && neighborValue <= 12) {
          const neighborCard = neighborValue * 4 + suit;

          // Kiểm tra xem lá này có thể tạo sequence không
          if (this.canFormSequenceWith(cardInfo, neighborValue)) {
            dangerousCards.push(neighborCard);
          }
        }
      }

      // 2. Các lá có thể tạo set với lá này (cùng giá trị, khác chất)
      for (let otherSuit = 0; otherSuit < 4; otherSuit++) {
        if (otherSuit !== suit) {
          const setCard = value * 4 + otherSuit;
          dangerousCards.push(setCard);
        }
      }

      return dangerousCards;
    }

    /**
     * Kiểm tra xem một lá có thể tạo sequence với lá hiện tại không
     */
    canFormSequenceWith(cardInfo, neighborValue) {
      const { value } = cardInfo;
      const diff = Math.abs(neighborValue - value);

      // Chỉ lá liền kề (diff = 1) hoặc cách 1 lá (diff = 2) mới có thể tạo sequence
      return diff <= 2;
    }

    /**
     * Phân tích lá rác - lá không có giá trị, nên đánh trước
     * Lá rác = lá cô lập hoàn toàn, không thể tạo phỏm
     */
    analyzeTrashCard(card, cardInfo) {
      const myCardsArray = Array.from(this.myCards).filter((c) => c !== card);

      if (myCardsArray.length === 0) {
        return { score: 100, isTrash: true, reason: "Lá duy nhất" };
      }

      let score = 0;
      let relatedCards = [];
      let hasSequencePotential = false;
      let hasSetPotential = false;

      // Kiểm tra khả năng tạo sequence (dãy) - IMPROVED LOGIC
      const sameSuitCards = myCardsArray.filter((c) => {
        const otherInfo = this.parseCard(c);
        return otherInfo && otherInfo.suit === cardInfo.suit;
      });

      // Analyze sequence potential with advanced group detection
      if (sameSuitCards.length > 0) {
        // Get all cards of this suit including the current card
        const allSuitCards = [...sameSuitCards, card]
          .map((c) => this.parseCard(c))
          .sort((a, b) => a.value - b.value);

        // Look for sequence formations within reasonable range (up to 4 cards apart to allow for 2 gaps)
        sameSuitCards.forEach((otherCard) => {
          const otherInfo = this.parseCard(otherCard);
          const valueDiff = Math.abs(otherInfo.value - cardInfo.value);

          // Direct adjacency or close proximity
          if (valueDiff <= 2) {
            relatedCards.push({
              card: otherCard,
              diff: valueDiff,
              type: "sequence",
            });
            hasSequencePotential = true;
          }
          // Extended sequence potential - check if they can be part of same sequence group
          else if (valueDiff <= 4 && sameSuitCards.length >= 2) {
            // Check if there are cards that bridge the gap
            const minValue = Math.min(cardInfo.value, otherInfo.value);
            const maxValue = Math.max(cardInfo.value, otherInfo.value);

            // Count how many cards we have in this range
            const cardsInRange = allSuitCards.filter(
              (c) => c.value >= minValue && c.value <= maxValue
            ).length;

            // If we have 3+ cards in a range of 4, it's likely sequence potential
            if (cardsInRange >= 3 && maxValue - minValue <= 4) {
              relatedCards.push({
                card: otherCard,
                diff: valueDiff,
                type: "sequence",
              });
              hasSequencePotential = true;
            }
          }
        });
      }

      // Kiểm tra khả năng tạo set (sảnh)
      const sameValueCards = myCardsArray.filter((c) => {
        const otherInfo = this.parseCard(c);
        return otherInfo && otherInfo.value === cardInfo.value;
      });

      if (sameValueCards.length > 0) {
        hasSetPotential = true;
        sameValueCards.forEach((c) => {
          relatedCards.push({ card: c, diff: 0, type: "set" });
        });
      }

      // Tính điểm dựa trên mức độ "rác"
      if (!hasSequencePotential && !hasSetPotential) {
        // LÁ RÁC HOÀN TOÀN - Ưu tiên cao nhất
        score = 100;
        return {
          score,
          isTrash: true,
          reason: "Lá rác hoàn toàn - không tạo được phỏm",
        };
      }

      if (relatedCards.length === 0) {
        // Cô lập hoàn toàn
        score = 90;
        return {
          score,
          isTrash: true,
          reason: "Cô lập - không có lá liên quan",
        };
      }

      // Phân tách set cards và sequence cards để tính điểm chính xác
      const setCards = relatedCards.filter((rc) => rc.type === "set");
      const sequenceCards = relatedCards.filter((rc) => rc.type === "sequence");

      const allPlayedCards = this.getAllVisibleCards();

      // CẠ CHẾT (DEAD COMBO): Lọc bỏ cạ nếu các lá để ghép đã bị đánh
      const effectiveSetCards = setCards.filter(rc => {
        let missingCount = 0;
        for (let suit = 0; suit < 4; suit++) {
          if (suit !== cardInfo.suit && suit !== this.parseCard(rc.card).suit) {
            const missingCard = cardInfo.value * 4 + suit;
            if (!allPlayedCards.has(missingCard)) {
              missingCount++;
            }
          }
        }
        return missingCount > 0;
      });

      const effectiveSeqCards = sequenceCards.filter(rc => {
        const sequences = this.findPossibleCombinationsForCard(card, cardInfo)
          .filter(combo => combo.type === 'sequence' && combo.cards.includes(rc.card));

        let allBlocked = true;
        for (let combo of sequences) {
          if (!this.isCombinationBlockedByPlayedCards(combo, allPlayedCards)) {
            allBlocked = false;
            break;
          }
        }
        return !allBlocked;
      });

      // Nếu có cạ, nhưng tất cả đều chết -> đó là XÉ CẠ CHẾT (rác hoàn toàn)
      if (relatedCards.length > 0 && effectiveSetCards.length === 0 && effectiveSeqCards.length === 0) {
        return {
          score: 95, // Cao hơn cạ thường, nên ưu tiên xé cạ chết
          isTrash: true,
          reason: "CẠ CHẾT (Các lá tạo phỏm đã bị ra hết)",
        };
      }

      // Kiểm tra nếu đã là phỏm
      if (this.isPartOfExistingPhom(card, cardInfo)) {
        // Đã là phỏm - TUYỆT ĐỐI không đánh
        score = -200;
        return { score, isTrash: false, reason: "ĐÃ LÀ PHỎM - KHÔNG ĐÁNH" };
      }

      // PRIORITY: Set potential (sảnh) - quan trọng nhất vì dễ tạo
      if (effectiveSetCards.length >= 2) {
        // Đã có 3+ lá cùng giá trị - rất mạnh
        score = -100;
        return { score, isTrash: false, reason: "Sảnh 3+ lá - rất mạnh" };
      } else if (effectiveSetCards.length === 1) {
        // Có 2 lá cùng giá trị - tiềm năng sảnh
        score = -60;
        return {
          score,
          isTrash: false,
          reason: "Tiềm năng sảnh - 2 lá cùng giá trị",
        };
      }

      // SECONDARY: Sequence potential (dãy) - chỉ xét khi không có set potential
      if (effectiveSeqCards.length >= 2) {
        // Nhiều lá có thể tạo dãy
        score = -40;
        return {
          score,
          isTrash: false,
          reason: "Tiềm năng dãy - nhiều lá liên quan",
        };
      } else if (effectiveSeqCards.length === 1) {
        const related = effectiveSeqCards[0];
        if (related.diff === 1) {
          // Có lá liền kề - dễ tạo dãy
          score = -30;
          return {
            score,
            isTrash: false,
            reason: "Tiềm năng dãy - có lá liền kề",
          };
        } else if (related.diff === 2) {
          // Chỉ có 1 lá cách 2 bậc - khó tạo phỏm
          score = 70;
          return { score, isTrash: false, reason: "Khó tạo dãy - cách 2 bậc" };
        }
      }

      return { score: 0, isTrash: false, reason: "Bình thường" };
    }

    /**
     * Kiểm tra lá bài có phải là phần của phỏm đã có không
     */
    isPartOfExistingPhom(card, cardInfo) {
      const myCardsArray = Array.from(this.myCards);

      // Kiểm tra sequence (dãy 3 lá liên tiếp cùng chất)
      const sameSuitCards = myCardsArray
        .filter((c) => {
          const info = this.parseCard(c);
          return info && info.suit === cardInfo.suit;
        })
        .sort((a, b) => this.parseCard(a).value - this.parseCard(b).value);

      // Tìm dãy chứa lá này
      for (let i = 0; i < sameSuitCards.length; i++) {
        if (sameSuitCards[i] === card) {
          // Kiểm tra trước và sau
          const hasBeforeSequence =
            i >= 2 &&
            this.parseCard(sameSuitCards[i - 1]).value === cardInfo.value - 1 &&
            this.parseCard(sameSuitCards[i - 2]).value === cardInfo.value - 2;

          const hasAfterSequence =
            i <= sameSuitCards.length - 3 &&
            this.parseCard(sameSuitCards[i + 1]).value === cardInfo.value + 1 &&
            this.parseCard(sameSuitCards[i + 2]).value === cardInfo.value + 2;

          const hasMiddleSequence =
            i >= 1 &&
            i <= sameSuitCards.length - 2 &&
            this.parseCard(sameSuitCards[i - 1]).value === cardInfo.value - 1 &&
            this.parseCard(sameSuitCards[i + 1]).value === cardInfo.value + 1;

          if (hasBeforeSequence || hasAfterSequence || hasMiddleSequence) {
            return true;
          }
        }
      }

      // Kiểm tra set (3 lá cùng giá trị)
      const sameValueCards = myCardsArray.filter((c) => {
        const info = this.parseCard(c);
        return info && info.value === cardInfo.value;
      });

      if (sameValueCards.length >= 3) {
        return true;
      }

      return false;
    }

    /**
     * Tính penalty nếu đánh lá này sẽ phá phỏm đã có
     * Penalty CỰC CAO để tránh phá phỏm
     */
    calculatePhomBreakingPenalty(card, cardInfo) {
      if (this.isPartOfExistingPhom(card, cardInfo)) {
        // PENALTY CỰC CAO - Tuyệt đối không phá phỏm
        return 10000;
      }
      return 0;
    }

    /**
     * Tính penalty nếu đánh lá này sẽ phá combo tiềm năng
     * Combo tiềm năng = gần thành phỏm (chỉ cần 1 lá nữa)
     */
    calculateComboBreakingPenalty(card, cardInfo) {
      let penalty = 0;
      const myCardsArray = Array.from(this.myCards).filter((c) => c !== card);

      // Kiểm tra sequence tiềm năng (2 lá liên tiếp cùng chất)
      const sameSuitCards = myCardsArray.filter((c) => {
        const info = this.parseCard(c);
        return info && info.suit === cardInfo.suit;
      });

      let hasNearSequence = false;
      sameSuitCards.forEach((otherCard) => {
        const otherInfo = this.parseCard(otherCard);
        const valueDiff = Math.abs(otherInfo.value - cardInfo.value);

        if (valueDiff === 1) {
          // Có lá liền kề - kiểm tra xem có tạo được dãy 3 không
          const thirdCardValue1 =
            cardInfo.value + (cardInfo.value > otherInfo.value ? 1 : -1);
          const thirdCardValue2 =
            otherInfo.value + (otherInfo.value > cardInfo.value ? 1 : -1);

          // Nếu lá thứ 3 có thể có (chưa ra), đây là combo tiềm năng
          if (
            (thirdCardValue1 >= 0 && thirdCardValue1 <= 12) ||
            (thirdCardValue2 >= 0 && thirdCardValue2 <= 12)
          ) {
            hasNearSequence = true;
          }
        }
      });

      if (hasNearSequence) {
        penalty += 150; // Penalty rất cao cho việc phá sequence tiềm năng
      }

      // Kiểm tra set tiềm năng (2 lá cùng giá trị)
      const sameValueCards = myCardsArray.filter((c) => {
        const info = this.parseCard(c);
        return info && info.value === cardInfo.value;
      });

      if (sameValueCards.length === 2) {
        // Có 2 lá cùng giá trị, đánh lá này sẽ phá set tiềm năng
        penalty += 130;
      } else if (sameValueCards.length === 1) {
        // Có 1 lá cùng giá trị, còn khả năng tạo set
        penalty += 60;
      }

      return penalty;
    }

    /**
     * Bonus cho lá bài biên (ít bị ăn vì khó tạo sequence)
     */
    calculateEdgeCardBonus(cardInfo) {
      const value = cardInfo.value;

      // A (0) và K (12) - rất an toàn (chỉ có 1 hướng tạo sequence)
      if (value === 0 || value === 12) return 40;

      // 2 (1) và Q (11) - khá an toàn
      if (value === 1 || value === 11) return 30;

      // 3 (2) và J (10) - tương đối an toàn
      if (value === 2 || value === 10) return 20;

      // 5-9 (4-8) - lá giữa nguy hiểm nhất (2 hướng tạo sequence)
      if (value >= 4 && value <= 8) return -10;

      return 0;
    }

    /**
     * Bonus cho bài chết - các lá liên quan đã được đánh
     */
    calculateDeadCardBonus(card, cardInfo) {
      let deadCardBonus = 0;
      const allPlayedCards = this.getAllVisibleCards();

      // Kiểm tra các lá có thể tạo sequence (cùng chất, giá trị liên tiếp)
      const sequenceNeighbors = this.findSequenceNeighbors(cardInfo);
      const deadSequenceCards = sequenceNeighbors.filter((neighborCard) =>
        allPlayedCards.has(neighborCard)
      );

      // Mỗi lá neighbor đã chết = +15 điểm an toàn
      deadCardBonus += deadSequenceCards.length * 15;

      // Kiểm tra các lá có thể tạo set (cùng giá trị, khác chất)
      const setNeighbors = this.findSetNeighbors(cardInfo);
      const deadSetCards = setNeighbors.filter((neighborCard) =>
        allPlayedCards.has(neighborCard)
      );

      // Mỗi lá set đã chết = +10 điểm an toàn
      deadCardBonus += deadSetCards.length * 10;

      return deadCardBonus;
    }

    /**
     * Penalty nếu đối thủ có pattern cho thấy cần loại bài này
     */
    calculateOpponentPatternRisk(card, cardInfo) {
      let riskPenalty = 0;

      // Phân tích các lá đối thủ đã đánh
      const opponentCards = Array.from(this.opponentPlayedCards);

      if (opponentCards.length === 0) return 0;

      // Đếm số lá đối thủ đánh cùng chất
      const sameSuitCount = opponentCards.filter((oppCard) => {
        const oppInfo = this.parseCard(oppCard);
        return oppInfo && oppInfo.suit === cardInfo.suit;
      }).length;

      // Nếu đối thủ đánh nhiều lá cùng chất → họ đang giữ lá cùng chất
      // → Tránh đánh lá này vì có thể họ cần để tạo sequence
      if (sameSuitCount >= 3) {
        riskPenalty += 25;
      } else if (sameSuitCount >= 2) {
        riskPenalty += 15;
      }

      // Đếm số lá đối thủ đánh cùng giá trị
      const sameValueCount = opponentCards.filter((oppCard) => {
        const oppInfo = this.parseCard(oppCard);
        return oppInfo && oppInfo.value === cardInfo.value;
      }).length;

      // Nếu đối thủ đánh nhiều lá cùng giá trị → họ đang giữ lá cùng giá trị
      if (sameValueCount >= 2) {
        riskPenalty += 20;
      }

      // Kiểm tra lá liền kề (có thể tạo sequence với lá này)
      const adjacentCards = opponentCards.filter((oppCard) => {
        const oppInfo = this.parseCard(oppCard);
        return (
          oppInfo &&
          oppInfo.suit === cardInfo.suit &&
          Math.abs(oppInfo.value - cardInfo.value) <= 2
        );
      });

      // Nếu đối thủ đánh lá liền kề → nguy hiểm, họ có thể đang giữ dãy
      if (adjacentCards.length >= 2) {
        riskPenalty += 30;
      } else if (adjacentCards.length === 1) {
        riskPenalty += 10;
      }

      return riskPenalty;
    }

    /**
     * Bonus cho lá cô lập - không tạo được combo với lá khác trong tay
     */
    calculateIsolationBonus(card, cardInfo) {
      const myCardsArray = Array.from(this.myCards).filter((c) => c !== card);

      if (myCardsArray.length === 0) return 50; // Lá duy nhất, rất an toàn

      // Đếm số lá có thể tạo combo với lá này
      let relatedCards = 0;

      myCardsArray.forEach((otherCard) => {
        const otherInfo = this.parseCard(otherCard);
        if (!otherInfo) return;

        // Cùng chất và giá trị gần nhau (có thể tạo sequence)
        if (
          otherInfo.suit === cardInfo.suit &&
          Math.abs(otherInfo.value - cardInfo.value) <= 2
        ) {
          relatedCards++;
        }

        // Cùng giá trị (có thể tạo set)
        if (otherInfo.value === cardInfo.value) {
          relatedCards++;
        }
      });

      // Lá càng cô lập (ít related cards) càng an toàn để đánh
      if (relatedCards === 0) return 35; // Hoàn toàn cô lập
      if (relatedCards === 1) return 20; // Ít liên quan
      if (relatedCards === 2) return 5; // Có thể tạo combo
      if (relatedCards >= 3) return -15; // Nhiều khả năng combo, không nên đánh

      return 0;
    }

    /**
     * Điều chỉnh theo pha game và hand strength
     */
    calculateHandStrengthAdjustment(cardInfo) {
      let adjustment = 0;

      // Điều chỉnh theo pha game
      const gamePhase = this.determineGamePhase();

      if (gamePhase === "late") {
        // Cuối game: ưu tiên đánh bài cao để giảm điểm bị ăn
        if (cardInfo.value >= 10) {
          adjustment += 15; // J, Q, K
        } else if (cardInfo.value >= 7) {
          adjustment += 10; // 8, 9, 10
        }
      } else if (gamePhase === "early") {
        // 1, 2 nước đầu: ƯU TIÊN đánh lá rác lớn (giảm điểm rủi ro cuối game)
        // Ensure they still follow safety rules (handled by calculateCardSafetyScore)
        if (cardInfo.value >= 9) {
          adjustment += 25; // J, Q, K
        } else if (cardInfo.value >= 7) {
          adjustment += 15; // 8, 9, 10
        }
      }

      // Điều chỉnh theo strategy hiện tại
      if (this.currentStrategy === "defensive") {
        // Defensive: ưu tiên bài biên và bài cô lập hơn
        if (cardInfo.value === 0 || cardInfo.value === 12) {
          adjustment += 10;
        }
      } else if (this.currentStrategy === "aggressive") {
        // Aggressive: đánh nhanh các lá không quan trọng
        adjustment += 5;
      }

      return adjustment;
    }

    /**
     * CUỐI GAME - Bonus cho việc đánh lá cao để chạy bài (giảm điểm bị ăn)
     * Khi đã hạ phỏm xong, ưu tiên đánh các lá cao trước để giảm rủi ro bị ù
     */
    calculateLateGameHighCardBonus(card, cardInfo) {
      const gamePhase = this.determineGamePhase();
      const myCardCount = this.myCards.size;

      // Chỉ áp dụng khi:
      // 1. Ở cuối game (late phase) HOẶC còn ít bài
      // 2. Không phá phỏm/combo (đã được check ở các factor trước)
      if (gamePhase !== "late" && myCardCount > 7) {
        return 0; // Không áp dụng ở đầu/giữa game
      }

      let bonus = 0;
      const value = cardInfo.value;

      // Kiểm tra xem có phải là lá cô lập (không tạo được phỏm)
      const trashAnalysis = this.analyzeTrashCard(card, cardInfo);
      const isTrashOrIsolated =
        trashAnalysis.isTrash || trashAnalysis.score >= 60;

      // Chỉ bonus cho lá rác/cô lập - tránh phá combo
      if (isTrashOrIsolated) {
        // K (12) = 10 điểm - Ưu tiên cao nhất
        if (value === 12) {
          bonus = 80;
        }
        // Q (11) = 10 điểm
        else if (value === 11) {
          bonus = 75;
        }
        // J (10) = 10 điểm
        else if (value === 10) {
          bonus = 70;
        }
        // 10 (9) = 10 điểm
        else if (value === 9) {
          bonus = 65;
        }
        // 9 (8) = 9 điểm
        else if (value === 8) {
          bonus = 50;
        }
        // 8 (7) = 8 điểm
        else if (value === 7) {
          bonus = 40;
        }
        // 7 (6) = 7 điểm
        else if (value === 6) {
          bonus = 30;
        }

        // Bonus thêm nếu rất cuối game (còn 5 lá trở xuống)
        if (myCardCount <= 5) {
          bonus *= 1.5;
        }
        // Bonus thêm nếu cực cuối (còn 3 lá)
        else if (myCardCount <= 3) {
          bonus *= 2.0;
        }
      }

      return Math.round(bonus);
    }

    /**
     * Tìm các lá có thể tạo sequence với lá này
     */
    findSequenceNeighbors(cardInfo) {
      const neighbors = [];
      const { suit, value } = cardInfo;

      // Lá trước (value - 1, value - 2)
      for (let offset = -2; offset <= -1; offset++) {
        const neighborValue = value + offset;
        if (neighborValue >= 0) {
          const neighborCard = neighborValue * 4 + suit;
          neighbors.push(neighborCard);
        }
      }

      // Lá sau (value + 1, value + 2)
      for (let offset = 1; offset <= 2; offset++) {
        const neighborValue = value + offset;
        if (neighborValue <= 12) {
          const neighborCard = neighborValue * 4 + suit;
          neighbors.push(neighborCard);
        }
      }

      return neighbors;
    }

    /**
     * Tìm các lá có thể tạo set với lá này (cùng giá trị, khác chất)
     */
    findSetNeighbors(cardInfo) {
      const neighbors = [];
      const { value } = cardInfo;

      // 3 lá khác chất cùng giá trị
      for (let suit = 0; suit < 4; suit++) {
        if (suit !== cardInfo.suit) {
          const neighborCard = value * 4 + suit;
          neighbors.push(neighborCard);
        }
      }

      return neighbors;
    }

    applyDifficultyToSafeDiscard(safetyScores) {
      return safetyScores
        .map((move) => {
          let adjustedScore = move.score;

          // Hard mode: luôn chọn an toàn nhất
          if (this.determineGamePhase() === "late") {
            adjustedScore *= 1.1; // Bonus ở cuối game
          }
          return { ...move, adjustedScore };
        })
        .sort((a, b) => b.adjustedScore - a.adjustedScore);
    }

    /**
     * Tạo reasoning message cho việc đánh bài - CHI TIẾT HƠN
     */
    generateDiscardReasoning(card, safetyScore) {
      const cardName = this.getCardName(card);
      const reasons = [];

      // 🔥 Priority 0: CHẮC CHẮN đối thủ không ăn được - UU TIÊN TUYỆT ĐỐI
      if (safetyScore.guaranteedSafeBonus >= 1500) {
        reasons.push("🔥🔥🔥 CHẮC CHẮN AN TOÀN - ĐỐI THỦ KHÔNG THỂ ĂN");
      } else if (safetyScore.guaranteedSafeBonus >= 800) {
        reasons.push("🔥🔥 RẤT CHẮC AN TOÀN - ưu tiên cao nhất");
      } else if (safetyScore.guaranteedSafeBonus >= 600) {
        reasons.push("🔥 KHẢ NĂNG CAO an toàn với đối thủ");
      } else if (safetyScore.guaranteedSafeBonus >= 400) {
        reasons.push("✅ tương đối an toàn với đối thủ");
      }

      // Priority 1: Đối thủ khó ăn được - logic cũ
      if (safetyScore.opponentCannotUseBonus <= -150) {
        reasons.push("🚫 ANALYZER CẢNH BÁO - đối thủ cần lá này");
      } else if (safetyScore.opponentCannotUseBonus >= 120) {
        reasons.push("🔥 ĐỐI THỦ KHÔNG ĂN ĐƯỢC - ưu tiên cao nhất");
      } else if (safetyScore.opponentCannotUseBonus >= 80) {
        reasons.push("✅ đối thủ khó ăn được");
      } else if (safetyScore.opponentCannotUseBonus >= 40) {
        reasons.push("tương đối an toàn với đối thủ");
      } else if (safetyScore.opponentCannotUseBonus === 0) {
        reasons.push("⚠️ đối thủ có thể ăn được");
      }

      // Priority 1: Lá rác
      if (safetyScore.trashCardBonus >= 90) {
        reasons.push("⭐ LÁ RÁC - ưu tiên đánh");
      } else if (safetyScore.trashCardBonus >= 60) {
        reasons.push("lá khó tạo phỏm");
      }

      // Priority 2: Cảnh báo phá phỏm
      if (safetyScore.phomPreservationPenalty > 0) {
        reasons.push("⚠️ PHÁ PHỎM - TRÁNH ĐÁNH");
      }

      // Priority 3: Cảnh báo phá combo
      if (safetyScore.comboBreakingPenalty > 60) {
        reasons.push("⚠️ phá combo tiềm năng");
      } else if (safetyScore.comboBreakingPenalty > 30) {
        reasons.push("giảm cơ hội tạo phỏm");
      }

      // Late game high card bonus - HIỂN THỊ RIÊNG VÌ QUAN TRỌNG
      if (safetyScore.lateGameHighCardBonus > 50) {
        reasons.push("🎯 CUỐI GAME - Chạy lá cao");
      } else if (safetyScore.lateGameHighCardBonus > 30) {
        reasons.push("chạy bài cao");
      }

      // Các yếu tố khác
      if (safetyScore.edgeBonus > 20) {
        reasons.push("lá biên an toàn");
      }
      if (safetyScore.deadCardBonus > 20) {
        reasons.push("nhiều lá liên quan đã chết");
      }
      if (safetyScore.isolationBonus > 20) {
        reasons.push("lá cô lập");
      }
      if (safetyScore.opponentPatternPenalty > 20) {
        reasons.push("đối thủ có thể cần");
      }
      if (safetyScore.chotPenalty < -5000) {
        reasons.push("🛑 RỦI RO BỊ ĂN CHỐT");
      }
      if (safetyScore.denLangPenalty < -10000) {
        reasons.push("🚨 RỦI RO ĐỀN LÀNG");
      }

      const reasonText =
        reasons.length > 0 ? reasons.join(", ") : "phân tích tổng hợp";

      return `Đánh ${cardName} - ${reasonText} (điểm: ${safetyScore.totalScore})`;
    }

    performOptimalDiscard(discardMove) {
      if (
        !discardMove ||
        !discardMove.cards ||
        discardMove.cards.length === 0
      ) {
        debug("[Phom Bot] No valid discard move");
        // Fix: always reset myTurn so bot doesn't get stuck
        this.myTurn = false;
        return;
      }

      const cardToDiscard = discardMove.cards[0];
      debug(`[Phom Bot] Discarding card: ${this.getCardName(cardToDiscard)}`);

      // Chọn lá bài để đánh với improved logic
      const success = this.selectCard(cardToDiscard);

      if (!success) {
        debug("[Phom Bot] Failed to select card, resetting turn state");
        // Fix: reset myTurn when card selection fails to prevent bot freeze
        this.myTurn = false;
        return;
      }
      this.cardSelected = cardToDiscard;
      this.lastDiscardedCard = cardToDiscard;
      // Đợi một chút rồi click nút đánh bài (nếu có)
      setTimeout(() => {
        this.clickGameButton("btn_danhBai");
        this.myTurn = false;
        debug("[Phom Bot] Discard action performed");
      }, 1000);
    }

    calculateMoveDelay() {
      let baseDelay =
        Math.random() * (this.playDelay.max - this.playDelay.min) +
        this.playDelay.min;
      const randomFactor = 0.8 + Math.random() * 0.4;
      return Math.round(baseDelay * randomFactor);
    }

    updateOpponentStrategy(data) {
      const { pattern, threatLevel } = data;

      // Cập nhật database về opponent patterns
      if (!this.opponentPatterns.has("threat_levels")) {
        this.opponentPatterns.set("threat_levels", []);
      }

      this.opponentPatterns.get("threat_levels").push({
        level: threatLevel,
        pattern: pattern,
        timestamp: Date.now(),
      });

      // Điều chỉnh strategy nếu opponent rất aggressive
      if (threatLevel > 8) {
        debug("[Phom Bot] High threat detected, switching to defensive");
        this.temporaryStrategy = "defensive";
        this.playDelay.min = Math.min(5000, this.playDelay.min + 1000);
      }
    }

    // Card analysis and probability calculations
    initCardProbabilities() {
      const probs = new Map();
      for (let i = 0; i < 52; i++) {
        probs.set(i, 1.0); // Initial probability of 1 for all cards
      }
      return probs;
    }

    parseCard(cardNumber) {
      if (cardNumber < 0 || cardNumber > 51) return null;

      const valueIndex = Math.floor(cardNumber / 4);
      const suitIndex = cardNumber % 4;

      const SUIT_CHARS = ["B", "T", "R", "C"];

      return {
        number: cardNumber,
        value: valueIndex,
        suit: suitIndex,
        valueName: VALUES[valueIndex],
        suitName: SUITS[suitIndex],
        suitChar: SUIT_CHARS[suitIndex], // ADD THIS
        isRed: suitIndex === 2 || suitIndex === 3,
      };
    }

    // Game state management
    onGameStart(data) {
      debug("[Phom Bot] Game started, resetting state");
      this.myCards = new Set();
      this.myPlayedCards = new Set();
      this.opponentPlayedCards = new Set();
      this.currentGameId = data.gameId;
      this.myTurn = false;
      this.isProcessingTurn = false;
      this.updateCardProbabilities();

      // Update session tracking
      this.gamesPlayedAtTable++;
      debug(`[Phom Bot] Game started. Session progress: ${this.gamesPlayedAtTable}/${this.maxGamesAtTable || 'Infinity'}`);
    }

    updateMyCards(cards) {
      this.myCards = new Set(cards);
      debug("[Phom Bot] Updated my cards:", cards.length);
      this.analyzePossibleMoves();
    }

    handleMyPhomCombinations(data) {
      if (!data || !data.combinations || !Array.isArray(data.combinations)) {
        debug("[Phom Bot] Invalid phom combinations data received");
        return;
      }

      debug("[Phom Bot] Processing my phom combinations:", data.combinations);
      const combinationList = data.combinations.reduce((acc, val) => acc.concat(val.cs), []);

      // Extract all cards from phom combinations and remove them from myCards
      let removedCards = [];

      combinationList.forEach((cardValue) => {
        if (this.myCards.has(cardValue)) {
          this.myCards.delete(cardValue);
          removedCards.push(cardValue);
        }
      });

      const previousSize = this.myCards.size + removedCards.length;
      const currentSize = this.myCards.size;

      debug(`[Phom Bot] Phom laid down - Cards removed: ${removedCards.length}, Hand size: ${previousSize} -> ${currentSize}`);
      debug(`[Phom Bot] Remaining cards in hand:`, [...this.myCards].map(c => this.getCardName(c)));

      // Update probabilities and re-analyze possible moves
      this.updateCardProbabilities();
      this.analyzePossibleMoves();

      // If hand is now empty or very small, consider different strategy
      if (this.myCards.size <= 2) {
        debug("[Phom Bot] Hand is very small after phom, switching to finishing strategy");
        this.currentStrategy = "aggressive";
      }
    }

    handleOpponentPhomCombinations(data) {
      if (!data || !data.combinations || !Array.isArray(data.combinations)) {
        debug("[Phom Bot] Invalid opponent phom combinations data received");
        return;
      }

      debug(`[Phom Bot] Opponent ${data.playerName} laid down phom:`, data.combinations);
      const combinationList = data.combinations.reduce((acc, val) => acc.concat(val.cs), []);
      // Track opponent's laid down cards for better analysis
      let opponentPhomCards = [];

      combinationList.forEach((cardValue) => {
        opponentPhomCards.push(cardValue);
        // Mark these cards as no longer available
        this.cardProbabilities.set(cardValue, 0);
      });

      debug(`[Phom Bot] Opponent revealed ${opponentPhomCards.length} cards:`,
        opponentPhomCards.map(c => this.getCardName(c)));

      // Update opponent analysis
      if (!this.opponentAnalysis.has(data.playerName)) {
        this.opponentAnalysis.set(data.playerName, {
          phomCombinations: [],
          revealedCards: new Set(),
          estimatedHandSize: 10 // Starting assumption
        });
      }
      const analysis = this.opponentAnalysis.get(data.playerName);

      // Khởi tạo các trường nếu thiếu (đề phòng được tạo từ hàm khác)
      if (!analysis.phomCombinations) analysis.phomCombinations = [];
      if (!analysis.revealedCards) analysis.revealedCards = new Set();
      if (analysis.estimatedHandSize === undefined) analysis.estimatedHandSize = 10;

      analysis.phomCombinations.push(...data.combinations);
      opponentPhomCards.forEach(card => analysis.revealedCards.add(card));
      analysis.estimatedHandSize -= opponentPhomCards.length;
      this.updateCardProbabilities();
    }

    onMyCardsPlayed(cards) {
      if (!cards || !Array.isArray(cards)) return;

      cards.forEach((card) => {
        this.myPlayedCards.add(card);
        this.myCards.delete(card);
      });

      this.updateCardProbabilities();
      debug("[Phom Bot] My cards played:", cards);
    }

    onOpponentCardsPlayed(cards) {
      if (!cards || !Array.isArray(cards)) return;

      cards.forEach((card) => {
        this.opponentPlayedCards.add(card);
        this.cardProbabilities.set(card, 0); // Card no longer available
      });

      this.analyzeOpponentPattern(cards);
      this.updateCardProbabilities();
      debug("[Phom Bot] Opponent cards played:", cards);
    }


    countPlayerIcons() {
      const scene = cc.director.getScene();
      let readyCount = 0;
      let hostCount = 0;

      function hasVisibleChild(node, targetName) {
        let found = false;
        function traverse(n) {
          if (n.name === targetName && n.activeInHierarchy) {
            found = true;
          }
          n.children.forEach(traverse);
        }
        traverse(node);
        return found;
      }

      function traverse(node) {
        if (/^player_\d+$/.test(node.name)) {
          const hasReady = hasVisibleChild(node, "ig_icon_ready");
          const hasHost = hasVisibleChild(node, "ig_host_icon");

          if (hasReady) {
            readyCount++;
            debug(`✅ ${node.name} có ig_icon_ready [Hiện]`);
          }
          if (hasHost) {
            hostCount++;
            debug(`⭐ ${node.name} có ig_host_icon [Hiện]`);
          }
          if (!hasReady && !hasHost) {
            debug(`❌ ${node.name} không có ready/host icon [Hiện]`);
          }
        }

        node.children.forEach(traverse);
      }

      traverse(scene);

      debug(`📊 Tổng số player có ig_icon_ready [Hiện]: ${readyCount}`);
      debug(`📊 Tổng số player có ig_host_icon [Hiện]: ${hostCount}`);

      return { readyCount, hostCount };
    }

    countPlayerVisible() {
      // const scene = this.getScene();
      // const players = new Set();
      // function traverse(node) {
      //   if (node.name === "lbl_displayName" && node.active) {
      //     try {
      //       const label = node.getComponent(cc.Label);
      //       const name = label?.string?.trim();
      //       if (name) {
      //         players.add(name);
      //       }
      //     } catch (e) { }
      //   }
      //   node.children.forEach(traverse);
      // }
      // traverse(scene);
      // return Array.from(players).filter(
      //   (name) =>
      //     !name.includes("contackegmaunau7") && !name.includes("khuongkieu")
      // ).length;

      const { readyCount, hostCount } = this.countPlayerIcons();
      return readyCount + hostCount;
    }

    onGameEnd(data) {
      this.gameHistory.push({
        gameId: this.currentGameId,
        result: {},
        myFinalCards: Array.from(this.myCards),
        opponentFinalCards: data.opponentCards,
        moves: this.lastAction,
      });
      this.analyzeGamePerformance();
      const numberPlayerVisible = this.countPlayerVisible();
      debug(
        `[Phom Bot] Game ended. Total ready currently: ${numberPlayerVisible}`
      );
      this.numberOfPlayers = numberPlayerVisible;

      // Rule check: 2 opponents ready (Total 3) played enough games
      if (this.maxGamesAtTable > 0 && this.gamesPlayedAtTable >= this.maxGamesAtTable) {
        debug(`[Phom Bot] Rule 2: Limit of ${this.maxGamesAtTable} games reached. Leaving table.`);
        window.postMessage({ type: "PHOM_MONITOR_MUST_LEAVE" }, "*");
        return;
      }

      // Rule check: 3 opponents ready (Total 4)
      if (numberPlayerVisible >= 4) {
        debug("[Phom Bot] Rule 3: Table is crowded. Leaving table.");
        window.postMessage({ type: "PHOM_MONITOR_MUST_LEAVE" }, "*");
        return;
      }

      // Rule check: 1 opponent ready (Total 2) OR Rule 2 (Total 3) with games left
      if (numberPlayerVisible >= 2) {
        this.tryStartCnt = 0;
        this.onStartGameCheck();
      } else {
        debug("[Phom Bot] Waiting for more players to be ready...");
      }
    }

    resetGame() {
      this.myCards.clear();
      this.myPlayedCards.clear();
      this.opponentPlayedCards.clear();
      this.myTurn = false;
      this.isProcessingTurn = false; // Fix: ensure lock is always released on reset
      this.currentGameId = null;
      this.cardProbabilities = this.initCardProbabilities();
      this.lastDiscardedCard = null;
      this.timesMyCardEaten = 0;

      // Fix: clear any pending startGameCheck interval to prevent zombie intervals
      if (this.startCheckIntervalId) {
        clearInterval(this.startCheckIntervalId);
        this.startCheckIntervalId = null;
      }

      if (this.fallbackIntervalId) {
        clearInterval(this.fallbackIntervalId);
        this.fallbackIntervalId = null;
      }

      // Reset thông tin từ analyzer
      if (this.opponentAnalysis) {
        this.opponentAnalysis.clear();
      }
      if (this.dangerousCardsFromAnalyzer) {
        this.dangerousCardsFromAnalyzer.clear();
      }
    }

    // Advanced card analysis
    updateCardProbabilities() {
      const totalCards = 52;
      const playedCards = new Set([
        ...this.myPlayedCards,
        ...this.opponentPlayedCards,
      ]);
      const knownCards = new Set([...this.myCards, ...playedCards]);

      // Update probabilities based on known information
      for (let i = 0; i < totalCards; i++) {
        if (playedCards.has(i)) {
          this.cardProbabilities.set(i, 0);
        } else if (this.myCards.has(i)) {
          this.cardProbabilities.set(i, 1);
        } else {
          // Estimate probability based on remaining unknown cards
          const remainingUnknown = totalCards - knownCards.size;
          this.cardProbabilities.set(i, 1.0 / Math.max(1, remainingUnknown));
        }
      }
    }

    analyzePossibleMoves() {
      const myCardsArray = Array.from(this.myCards);
      const combinations = this.findAllCombinations(myCardsArray);

      this.winningCombinations = combinations.filter((combo) =>
        this.isWinningCombination(combo)
      );

      debug(
        "[Phom Bot] Found",
        this.winningCombinations.length,
        "winning combinations"
      );
      return combinations;
    }

    findAllCombinations(cards) {
      const combinations = [];

      // Find sequences (runs)
      const sequences = this.findSequences(cards);
      combinations.push(...sequences);

      // Find sets (same value)
      const sets = this.findSets(cards);
      combinations.push(...sets);

      return combinations;
    }

    findSequences(cards) {
      const sequences = [];
      const cardsBySuit = this.groupCardsBySuit(cards);

      Object.keys(cardsBySuit).forEach((suit) => {
        const suitCards = cardsBySuit[suit].sort(
          (a, b) => this.parseCard(a).value - this.parseCard(b).value
        );

        for (let i = 0; i < suitCards.length - 2; i++) {
          for (let j = i + 2; j < suitCards.length; j++) {
            const sequence = suitCards.slice(i, j + 1);
            if (this.isValidSequence(sequence)) {
              sequences.push({
                type: "sequence",
                cards: sequence,
                score: this.calculateSequenceScore(sequence),
              });
            }
          }
        }
      });

      return sequences;
    }

    findSets(cards) {
      const sets = [];
      const valueGroups = {};

      cards.forEach((card) => {
        const parsed = this.parseCard(card);
        if (!valueGroups[parsed.value]) {
          valueGroups[parsed.value] = [];
        }
        valueGroups[parsed.value].push(card);
      });

      Object.values(valueGroups).forEach((group) => {
        if (group.length >= 3) {
          sets.push({
            type: "set",
            cards: group,
            score: this.calculateSetScore(group),
          });
        }
      });

      return sets;
    }

    groupCardsBySuit(cards) {
      const groups = {};
      cards.forEach((card) => {
        const parsed = this.parseCard(card);
        if (!groups[parsed.suit]) {
          groups[parsed.suit] = [];
        }
        groups[parsed.suit].push(card);
      });
      return groups;
    }

    isValidSequence(sequence) {
      if (sequence.length < 3) return false;

      for (let i = 1; i < sequence.length; i++) {
        const prev = this.parseCard(sequence[i - 1]);
        const curr = this.parseCard(sequence[i]);

        if (curr.value !== prev.value + 1 || curr.suit !== prev.suit) {
          return false;
        }
      }

      return true;
    }

    calculateSequenceScore(sequence) {
      // Higher score for longer sequences and higher value cards
      const length = sequence.length;
      const avgValue =
        sequence.reduce((sum, card) => sum + this.parseCard(card).value, 0) /
        length;

      return length * 10 + avgValue;
    }

    calculateSetScore(set) {
      // Higher score for more cards and higher values
      const length = set.length;
      const value = this.parseCard(set[0]).value;

      return length * 15 + value;
    }

    isWinningCombination(combination) {
      // Analyze if this combination leads to a high probability win
      const remainingCards = Array.from(this.myCards).filter(
        (card) => !combination.cards.includes(card)
      );

      return remainingCards.length <= 3 && combination.score > 50;
    }

    getOKButton() {
      try {
        const scene = this.getScene();
        if (!scene) {
          debug("[Phom Bot] No active scene found for OK button");
          return null;
        }
        const commonPopup = this.findNodeByName(scene, "BasePopupController");
        if (!commonPopup) {
          debug("❌ Không tìm thấy commonPopup trong scene");
          return null;
        }

        const okButton = this.findNodeByName(commonPopup, "btn_ok");
        if (!okButton) {
          debug("❌ Không tìm thấy btn_ok đang hiển thị");
          return null;
        }

        return okButton;
      } catch (error) {
        debug("[Phom Bot] Error getting OK button:", error);
        return null;
      }
    }

    getAvailableButtons() {
      const buttonNames = [
        "btn_batdau",
        "btn_sansang",
        "btn_anBai2",
        "btn_rutBai2",
        "btn_xepBai",
        "btn_guiBai",
        "btn_haPhom",
        "btn_baoU",
        "btn_danhBai",
      ];

      const availableButtons = [];

      try {
        const scene = this.getScene();
        debug(
          "[Phom Bot] Retrieved game scene for button check",
          scene ? "success" : "failed"
        );
        if (scene) {
          buttonNames.forEach((buttonName) => {
            const button = this.findNodeByName(scene, buttonName);
            // debug(
            //   `[Phom Bot] Checking button ${buttonName}:`, button ? "found" : "not found"
            // );
            if (button && this.isButtonVisible(button)) {
              availableButtons.push(buttonName);
            }
          });
        }
        debug("[Phom Bot] getAvailableButtons:", availableButtons);
      } catch (error) {
        debug("[Phom Bot] Error finding available buttons:", error);
      }

      return availableButtons;
    }

    getCardName(cardNumber) {
      const parsed = this.parseCard(cardNumber);
      return `${parsed.valueName}${parsed.suitName}`;
    }

    /**
     * Kiểm tra xem toàn bộ đối thủ đã hạ bài chưa (mình là người đánh/hạ cuối)
     */
    isLastToLowerCards() {
      const totalOpponents = this.opponentAnalysis.size;
      if (totalOpponents === 0) return false;

      let opponentsFinished = 0;
      this.opponentAnalysis.forEach((analysis) => {
        if ((analysis.phomCombinations && analysis.phomCombinations.length > 0) ||
          (analysis.revealedCards && analysis.revealedCards.size > 0)) {
          opponentsFinished++;
        }
      });

      return opponentsFinished === totalOpponents;
    }

    determineGamePhase() {
      const myCardCount = this.myCards.size;
      const totalDiscarded = (this.myPlayedCards ? this.myPlayedCards.size : 0) +
        (this.opponentPlayedCards ? this.opponentPlayedCards.size : 0);

      const players = Math.max(2, this.numberOfPlayers || 4); // assume at least 2 players

      // Vòng chốt: số bài đã đánh trên bàn >= số người chơi * 3
      if (totalDiscarded >= players * 3 - 1) return "late";

      // Nếu bài trên tay đã hạ phỏm (còn rất ít)
      if (myCardCount <= 5) return "late";

      // 2 nước đầu (mỗi người đánh nhiều nhất 2 lá)
      if (totalDiscarded < players * 2) return "early";

      return "mid";
    }

    analyzeOpponentPattern(cards) {
      // Analyze opponent playing patterns for future prediction
      const pattern = {
        timestamp: Date.now(),
        cards: cards,
        gamePhase: this.determineGamePhase(),
      };

      if (!this.opponentPatterns.has("recent")) {
        this.opponentPatterns.set("recent", []);
      }

      this.opponentPatterns.get("recent").push(pattern);

      // Keep only recent patterns (last 10 moves)
      if (this.opponentPatterns.get("recent").length > 10) {
        this.opponentPatterns.get("recent").shift();
      }
    }

    clickGameButton(buttonName) {
      try {
        if (!this.isCocosAvailable()) {
          debug("[Phom Bot] Cocos2d not available");
          return false;
        }

        const scene = this.getScene();
        if (!scene) {
          debug("[Phom Bot] No active scene found");
          return false;
        }

        // Find the button in the game UI
        const button = this.findNodeByName(scene, buttonName);

        if (button && this.isButtonVisible(button)) {
          debug(`[Phom Bot] Clicking button: ${buttonName}`);

          // Simulate human-like click
          this.triggerCocosClick(button);
          return true;
        } else {
          debug(`[Phom Bot] Button ${buttonName} not found or not visible`);
          return false;
        }
      } catch (error) {
        console.error(`[Phom Bot] Error clicking button ${buttonName}:`, error);
        return false;
      }
    }

    isButtonVisible(button) {
      if (!button) return false;
      const active = button.active !== undefined ? button.active : true;
      return active;
    }


    triggerCocosClick(node) {
      const createTouchEvent = (x, y) => {
        const event = new cc.Event.EventTouch([{ x, y }], 0);
        event.getLocation = () => ({ x, y });
        return event;
      };
      try {
        const startEvent = createTouchEvent(0, 0);
        node.emit(cc.Node.EventType.TOUCH_START, startEvent);
        const endEvent = createTouchEvent(0, 0);
        node.emit(cc.Node.EventType.TOUCH_END, endEvent);
      } catch (error) {
        debug("[Phom Bot] Error triggering cocos click:", error);
      }
    }

    parseCardSprite(spriteName) {
      if (!spriteName || spriteName === "Card_bc") {
        return { value: null, suit: null, hidden: true };
      }

      const match = spriteName.match(/^Card_(\d+)([TCRB])$/);
      if (!match) {
        return {
          value: null,
          suit: null,
          error: `Invalid sprite: ${spriteName}`,
        };
      }

      const spriteValue = parseInt(match[1]); // 1-13
      const suitChar = match[2]; // B, T, R, C

      const suitCharToIndex = {
        B: 0, // Bích (♠) - Spades
        T: 1, // Tép (♣) - Clubs
        R: 2, // Rô (♦) - Diamonds
        C: 3, // Cơ (♥) - Hearts
      };

      const suitIndex = suitCharToIndex[suitChar];
      if (suitIndex === undefined) {
        return { value: null, suit: null, error: `Invalid suit: ${suitChar}` };
      }

      const valueIndex = spriteValue - 1;

      const suitMap = {
        B: { name: "Bích", symbol: "♠", emoji: "♠️", color: "black" },
        T: { name: "Chuồn (Tép)", symbol: "♣", emoji: "♣️", color: "black" },
        R: { name: "Rô", symbol: "♦", emoji: "♦️", color: "red" },
        C: { name: "Cơ", symbol: "♥", emoji: "❤️", color: "red" },
      };

      let displayValue;
      if (spriteValue === 1) displayValue = "A";
      else if (spriteValue === 11) displayValue = "J";
      else if (spriteValue === 12) displayValue = "Q";
      else if (spriteValue === 13) displayValue = "K";
      else displayValue = spriteValue.toString();

      const suit = suitMap[suitChar];

      const cardNumber = valueIndex * 4 + suitIndex;

      return {
        cardNumber: cardNumber,
        value: valueIndex, // 0-12
        displayValue: displayValue,
        suit: suit,
        suitChar: suitChar,
        suitIndex: suitIndex,
        cardName: `${displayValue}${suit.symbol}`,
        cardCode: `${spriteValue}${suitChar}`,
        sprite: spriteName,
        hidden: false,
      };
    }

    getPlayerCards() {
      try {
        const cardNode = this.findNodeByName("card_node");
        if (!cardNode) {
          debug("[Phom Bot] card_node not found");
          return {
            all: [],
            visible: [],
            hidden: [],
            summary: { total: 0, visible: 0, hidden: 0 },
          };
        }

        const cards = [];
        const visibleCards = [];
        const hiddenCards = [];

        cardNode.children.forEach((cardChild, index) => {
          if (cardChild.name === "card" && cardChild.active) {
            const sprite = cardChild.getComponent(cc.Sprite);
            const spriteName = sprite?.spriteFrame?.name || "unknown";

            const cardInfo = this.parseCardSprite(spriteName);

            // Kiểm tra component thứ 3 để xác định bài thật
            const hasCardObject =
              cardChild._components &&
              cardChild._components[2] &&
              cardChild._components[2].card !== undefined;

            const cardData = {
              index: index + 1,
              sprite: spriteName,
              position: {
                x: Math.round(cardChild.worldPosition.x * 10) / 10,
                y: Math.round(cardChild.worldPosition.y * 10) / 10,
              },
              node: cardChild, // Fix: store cc node ref for direct triggerCocosClick (avoid misclick)
              internalId: cardChild._components?.[1]?._internalId || "unknown",
              hasCardObject: hasCardObject,
              ...cardInfo,
            };

            cards.push(cardData);

            if (cardInfo.hidden) {
              hiddenCards.push(cardData);
            } else if (hasCardObject) {
              visibleCards.push(cardData);
            }
          }
        });

        debug(
          `[Phom Bot] getPlayerCards - Total: ${cards.length}, Visible: ${visibleCards.length}, Hidden: ${hiddenCards.length}`
        );

        return {
          all: cards,
          visible: visibleCards,
          hidden: hiddenCards,
          summary: {
            total: cards.length,
            visible: visibleCards.length,
            hidden: hiddenCards.length,
          },
        };
      } catch (error) {
        debug(`[Phom Bot] Error in getPlayerCards:`, error);
        return {
          all: [],
          visible: [],
          hidden: [],
          summary: { total: 0, visible: 0, hidden: 0 },
        };
      }
    }

    clickByCoordinates(worldX, worldY) {
      const canvasEl = document.querySelector("canvas");
      if (!canvasEl) return false;

      const rect = canvasEl.getBoundingClientRect();

      const canvas = cc.find("Canvas");
      const camera = canvas.getComponentInChildren(cc.Camera);

      if (!camera) {
        debug("❌ Camera not found");
        return false;
      }

      const worldPos = cc.v3(worldX, worldY, 0);

      const screenPos = camera.worldToScreen(worldPos);

      const scaleX = rect.width / canvasEl.width;
      const scaleY = rect.height / canvasEl.height;

      const x = rect.left + screenPos.x * scaleX;
      const y = rect.top + (rect.height - screenPos.y * scaleY);

      // ✅ SAFETY GUARD: Cards always live in the bottom 60% of canvas (high DOM y values).
      // If computed y is in the TOP 40% (low DOM y), coordinate conversion failed —
      // clicking there would hit opponent avatars. Abort.
      const safeYThreshold = rect.top + rect.height * 0.4;
      if (y < safeYThreshold) {
        debug(`[Phom Bot] ⚠️ clickByCoordinates ABORTED: computed y=${Math.round(y)} is in avatar zone (top 40%). worldPos=(${worldX},${worldY})`);
        return false;
      }

      const evt = new MouseEvent("mousedown", {
        bubbles: true,
        clientX: x,
        clientY: y,
      });

      const evtUp = new MouseEvent("mouseup", {
        bubbles: true,
        clientX: x,
        clientY: y,
      });

      canvasEl.dispatchEvent(evt);
      canvasEl.dispatchEvent(evtUp);

      return true;
    }

    selectCard(cardNumber) {
      try {
        debug(`[Phom Bot] Attempting to select card: ${cardNumber}`);

        // Parse the target card to get its sprite information
        const targetCardInfo = this.parseCard(cardNumber);
        if (!targetCardInfo) {
          debug(`[Phom Bot] Invalid card number: ${cardNumber}`);
          return false;
        }

        const spriteValue = targetCardInfo.value + 1;
        const spriteSuit = targetCardInfo.suitChar;
        const expectedSprite = `Card_${spriteValue}${spriteSuit}`;
        debug(
          `[Phom Bot] Looking for sprite: ${expectedSprite} (card ${cardNumber}: ${targetCardInfo.valueName}${targetCardInfo.suitName})`
        );

        // Lấy danh sách thẻ bài hiện tại
        const playerCards = this.getPlayerCards();
        if (!playerCards.visible || playerCards.visible.length === 0) {
          debug("[Phom Bot] No visible cards available");
          return false;
        }

        const currentVisibles = playerCards.visible;

        // Tính toán toạ độ Y thấp nhất (y gốc của bộ bài khi chưa được click)
        let minY = 999999;
        currentVisibles.forEach(c => {
          if (c.position.y < minY) minY = c.position.y;
        });

        // Những lá có y nhô cao hơn minY + 10 đơn vị được coi là ĐANG CHỌN
        const thresholdY = minY + 10;
        let targetCard = null;

        // Đảm bảo KIỂM SOÁT TÌNH TRẠNG CHỌN BÀI (Chữa lỗi chọn 2 quân cùng lúc)
        for (const card of currentVisibles) {
          const isRaised = card.position.y > thresholdY;
          const isTarget = (card.sprite === expectedSprite);

          if (isTarget) {
            targetCard = card;
          }

          // Nếu lá bài này ĐANG NHÔ LÊN nhưng KHÔNG PHẢI là mục tiêu -> CLICK để hạ nó xuống (unselect)
          if (isRaised && !isTarget) {
            if (card.node) {
              this.triggerCocosClick(card.node);
            } else {
              this.clickByCoordinates(card.position.x, card.position.y);
            }
            debug(`[Phom Bot] Phát hiện lá ${card.sprite} đang nhầm chọn (nhô cao), tự động un-click.`);
          }
        }

        if (!targetCard) {
          debug(`[Phom Bot] ❌ Không tìm thấy quân bài với sprite: ${expectedSprite}`);
          return false;
        }

        // Ngược lại, nếu mục tiêu chưa nhô lên thì ta click nó
        const isTargetCurrentlyRaised = targetCard.position.y > thresholdY;

        if (!isTargetCurrentlyRaised) {
          debug(`[Phom Bot] ✅ Click chọn lá mục tiêu: ${expectedSprite} tại vị trí (${targetCard.position.x}, ${targetCard.position.y})`);
          const success = this.clickByCoordinates(targetCard.position.x, targetCard.position.y);
          if (success) {
            this.myCards.delete(cardNumber);
            return true;
          } else {
            debug(`[Phom Bot] Failed to click card via coordinates: ${expectedSprite}`);
            return false;
          }
        } else {
          debug(`[Phom Bot] ✅ Lá mục tiêu ${expectedSprite} đã nhô sẵn (đã được chọn), bỏ qua click.`);
          this.myCards.delete(cardNumber);
          return true;
        }

      } catch (error) {
        debug(`[Phom Bot] Error selecting card ${cardNumber}: ${error}`);
        return false;
      }
    }

    // Helper method để tìm node theo tên - updated to match test.js implementation
    findNodeByName(rootNode, targetName) {
      // If only one parameter provided, use scene as root (like test.js)
      if (arguments.length === 1) {
        targetName = rootNode;
        rootNode = this.getScene();
      }
      return this.findNodeDeep(rootNode, targetName);
    }

    findNodeDeep(node, targetName) {
      if (!node) return null;
      if (node.name === targetName) return node;
      if (node.children && node.children.length > 0) {
        for (const child of node.children) {
          const found = this.findNodeDeep(child, targetName);
          if (found) return found;
        }
      }

      return null;
    }

    sendSocketMessage(data) {
      // Fallback method to send socket message when button click fails
      window.postMessage(
        {
          type: "PHOM_BOT_SOCKET_MESSAGE",
          data: data,
        },
        "*"
      );
    }

    // Performance analysis
    analyzeGamePerformance() {
      if (this.gameHistory.length < 5) return;

      const recentGames = this.gameHistory.slice(-10);
      const winRate =
        recentGames.filter((game) => game.result === "win").length /
        recentGames.length;

      debug(
        "[Phom Bot] Win rate (last 10 games):",
        (winRate * 100).toFixed(1) + "%"
      );

      // Adjust strategy based on performance
      if (winRate < 0.6) {
        this.adjustStrategy("more_aggressive");
      } else if (winRate > 0.8) {
        this.adjustStrategy("more_conservative");
      }
    }

    adjustStrategyBasedOnOpponentPhom(playerName, opponentData) {
      const opponentPhomCount = opponentData.phomCombinations.length;
      const estimatedRemainingCards = opponentData.estimatedHandSize;

      debug(`[Phom Bot] Adjusting strategy - ${playerName} has ${opponentPhomCount} phom(s), estimated ${estimatedRemainingCards} cards left`);

      // If opponent has multiple phoms or very few cards left, play more aggressively
      if (opponentPhomCount >= 2 || estimatedRemainingCards <= 3) {
        debug("[Phom Bot] Opponent is close to winning, switching to aggressive strategy");
        this.currentStrategy = "aggressive";
        this.adjustStrategy("more_aggressive");
      }
      // If opponent has strong phoms early, play more defensively
      else if (opponentPhomCount === 1 && this.myCards.size > 8) {
        debug("[Phom Bot] Opponent has strong early phom, playing more defensively");
        this.currentStrategy = "defensive";
        this.adjustStrategy("more_conservative");
      }
    }

    adjustStrategy(adjustment) {
      switch (adjustment) {
        case "more_aggressive":
          this.playDelay.min = Math.max(1000, this.playDelay.min - 200);
          this.playDelay.max = Math.max(2000, this.playDelay.max - 500);
          debug("[Phom Bot] Adjusted to more aggressive strategy");
          break;
        case "more_conservative":
          this.playDelay.min = Math.min(5000, this.playDelay.min + 200);
          this.playDelay.max = Math.min(8000, this.playDelay.max + 500);
          debug("[Phom Bot] Adjusted to more conservative strategy");
          break;
      }
    }

    // Settings and configuration
    toggleBot(enabled) {
      this.isEnabled = enabled;
      if (enabled) {
        this.startFallbackInterval();
      } else if (this.fallbackIntervalId) {
        clearInterval(this.fallbackIntervalId);
        this.fallbackIntervalId = null;
        debug("[Phom Bot] Fallback interval stopped");
      }
      debug("[Phom Bot]", enabled ? "Enabled" : "Disabled");
    }

    updateSettings(settings) {
      if (settings.difficulty) {
        this.difficulty = settings.difficulty;
        this.adjustDifficultySettings();
      }

      if (settings.playDelay) {
        this.playDelay = settings.playDelay;
      }

      debug("[Phom Bot] Settings updated:", settings);
    }

    adjustDifficultySettings() {
      switch (this.difficulty) {
        case "easy":
          this.playDelay = { min: 3000, max: 6000 };
          break;
        case "medium":
          this.playDelay = { min: 2000, max: 4000 };
          break;
        case "hard":
          this.playDelay = { min: 1000, max: 3000 };
          break;
      }
    }

    loadSettings() {
      // Load settings from chrome storage
      if (typeof chrome !== "undefined" && chrome.storage) {
        chrome.storage.local.get(["phomBotSettings"], (result) => {
          if (result.phomBotSettings) {
            this.updateSettings(result.phomBotSettings);
          }
        });
      }
    }

    saveSettings() {
      if (typeof chrome !== "undefined" && chrome.storage) {
        const settings = {
          difficulty: this.difficulty,
          playDelay: this.playDelay,
          isEnabled: this.isEnabled,
        };

        chrome.storage.local.set({ phomBotSettings: settings });
      }
    }
  }

  // Initialize the bot
  window.phomBot = new PhomBot();
  debug("[Phom Bot] Advanced AI Bot loaded successfully");
})();
