(() => {
  function createDebugConsole() {
    try {
      const iframe = document.createElement("iframe");
      iframe.style.display = "none";
      (document.body || document.documentElement).appendChild(iframe);
      return iframe.contentWindow.console.log.bind(
        iframe.contentWindow.console
      );
    } catch (e) {
      console.error("[Phom Monitor] Lỗi tạo debug console:", e);
      return console.log.bind(console);
    }
  }

  const debug = createDebugConsole();

  function createTouchEvent(x, y) {
    const event = new cc.Event.EventTouch([{ x, y }], 0);
    // override getLocation để trả đúng tọa độ
    event.getLocation = () => ({ x, y });
    return event;
  }

  // Hàm tìm node theo tên đệ quy
  function findNodeDeep(name, node) {
    if (!node) return null;
    if (node.name === name) return node;
    for (let child of node.children) {
      const found = findNodeDeep(name, child);
      if (found) return found;
    }
    return null;
  }

  function findNodeByName(name) {
    return findNodeDeep(name, cc.director.getScene());
  }

  const prefab_phom = findNodeByName("prefab_phom");
  const btn_caidat = findNodeDeep("btn_caidat", prefab_phom);
  if (!btn_caidat) {
    debug("Không tìm thấy node btn_caidat");
    return;
  }
  const startEvent = createTouchEvent(0, 0);
  btn_caidat.emit(cc.Node.EventType.TOUCH_START, startEvent);
  const endEvent = createTouchEvent(0, 0);
  btn_caidat.emit(cc.Node.EventType.TOUCH_END, endEvent);

  const leave_table = findNodeByName("btn_out_table");
  if (!leave_table) {
    debug("Không tìm thấy node btn_out_table");
    return;
  }
  const startEvent2 = createTouchEvent(0, 0);
  leave_table.emit(cc.Node.EventType.TOUCH_START, startEvent2);
  const endEvent2 = createTouchEvent(0, 0);
  leave_table.emit(cc.Node.EventType.TOUCH_END, endEvent2);

  debug("Đã rời bàn");
})();
