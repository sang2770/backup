/**
 * PHOM GAME MESSAGE ANALYZER
 * 
 * Receives raw game messages from inject.js và phân tích thành structured data
 * Gửi analyzed data cho phom-bot.js để bot có thể make optimal decisions
 * 
 * RESPONSIBILITIES:
 * - Parse và analyze game messages
 * - Calculate hand strength và combinations
 * - Analyze opponent patterns và threat levels
 * - Generate recommended moves
 * - Send structured data to bot via PHOM_ANALYZER_EVENT
 */
(function () {

  function createDebugConsole() {
    try {
      const iframe = document.createElement("iframe");
      iframe.style.display = "none";
      (document.body || document.documentElement).appendChild(iframe);
      return iframe.contentWindow.console.log.bind(
        iframe.contentWindow.console
      );
    } catch (e) {
      console.error("[Phom Monitor] Lỗi tạo debug console:", e);
      return console.log.bind(console);
    }
  }

  const debug = createDebugConsole();
  class PhomGameAnalyzer {
    constructor() {
      this.gameState = {
        myCards: new Set(),
        currentPlayer: null,
        gamePhase: 'waiting', // waiting, playing, finished
        lastAction: null,
        opponentEatenCards: new Map(), // Map<playerName, Set<cardId>>
        opponentSequences: new Map(), // Map<playerName, Array<sequenceInfo>>
        dangerousCards: new Set() // Lá bài không nên đánh vì đối thủ có thể cần
      };

      this.cardMapping = this.initCardMapping();
      this.isCheckFirst = false; // Fix: must be instance property, not local var inside analyzeGameMessage
      this.setupMessageListener();
      debug("[Phom Analyzer] Initialized game message analyzer");
    }

    initCardMapping() {
      // Tạo mapping từ số thành bài để dễ phân tích
      const mapping = new Map();
      const suits = ['♠', '♣', '♦', '♥'];
      const values = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

      for (let i = 0; i < 52; i++) {
        const valueIndex = Math.floor(i / 4);
        const suitIndex = i % 4;
        mapping.set(i, {
          id: i,
          value: valueIndex,
          suit: suitIndex,
          display: values[valueIndex] + suits[suitIndex],
          numericValue: valueIndex + 1,
          isRed: suitIndex === 2 || suitIndex === 3
        });
      }

      return mapping;
    }

    setupMessageListener() {
      // Listen for PHOM_MONITOR messages để phân tích
      window.addEventListener("message", (event) => {
        if (event.source !== window) return;
        const { type, data } = event.data;
        // Chỉ xử lý các message PHOM_MONITOR từ inject.js và tracker
        if (type && type.includes('PHOM_MONITOR')) {
          this.analyzeGameMessage({ type, data });
        }
      });
    }

    analyzeGameMessage(message) {
      if (!message || !message.type) return;
      const { type, data } = message;
      switch (type) {
        case 'PHOM_MONITOR_INIT':
          // Fix: reset isCheckFirst when new game starts
          this.isCheckFirst = false;
          this.onGameStart(data);
          break;

        case 'PHOM_MONITOR_MY_CARDS':
          this.onReceiveMyCards(data.cards);
          // Fix: isCheckFirst is now instance property so it persists across calls
          if (!this.isCheckFirst) {
            this.isCheckFirst = true;
            this.onMyTurn({
              turn: true
            })
          }
          break;

        case 'PHOM_MONITOR_OPPONENT_EAT_CARD':
          this.onOpponentEatCard(data.playerName, data.cs);
          break;

        case 'PHOM_MONITOR_MY_PLAYED_CARDS':
          this.onMyCardsPlayed(data.dCs);
          break;

        case 'PHOM_MONITOR_OPPONENT_PLAYED_CARDS':
          this.onOpponentCardsPlayed(data.dCs);
          break;

        case 'PHOM_MONITOR_MY_TURN':
          this.onMyTurn(data);
          break;

        case 'PHOM_MONITOR_USER_JOIN':
          this.onGameCheckStart(data);
          break;

        case 'PHOM_MONITOR_GAME_END':
          this.onGameEnd();
          break;

        case 'PHOM_MONITOR_USER_LEAVE':
          this.onUserLeave();
          break;
      }
    }

    onGameStart(data) {
      if (this.gameState.gamePhase === 'playing') {
        debug("[Phom Analyzer] Game already in progress, ignoring start event");
        return;
      }
      debug("[Phom Analyzer] Game started");
      this.gameState = {
        myCards: new Set(),
        currentPlayer: null,
        gamePhase: 'playing',
        lastAction: null,
        gameId: data.gameId,
        opponentEatenCards: new Map(), // Reset thông tin đối thủ
        opponentSequences: new Map(),
        dangerousCards: new Set()
      };

      // Thông báo cho bot
      this.notifyBot('GAME_START', {
        gameId: data.gameId,
        initialCards: 0
      });
    }

    onReceiveMyCards(cards) {
      debug("[Phom Analyzer] Received my cards:", cards);

      this.gameState.myCards = new Set(cards);

      // Phân tích bài khởi tạo
      const analysis = this.analyzeInitialHand(cards);

      this.notifyBot('MY_CARDS_RECEIVED', {
        cards: cards,
        analysis: analysis
      });
    }

    onMyCardsPlayed(cards) {
      debug("[Phom Analyzer] I played cards:", cards);

      cards.forEach(card => {
        this.gameState.myCards.delete(card);
      });

      this.gameState.lastAction = {
        type: 'MY_PLAY',
        cards: cards,
        timestamp: Date.now()
      };

      this.notifyBot('MY_CARDS_PLAYED', {
        cards: cards,
        remainingCards: Array.from(this.gameState.myCards)
      });
    }

    onOpponentEatCard(playerName, cardNumber) {
      debug(`[Phom Analyzer] Opponent ${playerName} ate card:`, cardNumber);

      // Lưu trữ lá bài đối thủ đã ăn
      if (!this.gameState.opponentEatenCards.has(playerName)) {
        this.gameState.opponentEatenCards.set(playerName, new Set());
      }
      this.gameState.opponentEatenCards.get(playerName).add(cardNumber);

      // Phân tích sảnh đối thủ và dự đoán các lá nguy hiểm
      const analysis = this.analyzeOpponentEatenCards(playerName, cardNumber);

      // Cập nhật danh sách lá bài nguy hiểm
      this.updateDangerousCards(playerName, analysis);

      this.gameState.lastAction = {
        type: 'OPPONENT_EAT',
        player: playerName,
        card: cardNumber,
        timestamp: Date.now(),
        analysis: analysis
      };

      // Thông báo cho bot về các lá bài nguy hiểm
      this.notifyBot('OPPONENT_EAT_CARD', {
        player: playerName,
        eatenCard: cardNumber,
        analysis: analysis,
        dangerousCards: Array.from(this.gameState.dangerousCards),
        recommendation: 'Tránh đánh các lá có thể giúp đối thủ tạo phỏm'
      });
    }

    /**
     * Phân tích các lá bài đối thủ đã ăn để dự đoán sảnh của họ
     */
    analyzeOpponentEatenCards(playerName, newCard) {
      const eatenCards = Array.from(this.gameState.opponentEatenCards.get(playerName) || []);
      const newCardInfo = this.cardMapping.get(newCard);

      const analysis = {
        playerName: playerName,
        eatenCards: eatenCards,
        newCard: newCard,
        predictedSequences: [],
        predictedSets: [],
        dangerousCardsForThisPlayer: new Set(),
        confidenceLevel: 0
      };

      // Phân tích sequence tiềm năng
      this.analyzeSequencePotential(eatenCards, newCardInfo, analysis);

      // Phân tích set tiềm năng  
      this.analyzeSetPotential(eatenCards, newCardInfo, analysis);

      // Tính độ tin cậy dựa trên số lượng dữ liệu
      analysis.confidenceLevel = Math.min(10, eatenCards.length * 2);

      return analysis;
    }

    /**
     * Phân tích khả năng tạo sequence (dãy) từ các lá đã ăn
     */
    analyzeSequencePotential(eatenCards, newCardInfo, analysis) {
      // Nhóm các lá cùng chất
      const suitGroups = {};
      eatenCards.forEach(cardId => {
        const card = this.cardMapping.get(cardId);
        if (!suitGroups[card.suit]) suitGroups[card.suit] = [];
        suitGroups[card.suit].push(card);
      });

      // Thêm lá mới vào nhóm
      if (!suitGroups[newCardInfo.suit]) suitGroups[newCardInfo.suit] = [];
      suitGroups[newCardInfo.suit].push(newCardInfo);

      // Phân tích từng nhóm chất
      Object.entries(suitGroups).forEach(([suit, cards]) => {
        if (cards.length >= 2) {
          // Sắp xếp theo giá trị
          cards.sort((a, b) => a.value - b.value);

          // Tìm các dãy tiềm năng
          const sequences = this.findPotentialSequences(cards);
          sequences.forEach(seq => {
            analysis.predictedSequences.push({
              suit: parseInt(suit),
              cards: seq.cards,
              missingCards: seq.missingCards,
              probability: seq.probability
            });

            // Thêm các lá thiếu vào danh sách nguy hiểm
            seq.missingCards.forEach(cardId => {
              analysis.dangerousCardsForThisPlayer.add(cardId);
            });
          });
        }
      });
    }

    /**
     * Phân tích khả năng tạo set (bộ ba cùng giá trị)
     */
    analyzeSetPotential(eatenCards, newCardInfo, analysis) {
      // Nhóm theo giá trị
      const valueGroups = {};
      eatenCards.forEach(cardId => {
        const card = this.cardMapping.get(cardId);
        if (!valueGroups[card.value]) valueGroups[card.value] = [];
        valueGroups[card.value].push(card);
      });

      // Thêm lá mới
      if (!valueGroups[newCardInfo.value]) valueGroups[newCardInfo.value] = [];
      valueGroups[newCardInfo.value].push(newCardInfo);

      // Phân tích set tiềm năng
      Object.entries(valueGroups).forEach(([value, cards]) => {
        if (cards.length >= 2) {
          const usedSuits = new Set(cards.map(c => c.suit));
          const missingSuits = [];

          // Tìm các chất còn thiếu
          for (let suit = 0; suit < 4; suit++) {
            if (!usedSuits.has(suit)) {
              missingSuits.push(suit);
            }
          }

          if (missingSuits.length > 0) {
            analysis.predictedSets.push({
              value: parseInt(value),
              existingCards: cards.map(c => c.id),
              missingCards: missingSuits.map(suit => parseInt(value) * 4 + suit),
              probability: Math.max(5, 10 - missingSuits.length * 2)
            });

            // Thêm các lá thiếu vào danh sách nguy hiểm
            missingSuits.forEach(suit => {
              const cardId = parseInt(value) * 4 + suit;
              analysis.dangerousCardsForThisPlayer.add(cardId);
            });
          }
        }
      });
    }

    /**
     * Tìm các dãy tiềm năng từ các lá cùng chất
     */
    findPotentialSequences(sortedCards) {
      const sequences = [];

      for (let i = 0; i < sortedCards.length - 1; i++) {
        const current = sortedCards[i];
        const next = sortedCards[i + 1];

        // Nếu có 2 lá liên tiếp hoặc cách nhau 1-2 bậc
        const gap = next.value - current.value;
        if (gap >= 1 && gap <= 3) {
          const missingCards = [];
          const sequenceCards = [current, next];

          // Tìm các lá thiếu để tạo thành dãy 3
          if (gap === 1) {
            // Liền nhau - cần lá trước hoặc sau
            if (current.value > 0) {
              missingCards.push((current.value - 1) * 4 + current.suit);
            }
            if (next.value < 12) {
              missingCards.push((next.value + 1) * 4 + next.suit);
            }
          } else if (gap === 2) {
            // Cách 1 lá - cần lá giữa
            missingCards.push((current.value + 1) * 4 + current.suit);
          } else if (gap === 3) {
            // Cách 2 lá - cần 2 lá giữa
            missingCards.push((current.value + 1) * 4 + current.suit);
            missingCards.push((current.value + 2) * 4 + current.suit);
          }

          if (missingCards.length > 0) {
            sequences.push({
              cards: sequenceCards,
              missingCards: missingCards,
              probability: Math.max(3, 10 - gap * 2)
            });
          }
        }
      }

      return sequences;
    }

    /**
     * Cập nhật danh sách các lá bài nguy hiểm (không nên đánh)
     */
    updateDangerousCards(playerName, analysis) {
      // Thêm các lá nguy hiểm từ phân tích này
      analysis.dangerousCardsForThisPlayer.forEach(cardId => {
        this.gameState.dangerousCards.add(cardId);
      });

      // Lưu trữ sequence predictions cho player này
      if (!this.gameState.opponentSequences.has(playerName)) {
        this.gameState.opponentSequences.set(playerName, []);
      }

      const playerSequences = this.gameState.opponentSequences.get(playerName);
      playerSequences.push(...analysis.predictedSequences);
      playerSequences.push(...analysis.predictedSets);

      // Giới hạn lịch sử (chỉ giữ 10 predictions gần nhất)
      if (playerSequences.length > 10) {
        playerSequences.splice(0, playerSequences.length - 10);
      }

      debug(`[Phom Analyzer] Updated dangerous cards: ${this.gameState.dangerousCards.size} total`);
    }

    onOpponentCardsPlayed(cards) {
      debug("[Phom Analyzer] Opponent played cards:", cards);

      // Phân tích pattern của đối thủ
      const opponentPattern = this.analyzeOpponentPattern(cards);

      this.gameState.lastAction = {
        type: 'OPPONENT_PLAY',
        cards: cards,
        timestamp: Date.now(),
        pattern: opponentPattern
      };

      this.notifyBot('OPPONENT_CARDS_PLAYED', {
        cards: cards,
        pattern: opponentPattern,
        threatLevel: this.calculateThreatLevel(cards)
      });
    }
    onGameCheckStart() {
      this.notifyBot('GAME_CHECK_START', {});
    }

    onMyTurn() {
      debug("[Phom Analyzer] My turn to play");

      this.gameState.currentPlayer = 'me';

      // Phân tích tình huống hiện tại
      const situation = this.analyzCurrentSituation();

      this.notifyBot('MY_TURN', {
        gameState: this.gameState,
        situation: situation,
        recommendedMoves: this.generateRecommendedMoves()
      });
    }

    onGameEnd() {
      debug("[Phom Analyzer] Game ended:");

      this.gameState.gamePhase = 'finished';

      this.notifyBot('GAME_END', {
        finalState: this.gameState
      });
    }

    onUserLeave() {
      debug("[Phom Analyzer] User left game");

      // Reset isCheckFirst for next game
      this.isCheckFirst = false;

      // Reset game state
      this.gameState = {
        myCards: new Set(),
        currentPlayer: null,
        gamePhase: 'waiting',
        lastAction: null,
        opponentEatenCards: new Map(), // Reset thông tin đối thủ
        opponentSequences: new Map(),
        dangerousCards: new Set()
      };

      this.notifyBot('USER_LEAVE', {
        reason: 'Game left'
      });
    }

    // Phân tích bài khởi tạo
    analyzeInitialHand(cards) {
      const analysis = {
        sequences: [],
        sets: [],
        isolatedCards: [],
        potentialCombinations: [],
        strength: 0
      };

      // Nhóm bài theo chất và giá trị
      const suitGroups = this.groupCardsBySuit(cards);
      const valueGroups = this.groupCardsByValue(cards);

      // Tìm dãy (sequence)
      Object.entries(suitGroups).forEach(([suit, suitCards]) => {
        const sequences = this.findSequencesInSuit(suitCards);
        analysis.sequences.push(...sequences);
      });

      // Tìm set (cùng giá trị)
      Object.entries(valueGroups).forEach(([value, valueCards]) => {
        if (valueCards.length >= 3) {
          analysis.sets.push({
            type: 'set',
            value: parseInt(value),
            cards: valueCards,
            strength: valueCards.length * 10 + parseInt(value)
          });
        }
      });

      // Tính điểm strength tổng thể
      analysis.strength = this.calculateHandStrength(analysis);

      return analysis;
    }

    groupCardsBySuit(cards) {
      const groups = {};
      cards.forEach(cardId => {
        const card = this.cardMapping.get(cardId);
        if (!groups[card.suit]) groups[card.suit] = [];
        groups[card.suit].push(cardId);
      });

      // Sắp xếp theo giá trị
      Object.keys(groups).forEach(suit => {
        groups[suit].sort((a, b) => {
          return this.cardMapping.get(a).value - this.cardMapping.get(b).value;
        });
      });

      return groups;
    }

    groupCardsByValue(cards) {
      const groups = {};
      cards.forEach(cardId => {
        const card = this.cardMapping.get(cardId);
        if (!groups[card.value]) groups[card.value] = [];
        groups[card.value].push(cardId);
      });

      return groups;
    }

    findSequencesInSuit(suitCards) {
      const sequences = [];

      for (let i = 0; i < suitCards.length - 2; i++) {
        let sequence = [suitCards[i]];

        for (let j = i + 1; j < suitCards.length; j++) {
          const currentCard = this.cardMapping.get(suitCards[j]);
          const lastCard = this.cardMapping.get(sequence[sequence.length - 1]);

          if (currentCard.value === lastCard.value + 1) {
            sequence.push(suitCards[j]);
          } else {
            break;
          }
        }

        if (sequence.length >= 3) {
          sequences.push({
            type: 'sequence',
            suit: this.cardMapping.get(suitCards[i]).suit,
            cards: sequence,
            length: sequence.length,
            strength: sequence.length * 15 + this.cardMapping.get(sequence[0]).value
          });
        }
      }

      return sequences;
    }

    calculateHandStrength(analysis) {
      let strength = 0;

      // Điểm từ sequences
      analysis.sequences.forEach(seq => {
        strength += seq.strength;
      });

      // Điểm từ sets
      analysis.sets.forEach(set => {
        strength += set.strength;
      });

      // Phạt điểm cho bài lẻ
      const usedCards = new Set();
      analysis.sequences.forEach(seq => seq.cards.forEach(card => usedCards.add(card)));
      analysis.sets.forEach(set => set.cards.forEach(card => usedCards.add(card)));

      const isolatedCount = Array.from(this.gameState.myCards).filter(card =>
        !usedCards.has(card)
      ).length;

      strength -= isolatedCount * 5;

      return Math.max(0, strength);
    }

    analyzeOpponentPattern(cards) {
      const pattern = {
        combinationType: 'unknown',
        aggressiveness: 0,
        cardValues: [],
        suits: []
      };

      cards.forEach(cardId => {
        const card = this.cardMapping.get(cardId);
        pattern.cardValues.push(card.value);
        pattern.suits.push(card.suit);
      });

      // Phân tích loại combination
      if (cards.length === 1) {
        pattern.combinationType = 'discard';
        pattern.aggressiveness = 3; // Bình thường
      } else if (cards.length >= 3) {
        if (this.isSequence(cards)) {
          pattern.combinationType = 'sequence';
          pattern.aggressiveness = 7; // Tích cực
        } else if (this.isSet(cards)) {
          pattern.combinationType = 'set';
          pattern.aggressiveness = 8; // Rất tích cực
        } else {
          pattern.combinationType = 'mixed';
          pattern.aggressiveness = 9; // Cực kỳ tích cực
        }
      }

      return pattern;
    }

    isSequence(cards) {
      if (cards.length < 3) return false;

      const sortedCards = cards.map(id => this.cardMapping.get(id))
        .sort((a, b) => a.value - b.value);

      const suit = sortedCards[0].suit;
      for (let i = 0; i < sortedCards.length; i++) {
        if (sortedCards[i].suit !== suit ||
          (i > 0 && sortedCards[i].value !== sortedCards[i - 1].value + 1)) {
          return false;
        }
      }

      return true;
    }

    isSet(cards) {
      if (cards.length < 3) return false;

      const value = this.cardMapping.get(cards[0]).value;
      return cards.every(cardId => this.cardMapping.get(cardId).value === value);
    }

    calculateThreatLevel(cards) {
      // Tính mức độ đe dọa từ nước đi của đối thủ
      let threatLevel = 0;

      if (cards.length === 1) {
        threatLevel = 2; // Thấp - chỉ đánh bài
      } else if (cards.length >= 3) {
        if (this.isSequence(cards)) {
          threatLevel = 7; // Cao - có dãy
        } else if (this.isSet(cards)) {
          threatLevel = 8; // Rất cao - có set
        } else {
          threatLevel = 9; // Cực cao - có phỏm
        }

        // Tăng threat nếu là bài cao
        const highCards = cards.filter(cardId => {
          const card = this.cardMapping.get(cardId);
          return card.value >= 10; // J, Q, K
        });

        threatLevel += highCards.length;
      }

      return Math.min(10, threatLevel);
    }

    analyzCurrentSituation() {
      const situation = {
        phase: this.determineGamePhase(),
        myAdvantage: this.calculateMyAdvantage(),
        opponentThreat: this.assessOpponentThreat(),
        bestStrategy: 'balanced'
      };

      // Xác định chiến lược tốt nhất
      if (situation.myAdvantage > 7 && situation.opponentThreat < 5) {
        situation.bestStrategy = 'aggressive';
      } else if (situation.myAdvantage < 4 || situation.opponentThreat > 7) {
        situation.bestStrategy = 'defensive';
      }

      return situation;
    }

    determineGamePhase() {
      const myCardsCount = this.gameState.myCards.size;

      if (myCardsCount > 10) return 'early';
      if (myCardsCount > 6) return 'mid';
      return 'late';
    }

    calculateMyAdvantage() {
      // Phân tích lợi thế của mình
      const handAnalysis = this.analyzeInitialHand(Array.from(this.gameState.myCards));
      return Math.min(10, handAnalysis.strength / 10);
    }

    assessOpponentThreat() {
      if (!this.gameState.lastAction || this.gameState.lastAction.type !== 'OPPONENT_PLAY') {
        return 5; // Trung bình
      }

      return this.gameState.lastAction.pattern?.aggressiveness || 5;
    }

    generateRecommendedMoves() {
      const moves = [];
      const myCards = Array.from(this.gameState.myCards);

      // LUÔN LUÔN tạo danh sách đánh bài đơn (vì bot tập trung vào đánh bài)
      // Bot sẽ tự quyết định Ù/Gửi bài/Hạ phỏm
      myCards.forEach(card => {
        const score = this.evaluateDiscardScore(card);
        moves.push({
          type: 'discard',
          cards: [card],
          score: score,
          reasoning: this.generateDiscardReasoning(card)
        });
      });

      // Sắp xếp theo điểm số (cao nhất = nên đánh nhất)
      moves.sort((a, b) => b.score - a.score);

      return moves; // Trả về tất cả moves, bot sẽ filter
    }

    /**
     * Đánh giá điểm số cho việc đánh bài - ALIGN với bot logic
     * Ưu tiên: Tránh lá đối thủ cần > Lá rác > Lá cô lập > Lá biên > Lá giữa
     */
    evaluateDiscardScore(card) {
      const cardInfo = this.cardMapping.get(card);
      let score = 50; // Base score

      // PRIORITY 1: Kiểm tra lá nguy hiểm (đối thủ có thể cần)
      const dangerousPenalty = this.checkDangerousCard(card);
      score -= dangerousPenalty;

      // Factor 1: Kiểm tra lá rác (không tạo được phỏm)
      const trashScore = this.checkTrashCard(card, cardInfo);
      score += trashScore;

      // Factor 2: Kiểm tra lá có phải phần của phỏm không
      const isPartOfPhom = this.isPartOfExistingPhom(card, cardInfo);
      if (isPartOfPhom) {
        // PENALTY CỰC CAO - không nên đánh
        score -= 200;
      }

      // Factor 3: Kiểm tra có phá combo tiềm năng không
      const comboPenalty = this.checkComboBreaking(card, cardInfo);
      score -= comboPenalty;

      // Factor 4: Lá biên an toàn hơn (A, 2, J, Q, K)
      if (cardInfo.value === 0 || cardInfo.value === 12) {
        score += 30; // A, K
      } else if (cardInfo.value === 1 || cardInfo.value === 11) {
        score += 20; // 2, Q
      } else if (cardInfo.value === 2 || cardInfo.value === 10) {
        score += 10; // 3, J
      }

      // Factor 5: Ưu tiên đánh bài thấp điểm (A-5 tốt hơn 10-K)
      if (cardInfo.value <= 4) {
        score += 15; // A, 2, 3, 4, 5
      } else if (cardInfo.value >= 9) {
        score -= 10; // 10, J, Q, K giữ lại
      }

      return Math.max(0, Math.round(score));
    }

    /**
     * PRIORITY 1: Kiểm tra lá nguy hiểm - lá mà đối thủ có thể cần
     * Dựa trên phân tích các lá đối thủ đã ăn
     */
    checkDangerousCard(card) {
      // Kiểm tra lá này có trong danh sách nguy hiểm không
      if (this.gameState.dangerousCards.has(card)) {
        return 150; // PENALTY CỰC CAO - đối thủ có thể cần lá này
      }

      // Kiểm tra các lá liên quan có nguy hiểm không
      const cardInfo = this.cardMapping.get(card);
      let relatedDangerLevel = 0;

      // Kiểm tra các lá sequence liên quan
      for (let offset = -2; offset <= 2; offset++) {
        if (offset === 0) continue;

        const relatedValue = cardInfo.value + offset;
        if (relatedValue >= 0 && relatedValue <= 12) {
          const relatedCard = relatedValue * 4 + cardInfo.suit;
          if (this.gameState.dangerousCards.has(relatedCard)) {
            relatedDangerLevel += Math.max(0, 30 - Math.abs(offset) * 10);
          }
        }
      }

      // Kiểm tra các lá set liên quan (cùng giá trị)
      for (let suit = 0; suit < 4; suit++) {
        if (suit !== cardInfo.suit) {
          const relatedCard = cardInfo.value * 4 + suit;
          if (this.gameState.dangerousCards.has(relatedCard)) {
            relatedDangerLevel += 20;
          }
        }
      }

      return relatedDangerLevel;
    }

    /**
     * Kiểm tra lá rác (không có lá liên quan)
     */
    checkTrashCard(card, cardInfo) {
      const myCards = Array.from(this.gameState.myCards).filter(c => c !== card);
      let relatedCount = 0;

      myCards.forEach(otherCard => {
        const other = this.cardMapping.get(otherCard);

        // Cùng chất và gần nhau (có thể tạo sequence)
        if (other.suit === cardInfo.suit &&
          Math.abs(other.value - cardInfo.value) <= 2) {
          relatedCount++;
        }

        // Cùng giá trị (có thể tạo set)
        if (other.value === cardInfo.value) {
          relatedCount++;
        }
      });

      // Càng ít lá liên quan = càng là lá rác = điểm càng cao
      if (relatedCount === 0) return 100; // Lá rác hoàn toàn
      if (relatedCount === 1) return 50;  // Ít liên quan
      if (relatedCount === 2) return 20;  // Có thể tạo combo
      return -30; // Nhiều lá liên quan - không nên đánh
    }

    /**
     * Kiểm tra lá có phải phần của phỏm đã có không
     */
    isPartOfExistingPhom(card, cardInfo) {
      const myCards = Array.from(this.gameState.myCards);

      // Kiểm tra sequence (3+ lá liên tiếp cùng chất)
      const sameSuitCards = myCards
        .filter(c => {
          const info = this.cardMapping.get(c);
          return info.suit === cardInfo.suit;
        })
        .sort((a, b) => {
          return this.cardMapping.get(a).value - this.cardMapping.get(b).value;
        });

      // Tìm dãy chứa lá này
      for (let i = 0; i < sameSuitCards.length; i++) {
        if (sameSuitCards[i] === card) {
          const cardValue = cardInfo.value;

          // Kiểm tra sequence trước, sau, giữa
          const hasBefore2 = i >= 2 &&
            this.cardMapping.get(sameSuitCards[i - 1]).value === cardValue - 1 &&
            this.cardMapping.get(sameSuitCards[i - 2]).value === cardValue - 2;

          const hasAfter2 = i <= sameSuitCards.length - 3 &&
            this.cardMapping.get(sameSuitCards[i + 1]).value === cardValue + 1 &&
            this.cardMapping.get(sameSuitCards[i + 2]).value === cardValue + 2;

          const hasMiddle = i >= 1 && i <= sameSuitCards.length - 2 &&
            this.cardMapping.get(sameSuitCards[i - 1]).value === cardValue - 1 &&
            this.cardMapping.get(sameSuitCards[i + 1]).value === cardValue + 1;

          if (hasBefore2 || hasAfter2 || hasMiddle) {
            return true;
          }
        }
      }

      // Kiểm tra set (3+ lá cùng giá trị)
      const sameValueCards = myCards.filter(c => {
        const info = this.cardMapping.get(c);
        return info.value === cardInfo.value;
      });

      return sameValueCards.length >= 3;
    }

    /**
     * Kiểm tra có phá combo tiềm năng không
     */
    checkComboBreaking(card, cardInfo) {
      const myCards = Array.from(this.gameState.myCards).filter(c => c !== card);
      let penalty = 0;

      // Kiểm tra sequence tiềm năng (2 lá liên tiếp)
      const nearSequence = myCards.filter(c => {
        const info = this.cardMapping.get(c);
        return info.suit === cardInfo.suit &&
          Math.abs(info.value - cardInfo.value) === 1;
      });

      if (nearSequence.length > 0) {
        penalty += 150; // Có lá liền kề
      }

      // Kiểm tra set tiềm năng (2 lá cùng giá trị)
      const sameValue = myCards.filter(c => {
        const info = this.cardMapping.get(c);
        return info.value === cardInfo.value;
      });

      if (sameValue.length === 2) {
        penalty += 130; // Đã có 2 lá, gần thành set
      } else if (sameValue.length === 1) {
        penalty += 60; // Có 1 lá cùng giá trị
      }

      return penalty;
    }

    /**
     * Tạo reasoning cho recommended move
     */
    generateDiscardReasoning(card) {
      const cardInfo = this.cardMapping.get(card);
      const cardName = `${cardInfo.display}`;

      const isDangerous = this.checkDangerousCard(card) >= 100;
      const isTrash = this.checkTrashCard(card, cardInfo) >= 50;
      const isPhom = this.isPartOfExistingPhom(card, cardInfo);

      if (isPhom) {
        return `⚠️ ${cardName} - PHẦN CỦA PHỎM - TRÁNH ĐÁNH`;
      }

      if (isDangerous) {
        return `🚫 ${cardName} - ĐỐI THỦ CẦN - TRÁNH ĐÁNH`;
      }

      if (isTrash) {
        return `⭐ ${cardName} - Lá rác - ưu tiên đánh`;
      }

      return `${cardName} - Phân tích từ analyzer`;
    }

    notifyBot(eventType, data) {
      // Gửi thông tin đã phân tích cho bot
      window.postMessage({
        type: 'PHOM_ANALYZER_EVENT',
        eventType: eventType,
        data: data,
        timestamp: Date.now()
      }, '*');
    }
  }

  // Khởi tạo analyzer
  window.phomAnalyzer = new PhomGameAnalyzer();

  debug("[Phom Analyzer] Game analyzer loaded successfully");
})();
