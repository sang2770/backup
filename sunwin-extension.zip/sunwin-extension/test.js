function createDebugConsole() {
    try {
        const iframe = document.createElement("iframe");
        iframe.style.display = "none";
        (document.body || document.documentElement).appendChild(iframe);
        return iframe.contentWindow.console.log.bind(
            iframe.contentWindow.console
        );
    } catch (e) {
        console.error("[Phom Monitor] Lỗi tạo debug console:", e);
        return console.log.bind(console);
    }
}

const debug = createDebugConsole();


function logNodeTree(node, indent = 0) {
    const prefix = ' '.repeat(indent * 2); // mỗi cấp cách ra 2 dấu cách
    debug(`${prefix}- ${node.name}`);

    node.children.forEach(child => {
        logNodeTree(child, indent + 1);
    });
}

logNodeTree(cc.director.getScene());


// Theo dõi bài đã đánh trên bàn
let myPlayedCards = new Set();
let opponentPlayedCards = new Set();
let boardCards = new Set(); // Tất cả bài trên bàn
let cardHistory = []; // Lịch sử đánh bài theo thời gian

function parseCardSprite(spriteName) {
    if (!spriteName || spriteName === "Card_bc") {
        return { value: null, suit: null, hidden: true };
    }

    // Pattern: Card_[number][suit]
    const match = spriteName.match(/^Card_(\d+)([TCRB])$/);
    if (!match) {
        return { value: null, suit: null, error: `Invalid sprite: ${spriteName}` };
    }

    const value = parseInt(match[1]);
    const suitChar = match[2];

    // Mapping suit characters - Cập nhật theo chuẩn Việt Nam
    const suitMap = {
        'B': { name: 'Bích', symbol: '♠', emoji: '♠️', color: 'black' },  // Spades
        'T': { name: 'Chuồn (Tép)', symbol: '♣', emoji: '♣️', color: 'black' }, // Clubs
        'R': { name: 'Rô', symbol: '♦', emoji: '♦️', color: 'red' },      // Diamonds  
        'C': { name: 'Cơ', symbol: '♥', emoji: '❤️', color: 'red' },      // Hearts
    };

    // Convert number to display value
    let displayValue;
    if (value === 1) displayValue = 'A';
    else if (value === 11) displayValue = 'J';
    else if (value === 12) displayValue = 'Q';
    else if (value === 13) displayValue = 'K';
    else displayValue = value.toString();

    const suit = suitMap[suitChar] || { name: 'Unknown', symbol: '?', emoji: '❓', color: 'unknown' };

    return {
        value: value,
        displayValue: displayValue,
        suit: suit,
        suitChar: suitChar,
        cardName: `${displayValue}${suit.symbol}`,
        cardCode: `${value}${suitChar}`,
        hidden: false
    };
}

// Hàm tìm bài đã đánh trên bàn - cập nhật với tìm kiếm thông minh
function findBoardCards() {
    const playedCards = [];

    // Sử dụng hàm tìm kiếm nâng cao
    const foundNodes = findPlayedCardNodes();

    // Lọc các node có khả năng chứa bài trên bàn chung
    const boardNodeNames = Object.keys(foundNodes).filter(name =>
        name.includes('table') || name.includes('board') || name.includes('center') ||
        name.includes('middle') || name.includes('play_area')
    );

    boardNodeNames.forEach(nodeName => {
        const node = foundNodes[nodeName];
        if (node) {
            debug(`🎲 Kiểm tra node bàn chơi: ${nodeName}`);
            const cards = extractCardsFromNode(node, 'board');
            playedCards.push(...cards);
        }
    });

    return playedCards;
}

// Hàm tìm bài đã đánh của người chơi
function findMyPlayedCards() {
    const scene = cc.director.getScene();
    const myCards = [];

    // Tìm các node có thể chứa bài đã đánh của mình
    const possibleNodes = [
        'my_played', 'player_played', 'my_discard', 'player_discard',
        'my_cards_played', 'own_played'
    ];

    possibleNodes.forEach(nodeName => {
        const node = findNodeByName(nodeName);
        if (node) {
            debug(`🔍 Tìm thấy node bài của tôi: ${nodeName}`);
            const cards = extractCardsFromNode(node, 'me');
            myCards.push(...cards);
        }
    });

    return myCards;
}

// Hàm tìm bài đã đánh của đối thủ
function findOpponentPlayedCards() {
    const scene = cc.director.getScene();
    const opponentCards = [];

    // Tìm các node có thể chứa bài đã đánh của đối thủ
    const possibleNodes = [
        'opponent_played', 'enemy_played', 'opponent_discard', 'enemy_discard',
        'other_played', 'rival_played'
    ];

    possibleNodes.forEach(nodeName => {
        const node = findNodeByName(nodeName);
        if (node) {
            debug(`🔍 Tìm thấy node bài đối thủ: ${nodeName}`);
            const cards = extractCardsFromNode(node, 'opponent');
            opponentCards.push(...cards);
        }
    });

    return opponentCards;
}

// Hàm trích xuất thông tin bài từ node
function extractCardsFromNode(node, owner) {
    const cards = [];

    if (!node || !node.children) return cards;

    node.children.forEach((cardChild, index) => {
        if (cardChild.name === "card" && cardChild.active) {
            const sprite = cardChild.getComponent(cc.Sprite);
            const spriteName = sprite?.spriteFrame?.name || "unknown";
            const cardInfo = parseCardSprite(spriteName);

            if (!cardInfo.hidden && cardInfo.value) {
                const cardData = {
                    index: index + 1,
                    sprite: spriteName,
                    owner: owner,
                    timestamp: Date.now(),
                    position: {
                        x: Math.round(cardChild.position.x * 10) / 10,
                        y: Math.round(cardChild.position.y * 10) / 10
                    },
                    ...cardInfo
                };

                cards.push(cardData);

                // Cập nhật tracking sets
                if (owner === 'me') {
                    myPlayedCards.add(cardInfo.cardCode);
                } else if (owner === 'opponent') {
                    opponentPlayedCards.add(cardInfo.cardCode);
                }
                boardCards.add(cardInfo.cardCode);

                // Thêm vào lịch sử nếu chưa có
                const existsInHistory = cardHistory.some(h =>
                    h.cardCode === cardInfo.cardCode && h.owner === owner
                );
                if (!existsInHistory) {
                    cardHistory.push({
                        ...cardData,
                        playTime: new Date().toLocaleTimeString()
                    });
                }
            }
        }
    });

    return cards;
}

// Phân tích tổng quan bài đã đánh
function analyzeBoardCards() {
    debug(`\n🎯 === PHÂN TÍCH BÀI ĐÃ ĐÁNH TRÊN BÀN ===`);

    const boardCards = findBoardCards();
    const myCards = findMyPlayedCards();
    const opponentCards = findOpponentPlayedCards();

    const allPlayedCards = [...boardCards, ...myCards, ...opponentCards];

    debug(`📊 Tổng số bài đã đánh: ${allPlayedCards.length}`);
    debug(`🟢 Bài tôi đã đánh: ${myPlayedCards.size}`);
    debug(`🔴 Bài đối thủ đã đánh: ${opponentPlayedCards.size}`);
    debug(`🎲 Bài trên bàn chung: ${boardCards.length}`);

    if (myPlayedCards.size > 0) {
        debug(`\n🟢 DANH SÁCH BÀI TÔI ĐÃ ĐÁNH:`);
        Array.from(myPlayedCards).forEach(cardCode => {
            const cardInfo = parseCardFromCode(cardCode);
            debug(`  ${cardInfo.cardName} (${cardInfo.suit.name})`);
        });
    }

    if (opponentPlayedCards.size > 0) {
        debug(`\n🔴 DANH SÁCH BÀI ĐỐI THỦ ĐÃ ĐÁNH:`);
        Array.from(opponentPlayedCards).forEach(cardCode => {
            const cardInfo = parseCardFromCode(cardCode);
            debug(`  ${cardInfo.cardName} (${cardInfo.suit.name})`);
        });
    }

    if (allPlayedCards.length > 0) {
        analyzeBoardPatterns(allPlayedCards);
    }

    return {
        board: boardCards,
        my: Array.from(myPlayedCards),
        opponent: Array.from(opponentPlayedCards),
        all: allPlayedCards,
        history: cardHistory,
        summary: {
            total: allPlayedCards.length,
            myCount: myPlayedCards.size,
            opponentCount: opponentPlayedCards.size,
            boardCount: boardCards.length
        }
    };
}

// Chuyển đổi cardCode thành thông tin bài
function parseCardFromCode(cardCode) {
    const match = cardCode.match(/^(\d+)([TCRB])$/);
    if (!match) return { cardName: cardCode, suit: { name: 'Unknown' } };

    const value = parseInt(match[1]);
    const suitChar = match[2];

    const suitMap = {
        'T': { name: 'Chuồn (Tép)', symbol: '♣', emoji: '♣️' },
        'B': { name: 'Bích', symbol: '♠', emoji: '♠️' },
        'R': { name: 'Rô', symbol: '♦', emoji: '♦️' },
        'C': { name: 'Cơ', symbol: '♥', emoji: '❤️' },
    };

    let displayValue;
    if (value === 1) displayValue = 'A';
    else if (value === 11) displayValue = 'J';
    else if (value === 12) displayValue = 'Q';
    else if (value === 13) displayValue = 'K';
    else displayValue = value.toString();

    const suit = suitMap[suitChar] || { name: 'Unknown', symbol: '?', emoji: '❓' };

    return {
        value: value,
        displayValue: displayValue,
        suit: suit,
        suitChar: suitChar,
        cardName: `${displayValue}${suit.symbol}`,
        cardCode: cardCode
    };
}

// Phân tích pattern bài đã đánh
function analyzeBoardPatterns(playedCards) {
    debug(`\n🔍 PHÂN TÍCH PATTERN BÀI ĐÃ ĐÁNH:`);

    if (playedCards.length === 0) {
        debug(`  Chưa có bài nào được đánh`);
        return;
    }

    // Nhóm theo chất
    const suits = {};
    playedCards.forEach(card => {
        if (card.suitChar) {
            if (!suits[card.suitChar]) suits[card.suitChar] = [];
            suits[card.suitChar].push(card);
        }
    });

    debug(`\n🃏 Phân bố theo chất đã đánh:`);
    Object.entries(suits).forEach(([suitChar, suitCards]) => {
        if (suitCards.length > 0) {
            const suit = suitCards[0].suit;
            const values = suitCards.map(c => c.displayValue).sort();
            const owners = suitCards.map(c => c.owner === 'me' ? '🟢' : '🔴').join('');
            debug(`  ${suit.emoji} ${suit.name}: ${values.join(', ')} ${owners}`);
        }
    });

    // Phân tích bài cao đã xuất hiện
    const highCards = playedCards.filter(c => c.value >= 10 || c.value === 1);
    if (highCards.length > 0) {
        debug(`\n⭐ BÀI CAO ĐÃ XUẤT HIỆN (A, 10, J, Q, K):`);
        const myHighCards = highCards.filter(c => c.owner === 'me');
        const opponentHighCards = highCards.filter(c => c.owner === 'opponent');

        if (myHighCards.length > 0) {
            debug(`  🟢 Tôi đã đánh: ${myHighCards.map(c => c.cardName).join(', ')}`);
        }
        if (opponentHighCards.length > 0) {
            debug(`  🔴 Đối thủ đã đánh: ${opponentHighCards.map(c => c.cardName).join(', ')}`);
        }
    }

    // Thống kê theo người chơi
    const myCount = playedCards.filter(c => c.owner === 'me').length;
    const opponentCount = playedCards.filter(c => c.owner === 'opponent').length;

    debug(`\n📈 THỐNG KÊ ĐÁNH BÀI:`);
    debug(`  🟢 Tôi đã đánh: ${myCount} lượt`);
    debug(`  🔴 Đối thủ đã đánh: ${opponentCount} lượt`);

    if (myCount > opponentCount) {
        debug(`  💡 Bạn đang đánh nhiều hơn đối thủ. Hãy thận trọng!`);
    } else if (opponentCount > myCount) {
        debug(`  💡 Đối thủ đang đánh tích cực. Quan sát kỹ!`);
    } else {
        debug(`  💡 Trạng thái cân bằng.`);
    }
}

function getPlayerCards() {
    const cardNode = findNodeByName("card_node");
    if (!cardNode) {
        debug("Không tìm thấy card_node");
        return [];
    }

    const cards = [];
    const visibleCards = [];
    const hiddenCards = [];

    cardNode.children.forEach((cardChild, index) => {
        if (cardChild.name === "card" && cardChild.active) {
            const sprite = cardChild.getComponent(cc.Sprite);
            const spriteName = sprite?.spriteFrame?.name || "unknown";

            const cardInfo = parseCardSprite(spriteName);

            // Kiểm tra component thứ 3 để xác định bài thật
            const hasCardObject = cardChild._components &&
                cardChild._components[2] &&
                cardChild._components[2].card !== undefined;

            const cardData = {
                index: index + 1,
                sprite: spriteName,
                position: {
                    x: Math.round(cardChild.position.x * 10) / 10,
                    y: Math.round(cardChild.position.y * 10) / 10
                },
                internalId: cardChild._components?.[1]?._internalId || 'unknown',
                hasCardObject: hasCardObject,
                ...cardInfo
            };

            cards.push(cardData);

            if (cardInfo.hidden) {
                hiddenCards.push(cardData);
            } else if (hasCardObject) {
                visibleCards.push(cardData);
            }
        }
    });

    // Log summary
    debug(`\n=== TỔNG KẾT QUÂN BÀI ===`);
    debug(`Tổng số quân bài: ${cards.length}`);
    debug(`Quân bài hiện: ${visibleCards.length}`);
    debug(`Quân bài ẩn: ${hiddenCards.length}`);

    if (visibleCards.length > 0) {
        debug(`\n📋 QUÂN BÀI TRONG TAY:`);
        visibleCards.forEach(card => {
            debug(`  ${card.index}. ${card.cardName} (${card.suit.name}) - ID: ${card.spriteName} - Pos: (${card.position.x}, ${card.position.y})`);
        });

        // Phân tích bộ bài
        analyzeHand(visibleCards);

        // Validation với bài thực tế
        validateWithKnownCards(visibleCards);
    }

    return {
        all: cards,
        visible: visibleCards,
        hidden: hiddenCards,
        summary: {
            total: cards.length,
            visible: visibleCards.length,
            hidden: hiddenCards.length
        }
    };
}

function analyzeHand(cards) {
    debug(`\n🎯 PHÂN TÍCH BỘ BÀI (${cards.length} quân):`);

    // Nhóm theo chất với emoji
    const suits = {};
    cards.forEach(card => {
        if (!suits[card.suitChar]) suits[card.suitChar] = [];
        suits[card.suitChar].push(card);
    });

    debug(`\n🃏 Phân bố theo chất:`);
    Object.entries(suits).forEach(([suitChar, suitCards]) => {
        const suit = suitCards[0].suit;
        const values = suitCards.map(c => c.displayValue).sort((a, b) => {
            const getValue = (val) => {
                if (val === 'A') return 1;
                if (val === 'J') return 11;
                if (val === 'Q') return 12;
                if (val === 'K') return 13;
                return parseInt(val);
            };
            return getValue(a) - getValue(b);
        });
        debug(`  ${suit.emoji} ${suit.name}: ${values.join(', ')} (${suitCards.length} quân)`);
    });

    // Nhóm theo giá trị
    const values = {};
    cards.forEach(card => {
        if (!values[card.value]) values[card.value] = [];
        values[card.value].push(card);
    });

    const pairs = Object.entries(values).filter(([_, cards]) => cards.length >= 2);
    if (pairs.length > 0) {
        debug(`\n🔥 CẶP/SÂM/TỨ QUÝ:`);
        pairs.forEach(([value, pairCards]) => {
            const displayValue = pairCards[0].displayValue;
            const suitEmojis = pairCards.map(c => c.suit.emoji).join('');
            const type = pairCards.length === 2 ? 'Cặp' :
                pairCards.length === 3 ? 'Sâm' : 'Tứ quý';
            debug(`  ${type} ${displayValue}: ${suitEmojis} (${pairCards.length} quân)`);
        });
    }

    // Kiểm tra sảnh
    checkStraight(cards);
}

function checkStraight(cards) {
    if (cards.length < 3) return;

    const values = cards.map(c => c.value).sort((a, b) => a - b);
    const uniqueValues = [...new Set(values)];

    debug(`\n🎲 Kiểm tra sảnh:`);

    // Tìm sảnh dài nhất
    let longestStraight = [];
    let currentStraight = [uniqueValues[0]];

    for (let i = 1; i < uniqueValues.length; i++) {
        if (uniqueValues[i] === uniqueValues[i - 1] + 1) {
            currentStraight.push(uniqueValues[i]);
        } else {
            if (currentStraight.length >= 3 && currentStraight.length > longestStraight.length) {
                longestStraight = [...currentStraight];
            }
            currentStraight = [uniqueValues[i]];
        }
    }

    if (currentStraight.length >= 3 && currentStraight.length > longestStraight.length) {
        longestStraight = [...currentStraight];
    }

    if (longestStraight.length >= 3) {
        const straightDisplay = longestStraight.map(v => {
            if (v === 1) return 'A';
            if (v === 11) return 'J';
            if (v === 12) return 'Q';
            if (v === 13) return 'K';
            return v.toString();
        }).join('-');
        debug(`  ⭐ Sảnh ${longestStraight.length} quân: ${straightDisplay}`);
    } else {
        debug(`  Không có sảnh (cần tối thiểu 3 quân liên tiếp)`);
    }
}

function validateWithKnownCards(detectedCards) {
    // Dựa vào thông tin trước: 8R, 9R, 9B, 11B, 11T, 13T, 2T, 2R, 6B
    // Chuyển đổi sang format mới: 8R, 9R, 9B, 11B, 11T, 13T, 2T, 2R, 6B
    const knownCards = ['8R', '9R', '9B', '11B', '11T', '13T', '2T', '2R', '6B'];

    debug(`\n🔍 SO SÁNH VỚI BÀI ĐÃ BIẾT:`);

    const detectedCodes = detectedCards.map(card => card.cardCode);
    const matched = detectedCodes.filter(code => knownCards.includes(code));
    const extra = detectedCodes.filter(code => !knownCards.includes(code));
    const missing = knownCards.filter(code => !detectedCodes.includes(code));

    debug(`📊 Thống kê:`);
    debug(`  Phát hiện: ${detectedCards.length} quân`);
    debug(`  Đã biết: ${knownCards.length} quân`);
    debug(`  Trùng khớp: ${matched.length} quân`);

    if (matched.length > 0) {
        debug(`✅ Khớp: ${matched.join(', ')}`);
    }

    if (extra.length > 0) {
        debug(`⚠️ Thừa: ${extra.join(', ')}`);
    }

    if (missing.length > 0) {
        debug(`❌ Thiếu: ${missing.join(', ')}`);
    }

    const accuracy = knownCards.length > 0 ?
        (matched.length / knownCards.length * 100).toFixed(1) : 0;
    debug(`🎯 Độ chính xác: ${accuracy}%`);
}

function findNodeByName(name) {
    return findNodeDeep(name, cc.director.getScene());
}

function findNodeDeep(name, node) {
    if (!node) return null;
    if (node.name === name) return node;
    for (let child of node.children) {
        const found = findNodeDeep(name, child);
        if (found) return found;
    }
    return null;
}

// Hàm tìm kiếm nâng cao cho các node chứa bài đã đánh
function findPlayedCardNodes() {
    debug(`\n🔍 TÌM KIẾM CÁC NODE CHỨA BÀI ĐÃ ĐÁNH...`);

    const scene = cc.director.getScene();
    const foundNodes = {};

    // Danh sách các tên node có thể chứa bài đã đánh
    const possibleNodeNames = [
        // Bài trên bàn chung
        'table_cards', 'board_cards', 'played_cards', 'center_cards',
        'discard_pile', 'middle_cards', 'table_center', 'game_table',
        'card_table', 'play_area', 'center_area',

        // Bài của người chơi đã đánh
        'my_played', 'player_played', 'my_discard', 'player_discard',
        'my_cards_played', 'own_played', 'user_played',

        // Bài của đối thủ đã đánh
        'opponent_played', 'enemy_played', 'opponent_discard', 'enemy_discard',
        'other_played', 'rival_played', 'ai_played',

        // Các tên khác có thể
        'played_area', 'discard_area', 'throw_cards', 'dropped_cards'
    ];

    // Tìm kiếm các node
    possibleNodeNames.forEach(nodeName => {
        const node = findNodeByName(nodeName);
        if (node) {
            foundNodes[nodeName] = node;
            debug(`  ✅ Tìm thấy: ${nodeName}`);

            // Đếm số lượng card children
            const cardCount = node.children ? node.children.filter(child =>
                child.name === 'card' && child.active
            ).length : 0;

            if (cardCount > 0) {
                debug(`    📊 Có ${cardCount} thẻ bài`);
            }
        }
    });

    // Tìm kiếm theo pattern trong tên node
    function searchNodesByPattern(rootNode, pattern) {
        const results = [];

        function traverse(node) {
            if (node.name && node.name.toLowerCase().includes(pattern.toLowerCase())) {
                results.push(node);
            }
            if (node.children) {
                node.children.forEach(child => traverse(child));
            }
        }

        traverse(rootNode);
        return results;
    }

    // Tìm các node có tên chứa "played", "discard", "table"
    const patterns = ['played', 'discard', 'table', 'board', 'center'];
    patterns.forEach(pattern => {
        const nodes = searchNodesByPattern(scene, pattern);
        if (nodes.length > 0) {
            debug(`  🔍 Tìm thấy ${nodes.length} node chứa "${pattern}": ${nodes.map(n => n.name).join(', ')}`);
            nodes.forEach(node => {
                if (!foundNodes[node.name]) {
                    foundNodes[node.name] = node;
                }
            });
        }
    });

    return foundNodes;
}

// Monitor changes - Theo dõi cả bài trên tay và bài đã đánh
function monitorCardChanges() {
    let lastCardData = null;
    let lastBoardData = null;

    setInterval(() => {
        // Theo dõi bài trên tay
        const currentCards = getPlayerCards();
        const currentVisibleCards = currentCards.visible.map(c => c.cardCode).sort().join(',');

        // Theo dõi bài đã đánh
        const boardInfo = analyzeBoardCards();
        const currentBoardCards = `${boardInfo.summary.myCount}-${boardInfo.summary.opponentCount}-${boardInfo.summary.total}`;

        // Kiểm tra thay đổi bài trên tay
        if (currentVisibleCards !== lastCardData) {
            debug(`\n🔄 THAY ĐỔI BÀI TRÊN TAY: ${new Date().toLocaleTimeString()}`);
            if (currentCards.visible.length > 0) {
                debug(`Bài hiện tại: ${currentCards.visible.map(c => c.cardName).join(', ')}`);
            }
            lastCardData = currentVisibleCards;
        }

        // Kiểm tra thay đổi bài đã đánh
        if (currentBoardCards !== lastBoardData) {
            debug(`\n🎲 THAY ĐỔI BÀI ĐÃ ĐÁNH: ${new Date().toLocaleTimeString()}`);
            if (boardInfo.summary.total > 0) {
                debug(`📊 Tổng bài đã đánh: ${boardInfo.summary.total}`);
                debug(`🟢 Tôi: ${boardInfo.summary.myCount} | 🔴 Đối thủ: ${boardInfo.summary.opponentCount}`);
            }
            lastBoardData = currentBoardCards;
        }
    }, 2000);
}

// Hàm phân tích tổng hợp trạng thái game
function analyzeGameState() {
    debug(`\n🎮 ===== PHÂN TÍCH TỔNG HỢP TRẠNG THÁI GAME =====`);
    debug(`⏰ Thời gian: ${new Date().toLocaleTimeString()}`);

    // Phân tích bài trên tay
    const handCards = getPlayerCards();

    // Phân tích bài đã đánh
    const boardInfo = analyzeBoardCards();

    // Đưa ra gợi ý chiến lược
    if (handCards.visible.length > 0 && boardInfo.summary.total > 0) {
        provideTacticalAdvice(handCards.visible, boardInfo);
    }

    return {
        hand: handCards,
        board: boardInfo,
        timestamp: Date.now()
    };
}

// Đưa ra lời khuyên chiến lược
function provideTacticalAdvice(handCards, boardInfo) {
    debug(`\n💡 GỢI Ý CHIẾN LƯỢC:`);

    const remainingCards = 52 - boardInfo.summary.total - handCards.length;
    debug(`🃏 Số bài còn lại trong bộ: ${remainingCards}`);

    // Phân tích xu hướng đánh bài
    const myPlayedCount = boardInfo.summary.myCount;
    const opponentPlayedCount = boardInfo.summary.opponentCount;

    if (myPlayedCount > opponentPlayedCount + 2) {
        debug(`⚠️ Bạn đang đánh quá nhiều so với đối thủ. Hãy thận trọng hơn!`);
    } else if (opponentPlayedCount > myPlayedCount + 2) {
        debug(`📈 Đối thủ đang đánh tích cực. Có thể họ đang gặp khó khăn hoặc có chiến lược gì đó.`);
    } else {
        debug(`⚖️ Tình hình khá cân bằng. Tiếp tục quan sát.`);
    }

    // Phân tích bài cao
    const myHighCards = handCards.filter(c => c.value >= 10 || c.value === 1);
    const playedHighCards = Array.from(myPlayedCards).concat(Array.from(opponentPlayedCards))
        .map(code => parseCardFromCode(code))
        .filter(c => c.value >= 10 || c.value === 1);

    debug(`\n🎯 PHÂN TÍCH BÀI CAO:`);
    debug(`  Bài cao trong tay: ${myHighCards.length}`);
    debug(`  Bài cao đã đánh: ${playedHighCards.length}`);

    if (myHighCards.length > 3) {
        debug(`  💎 Bạn có nhiều bài cao. Hãy sử dụng khôn ngoan!`);
    }
}

// Method to trigger cocos click on a node with multiple approaches
function triggerCocosClick(node) {
    debug(`🖱️ Đang thử click node: ${node.name} tại vị trí (${node.position.x}, ${node.position.y})`);

    // Method 1: Standard touch events with fallback coordinates
    try {
        // Try to get world position, fallback to node position
        let worldPos;
        if (typeof node.convertToWorldSpaceAR === 'function') {
            worldPos = node.convertToWorldSpaceAR(cc.Vec2.ZERO);
        } else if (typeof node.convertToWorldSpace === 'function') {
            worldPos = node.convertToWorldSpace(cc.Vec2.ZERO);
        } else {
            // Fallback to node position
            worldPos = { x: node.position.x, y: node.position.y };
        }

        const createTouchEvent = (x, y, eventType) => {
            const touch = {
                x: x || worldPos.x,
                y: y || worldPos.y,
                getLocation: function () { return { x: this.x, y: this.y }; },
                getLocationInView: function () { return { x: this.x, y: this.y }; },
                getStartLocation: function () { return { x: this.x, y: this.y }; }
            };

            const event = new cc.Event.EventTouch([touch], false);
            event.type = eventType || cc.Node.EventType.TOUCH_START;
            event.touch = touch;
            event.getLocation = () => ({ x: touch.x, y: touch.y });
            event.getLocationInView = () => ({ x: touch.x, y: touch.y });
            return event;
        };

        // Emit touch sequence
        const startEvent = createTouchEvent(worldPos.x, worldPos.y, cc.Node.EventType.TOUCH_START);
        node.emit(cc.Node.EventType.TOUCH_START, startEvent);

        // Small delay for touch move
        setTimeout(() => {
            const moveEvent = createTouchEvent(worldPos.x, worldPos.y, cc.Node.EventType.TOUCH_MOVE);
            node.emit(cc.Node.EventType.TOUCH_MOVE, moveEvent);
        }, 10);

        setTimeout(() => {
            const endEvent = createTouchEvent(worldPos.x, worldPos.y, cc.Node.EventType.TOUCH_END);
            node.emit(cc.Node.EventType.TOUCH_END, endEvent);
            debug(`✅ Method 1: Đã emit touch events cho node ${node.name}`);
        }, 50);

    } catch (error) {
        debug(`❌ Method 1 failed: ${error}`);
    }

    // Method 2: Try with Button component
    try {
        const button = node.getComponent(cc.Button);
        if (button && button.enabled) {
            button.node.emit('click');
            debug(`✅ Method 2: Đã click Button component`);
        }
    } catch (error) {
        debug(`❌ Method 2 failed: ${error}`);
    }

    // Method 3: Direct component interaction
    try {
        // Check for custom components that might handle clicks
        if (node._components) {
            node._components.forEach((component, index) => {
                if (component && typeof component.onClick === 'function') {
                    component.onClick();
                    debug(`✅ Method 3: Đã gọi onClick của component ${index}`);
                } else if (component && typeof component.onTouch === 'function') {
                    component.onTouch();
                    debug(`✅ Method 3: Đã gọi onTouch của component ${index}`);
                }
            });
        }
    } catch (error) {
        debug(`❌ Method 3 failed: ${error}`);
    }

    // Method 4: Mouse events simulation
    try {
        const mouseEvent = new MouseEvent('click', {
            view: window,
            bubbles: true,
            cancelable: true,
            clientX: node.position.x,
            clientY: node.position.y
        });

        if (node._sgNode && node._sgNode.dispatchEvent) {
            node._sgNode.dispatchEvent(mouseEvent);
            debug(`✅ Method 4: Đã dispatch mouse event`);
        }
    } catch (error) {
        debug(`❌ Method 4 failed: ${error}`);
    }

    // Method 5: Try to find and call card selection functions
    try {
        // Look for card-specific selection methods
        if (node._components && node._components.length > 2) {
            const cardComponent = node._components[2];
            if (cardComponent && cardComponent.card !== undefined) {
                // Try common card selection method names
                const methods = ['selectCard', 'onCardClick', 'cardSelected', 'select', 'choose'];
                methods.forEach(methodName => {
                    if (typeof cardComponent[methodName] === 'function') {
                        cardComponent[methodName]();
                        debug(`✅ Method 5: Đã gọi ${methodName} trên card component`);
                    }
                });

                // Try parent component methods
                if (cardComponent.node && cardComponent.node.parent && cardComponent.node.parent._components) {
                    cardComponent.node.parent._components.forEach(parentComp => {
                        methods.forEach(methodName => {
                            if (typeof parentComp[methodName] === 'function') {
                                parentComp[methodName](cardComponent.card);
                                debug(`✅ Method 5: Đã gọi ${methodName} trên parent component`);
                            }
                        });
                    });
                }
            }
        }
    } catch (error) {
        debug(`❌ Method 5 failed: ${error}`);
    }
}

// Method to click select card by card number (1-based index)
function clickSelectCard(cardNumber) {
    debug(`\n🎯 Cố gắng click chọn quân bài số: ${cardNumber}`);

    const cardNode = findNodeByName("card_node");
    if (!cardNode) {
        debug("❌ Không tìm thấy card_node");
        return false;
    }

    // Get current player cards
    const playerCards = getPlayerCards();
    if (!playerCards.visible || playerCards.visible.length === 0) {
        debug("❌ Không có quân bài nào hiện tại");
        return false;
    }

    // Validate card number
    if (cardNumber < 1 || cardNumber > playerCards.visible.length) {
        debug(`❌ Số thứ tự quân bài không hợp lệ. Phải từ 1-${playerCards.visible.length}`);
        return false;
    }

    // Find the card node to click
    let cardIndex = 0;
    let is_clicked = false;
    playerCards.visible.forEach(card => {
        cardIndex += 1;
        if (cardIndex === cardNumber && !is_clicked) {
            const cardChild = cardNode.children[card.index - 1];
            if (cardChild) {
                triggerCocosClick(cardChild);
                debug(`✅ Đã click chọn quân bài số ${cardNumber}: ${card.cardName}`);
                is_clicked = true;
                return true;
            } else {
                debug(`❌ Không tìm thấy node của quân bài số ${cardNumber}`);
                return false;
            }
        }
    });
    return is_clicked;
}

// Method to click select card by card name (e.g., "A♥", "K♠", "10♦")
function clickSelectCardByName(cardName) {
    debug(`\n🎯 Cố gắng click chọn quân bài: ${cardName}`);

    const playerCards = getPlayerCards();
    if (!playerCards.visible || playerCards.visible.length === 0) {
        debug("❌ Không có quân bài nào hiện tại");
        return false;
    }

    // Find card by name
    const targetCard = playerCards.visible.find(card =>
        card.cardName === cardName ||
        card.cardName.replace(/[♠♥♦♣]/g, match => {
            const suitMap = { '♠': 'B', '♥': 'C', '♦': 'R', '♣': 'T' };
            return suitMap[match] || match;
        }) === cardName
    );

    if (!targetCard) {
        debug(`❌ Không tìm thấy quân bài: ${cardName}`);
        debug(`📋 Các quân bài hiện có: ${playerCards.visible.map(c => c.cardName).join(', ')}`);
        return false;
    }

    // Click the found card
    return clickSelectCard(targetCard.index);
}

// Method to debug node structure and find click handlers
function debugNodeStructure(node, cardInfo = null) {
    debug(`\n🔍 DEBUG NODE STRUCTURE: ${node.name}`);
    debug(`📍 Position: (${node.position.x}, ${node.position.y})`);
    debug(`✅ Active: ${node.active}`);
    debug(`👁️ Visible: ${node.opacity > 0}`);

    if (cardInfo) {
        debug(`🃏 Card Info: ${cardInfo.cardName} (${cardInfo.suit.name})`);
    }

    // Check components
    if (node._components) {
        debug(`🧩 Components (${node._components.length}):`);
        node._components.forEach((comp, index) => {
            if (comp) {
                debug(`  [${index}] ${comp.constructor.name || 'Unknown'}`);

                // Check for click-related properties and methods
                const clickMethods = ['onClick', 'onTouch', 'selectCard', 'onCardClick', 'cardSelected', 'select', 'choose'];
                const foundMethods = clickMethods.filter(method => typeof comp[method] === 'function');
                if (foundMethods.length > 0) {
                    debug(`    🎯 Click methods: ${foundMethods.join(', ')}`);
                }

                // Check for card property
                if (comp.card !== undefined) {
                    debug(`    🃏 Has card property: ${JSON.stringify(comp.card)}`);
                }

                // Check Button component
                if (comp.constructor.name === 'cc.Button' || comp.interactable !== undefined) {
                    debug(`    🔘 Button component - enabled: ${comp.enabled}, interactable: ${comp.interactable}`);
                }
            }
        });
    }

    // Check event listeners
    if (node._eventProcessor && node._eventProcessor._listeners) {
        const listeners = node._eventProcessor._listeners;
        debug(`🎧 Event Listeners:`);
        Object.keys(listeners).forEach(eventType => {
            if (listeners[eventType] && listeners[eventType].length > 0) {
                debug(`  ${eventType}: ${listeners[eventType].length} listeners`);
            }
        });
    }

    // Check parent node
    if (node.parent) {
        debug(`👨‍👩‍👧‍👦 Parent: ${node.parent.name}`);
    }

    return node;
}

// Click by coordinates function
function clickByCoordinates(x, y, elementType = 'canvas') {
    debug(`🎯 Click bằng tọa độ: (${x}, ${y}) trên ${elementType}`);

    try {
        // Method 1: Canvas click simulation
        const canvas = document.querySelector('canvas');
        if (canvas) {
            const rect = canvas.getBoundingClientRect();

            // Convert game coordinates to screen coordinates
            const screenX = rect.left + rect.width / 2 + x;
            const screenY = rect.top + rect.height / 2 - y; // Y axis is inverted in canvas

            debug(`📍 Screen coordinates: (${screenX}, ${screenY})`);

            // Create mouse events
            const mouseDown = new MouseEvent('mousedown', {
                bubbles: true,
                cancelable: true,
                clientX: screenX,
                clientY: screenY,
                button: 0
            });

            const mouseUp = new MouseEvent('mouseup', {
                bubbles: true,
                cancelable: true,
                clientX: screenX,
                clientY: screenY,
                button: 0
            });

            const click = new MouseEvent('click', {
                bubbles: true,
                cancelable: true,
                clientX: screenX,
                clientY: screenY,
                button: 0
            });

            // Dispatch events
            canvas.dispatchEvent(mouseDown);
            setTimeout(() => {
                canvas.dispatchEvent(mouseUp);
                canvas.dispatchEvent(click);
            }, 50);

            debug(`✅ Đã click canvas tại tọa độ (${x}, ${y})`);
            return true;
        }
    } catch (error) {
        debug(`❌ Canvas click failed: ${error}`);
    }

    // Method 2: Touch events simulation
    try {
        const canvas = document.querySelector('canvas');
        if (canvas) {
            const rect = canvas.getBoundingClientRect();
            const screenX = rect.left + rect.width / 2 + x;
            const screenY = rect.top + rect.height / 2 - y;

            const touch = new Touch({
                identifier: 1,
                target: canvas,
                clientX: screenX,
                clientY: screenY,
                pageX: screenX,
                pageY: screenY,
                screenX: screenX,
                screenY: screenY
            });

            const touchStart = new TouchEvent('touchstart', {
                bubbles: true,
                cancelable: true,
                touches: [touch],
                targetTouches: [touch],
                changedTouches: [touch]
            });

            const touchEnd = new TouchEvent('touchend', {
                bubbles: true,
                cancelable: true,
                touches: [],
                targetTouches: [],
                changedTouches: [touch]
            });

            canvas.dispatchEvent(touchStart);
            setTimeout(() => {
                canvas.dispatchEvent(touchEnd);
            }, 50);

            debug(`✅ Đã touch canvas tại tọa độ (${x}, ${y})`);
            return true;
        }
    } catch (error) {
        debug(`❌ Touch events failed: ${error}`);
    }

    return false;
}

// Click card by coordinates
function clickCardByCoordinates(cardNumber) {
    debug(`\n📍 Click quân bài số ${cardNumber} bằng tọa độ`);

    const playerCards = getPlayerCards();
    if (!playerCards.visible || playerCards.visible.length === 0) {
        debug("❌ Không có quân bài nào hiện tại");
        return false;
    }

    if (cardNumber < 1 || cardNumber > playerCards.visible.length) {
        debug(`❌ Số thứ tự quân bài không hợp lệ. Phải từ 1-${playerCards.visible.length}`);
        return false;
    }

    const card = playerCards.visible[cardNumber - 1];
    debug(`🎯 Click quân bài: ${card.cardName} tại (${card.position.x}, ${card.position.y})`);

    return clickByCoordinates(card.position.x, card.position.y);
}

// Click at specific screen position
function clickAtScreenPosition(screenX, screenY) {
    debug(`🖱️ Click tại màn hình: (${screenX}, ${screenY})`);

    try {
        const element = document.elementFromPoint(screenX, screenY);
        if (element) {
            debug(`🎯 Tìm thấy element: ${element.tagName} tại vị trí click`);

            const events = ['mousedown', 'mouseup', 'click'];
            events.forEach(eventType => {
                const event = new MouseEvent(eventType, {
                    bubbles: true,
                    cancelable: true,
                    clientX: screenX,
                    clientY: screenY,
                    button: 0
                });
                element.dispatchEvent(event);
            });

            debug(`✅ Đã click element tại (${screenX}, ${screenY})`);
            return true;
        }
    } catch (error) {
        debug(`❌ Screen click failed: ${error}`);
    }

    return false;
}

// Get card screen coordinates
function getCardScreenCoordinates(cardNumber) {
    const playerCards = getPlayerCards();
    if (!playerCards.visible || cardNumber > playerCards.visible.length) {
        return null;
    }

    const card = playerCards.visible[cardNumber - 1];
    const canvas = document.querySelector('canvas');

    if (canvas) {
        const rect = canvas.getBoundingClientRect();
        const screenX = rect.left + rect.width / 2 + card.position.x;
        const screenY = rect.top + rect.height / 2 - card.position.y;

        return {
            game: { x: card.position.x, y: card.position.y },
            screen: { x: screenX, y: screenY },
            card: card
        };
    }

    return null;
}

// Optimized click function - only use the working method
function quickClickCard(node) {
    debug(`🎯 Quick click node: ${node.name} tại vị trí (${node.position.x}, ${node.position.y})`);

    // Method 3 - Component onClick (đã proven hoạt động)
    try {
        if (node._components && node._components.length > 2) {
            const cardComponent = node._components[2];
            if (cardComponent && typeof cardComponent.onClick === 'function') {
                cardComponent.onClick();
                debug(`✅ Quick click thành công: Đã gọi onClick của component 2`);
                return true;
            }
        }
    } catch (error) {
        debug(`❌ Quick click failed: ${error}`);
    }

    // Fallback - try other component methods
    try {
        if (node._components) {
            for (let i = 0; i < node._components.length; i++) {
                const comp = node._components[i];
                if (comp && typeof comp.onClick === 'function') {
                    comp.onClick();
                    debug(`✅ Quick click fallback thành công: Đã gọi onClick của component ${i}`);
                    return true;
                }
            }
        }
    } catch (error) {
        debug(`❌ Quick click fallback failed: ${error}`);
    }

    return false;
}

// Simplified card selection function
function fastClickSelectCard(cardNumber) {
    debug(`\n⚡ Fast click chọn quân bài số: ${cardNumber}`);

    const cardNode = findNodeByName("card_node");
    if (!cardNode) {
        debug("❌ Không tìm thấy card_node");
        return false;
    }

    // Get current player cards
    const playerCards = getPlayerCards();
    if (!playerCards.visible || playerCards.visible.length === 0) {
        debug("❌ Không có quân bài nào hiện tại");
        return false;
    }

    // Validate card number
    if (cardNumber < 1 || cardNumber > playerCards.visible.length) {
        debug(`❌ Số thứ tự quân bài không hợp lệ. Phải từ 1-${playerCards.visible.length}`);
        return false;
    }

    // Find and click the card
    let cardIndex = 0;
    for (const card of playerCards.visible) {
        cardIndex++;
        if (cardIndex === cardNumber) {
            const cardChild = cardNode.children[card.index - 1];
            if (cardChild) {
                const success = quickClickCard(cardChild);
                if (success) {
                    debug(`✅ Fast click thành công quân bài số ${cardNumber}: ${card.cardName}`);
                    return true;
                }
            }
        }
    }

    debug(`❌ Fast click thất bại cho quân bài số ${cardNumber}`);
    return false;
}

// Enhanced method to get clickable cards info with debugging
function getClickableCards() {
    const playerCards = getPlayerCards();
    if (!playerCards.visible || playerCards.visible.length === 0) {
        debug("❌ Không có quân bài nào để click");
        return [];
    }

    debug(`\n🎮 DANH SÁCH QUÂN BÀI CÓ THỂ CLICK:`);

    const cardNode = findNodeByName("card_node");
    if (cardNode) {
        playerCards.visible.forEach((card, index) => {
            debug(`\n  ${card.index}. ${card.cardName} (${card.suit.name}) - Vị trí: (${card.position.x}, ${card.position.y})`);

            // Find the actual node for this card
            const cardChild = cardNode.children[card.index - 1];
            if (cardChild) {
                debugNodeStructure(cardChild, card);
            }
        });
    }

    return playerCards.visible;
}

// Method to test different click approaches on a specific card
function testCardClick(cardNumber) {
    debug(`\n🧪 TESTING CLICK METHODS FOR CARD ${cardNumber}:`);

    const playerCards = getPlayerCards();
    if (!playerCards.visible || cardNumber > playerCards.visible.length) {
        debug("❌ Invalid card number");
        return false;
    }

    const cardNode = findNodeByName("card_node");
    if (!cardNode) {
        debug("❌ card_node not found");
        return false;
    }

    const card = playerCards.visible[cardNumber - 1];
    const cardChild = cardNode.children[card.index - 1];

    if (!cardChild) {
        debug("❌ Card node not found");
        return false;
    }

    debug(`🎯 Testing on card: ${card.cardName}`);
    debugNodeStructure(cardChild, card);

    // Now try clicking with enhanced method
    triggerCocosClick(cardChild);

    return true;
}

// Export functions
window.getPlayerCards = getPlayerCards;
window.analyzeHand = analyzeHand;
window.validateWithKnownCards = validateWithKnownCards;
window.monitorCardChanges = monitorCardChanges;

// Export new functions for board tracking
window.findBoardCards = findBoardCards;
window.findMyPlayedCards = findMyPlayedCards;
window.findOpponentPlayedCards = findOpponentPlayedCards;
window.findPlayedCardNodes = findPlayedCardNodes;
window.analyzeBoardCards = analyzeBoardCards;
window.analyzeGameState = analyzeGameState;
window.provideTacticalAdvice = provideTacticalAdvice;

// Export card selection functions
window.triggerCocosClick = triggerCocosClick;
window.clickSelectCard = clickSelectCard;
window.clickSelectCardByName = clickSelectCardByName;
window.getClickableCards = getClickableCards;
window.debugNodeStructure = debugNodeStructure;
window.testCardClick = testCardClick;

// Export optimized functions
window.quickClickCard = quickClickCard;
window.fastClickSelectCard = fastClickSelectCard;

// Export coordinate-based click functions
window.clickByCoordinates = clickByCoordinates;
window.clickCardByCoordinates = clickCardByCoordinates;
window.clickAtScreenPosition = clickAtScreenPosition;
window.getCardScreenCoordinates = getCardScreenCoordinates;

// Helper functions to manage tracked data
window.clearPlayedCards = function () {
    myPlayedCards.clear();
    opponentPlayedCards.clear();
    boardCards.clear();
    cardHistory = [];
    debug("🧹 Đã xóa dữ liệu bài đã đánh");
};

window.getPlayedCardsStats = function () {
    return {
        myPlayed: Array.from(myPlayedCards),
        opponentPlayed: Array.from(opponentPlayedCards),
        totalBoard: Array.from(boardCards),
        history: cardHistory,
        stats: {
            myCount: myPlayedCards.size,
            opponentCount: opponentPlayedCards.size,
            totalCount: boardCards.size,
            historyLength: cardHistory.length
        }
    };
};

window.showCardHistory = function () {
    debug(`\n📜 LỊCH SỬ ĐÁNH BÀI (${cardHistory.length} lượt):`);
    cardHistory.forEach((card, index) => {
        const owner = card.owner === 'me' ? '🟢' : card.owner === 'opponent' ? '🔴' : '🎲';
        debug(`  ${index + 1}. ${owner} ${card.cardName} - ${card.playTime}`);
    });
};

// Auto start
debug("🎲 Bắt đầu phân tích quân bài và theo dõi bàn chơi...");
debug("📝 Sử dụng các lệnh sau:");
debug("  - getPlayerCards(): Xem bài trên tay");
debug("  - analyzeBoardCards(): Phân tích bài đã đánh");
debug("  - analyzeGameState(): Phân tích tổng hợp");
debug("  - findPlayedCardNodes(): Tìm các node chứa bài đã đánh");
debug("  - showCardHistory(): Xem lịch sử đánh bài");
debug("  - clearPlayedCards(): Xóa dữ liệu bài đã đánh");
debug("  - getPlayedCardsStats(): Xem thống kê");
debug("");
debug("🖱️ Các lệnh click chọn quân bài:");
debug("  - getClickableCards(): Xem danh sách quân bài có thể click (với debug info)");
debug("  - clickSelectCard(cardNumber): Click chọn quân bài theo số thứ tự (1, 2, 3...)");
debug("  - clickSelectCardByName('A♥'): Click chọn quân bài theo tên");
debug("  - triggerCocosClick(node): Click vào một node với nhiều phương pháp");
debug("  - debugNodeStructure(node): Debug cấu trúc node để tìm cách click");
debug("  - testCardClick(cardNumber): Test nhiều phương pháp click trên một quân bài");
debug("");
debug("⚡ Các lệnh click tối ưu (nhanh và ổn định):");
debug("  - fastClickSelectCard(cardNumber): Click nhanh quân bài theo số thứ tự");
debug("  - quickClickCard(node): Click trực tiếp một node (chỉ dùng method đã proven)");
debug("");
debug("📍 Các lệnh click bằng tọa độ:");
debug("  - clickCardByCoordinates(cardNumber): Click quân bài bằng tọa độ");
debug("  - clickByCoordinates(x, y): Click tại tọa độ game cụ thể");
debug("  - clickAtScreenPosition(screenX, screenY): Click tại vị trí màn hình");
debug("  - getCardScreenCoordinates(cardNumber): Lấy tọa độ màn hình của quân bài");
debug("");

// Khởi động các chức năng
getPlayerCards();
findPlayedCardNodes(); // Tìm kiếm các node ngay từ đầu